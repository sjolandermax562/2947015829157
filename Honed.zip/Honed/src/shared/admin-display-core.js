/**
 * Admin Display Core - Shared Module
 * Common logic for creating admin displays with avatars, usernames, scores, and buttons
 * Used by both pump.fun (content.js) and axiom.trade (axiom.js)
 */

// Guard against duplicate script loading
if (typeof window.AdminDisplayHotReload !== 'undefined') {
  console.log('[AdminDisplayCore] Already loaded, skipping...');
} else {

/**
 * Hot Reload Manager - Updates admin scores when sheet data changes
 */
class AdminDisplayHotReload {
  constructor(SheetsData) {
    this.SheetsData = SheetsData;
    this.storageListenerBound = null;
  }

  // Start listening for storage changes
  start() {
    if (this.storageListenerBound) return; // Already started

    this.storageListenerBound = this._handleStorageChange.bind(this);
    chrome.storage.onChanged.addListener(this.storageListenerBound);
    console.log('[AdminDisplayHotReload] Started');
  }

  // Stop listening for storage changes
  stop() {
    if (this.storageListenerBound) {
      chrome.storage.onChanged.removeListener(this.storageListenerBound);
      this.storageListenerBound = null;
    }
  }

  // Handle storage changes - update all admin scores on the page
  async _handleStorageChange(changes, areaName) {
    // Only care about local storage changes
    if (areaName !== 'local') return;

    // Check if admin data was updated
    if (changes.sheetsAdmins) {
      console.log('[AdminDisplayHotReload] Admin sheet data updated, refreshing scores on page');
      await this._updateAllScores();
    }
  }

  // Update all admin score elements on the page
  async _updateAllScores() {
    // Find all admin score elements (including "..." placeholders)
    const scoreElements = document.querySelectorAll('.admin-sheet-score[data-admin-username]');

    console.log(`[AdminDisplayHotReload] Found ${scoreElements.length} score elements to update`);

    for (const scoreElement of scoreElements) {
      const username = scoreElement.getAttribute('data-admin-username');
      if (!username) continue;

      try {
        const stats = await this.SheetsData.getAdminStats(username);
        if (stats && stats.total_rating >= 0) {
          const scoreData = this.SheetsData.formatScore(stats.total_rating);
          scoreElement.textContent = scoreData.formatted;
          scoreElement.className = `admin-sheet-score ${scoreData.class}`;
          scoreElement.style.color = scoreData.color;
          scoreElement.style.fontWeight = '600';
        }
      } catch (err) {
        console.error(`[AdminDisplayHotReload] Failed to update score for ${username}:`, err);
      }
    }
  }
}

/**
 * Format follower count for display
 * @param {number} count - Follower count
 * @returns {string} Formatted count (e.g., "1.5K", "2.3M")
 */
function formatFollowerCount(count) {
  if (!count || isNaN(count)) return '0';
  count = Number(count);
  if (count >= 1000000) {
    return (count / 1000000).toFixed(1) + 'M';
  }
  if (count >= 1000) {
    return (count / 1000).toFixed(1) + 'K';
  }
  return count.toString();
}

/**
 * Create admin avatar element
 * @param {Object} admin - Admin object from API
 * @param {Object} chrome - Chrome API object (for runtime.getURL)
 * @returns {HTMLImageElement} Avatar image element
 */
function createAdminAvatar(admin, chrome) {
  const avatar = document.createElement('img');
  const fallbackIcon = chrome?.runtime?.getURL?.('icons/icon48.png') || 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><circle cx="12" cy="12" r="10"/></svg>';
  avatar.src = admin.profile_image_url_https || admin.profilePicture || fallbackIcon;
  avatar.alt = admin.screen_name || admin.userName || 'Admin';
  avatar.className = 'admin-avatar';
  avatar.style.cssText = 'width: 18px !important; height: 18px !important; border-radius: 50% !important; flex-shrink: 0 !important; position: relative !important;';
  avatar.onerror = () => {
    avatar.src = fallbackIcon;
  };

  return avatar;
}

/**
 * Create username label element
 * @param {Object} admin - Admin object from API
 * @param {Function} onHover - Callback for hover events (for tooltip)
 * @returns {HTMLSpanElement} Username span element
 */
function createUsernameLabel(admin, onHover) {
  const usernameLabel = document.createElement('span');
  usernameLabel.className = 'admin-username';
  const username = admin.screen_name || admin.userName || 'unknown';
  usernameLabel.textContent = '@' + username;
  usernameLabel.style.cssText = 'cursor: pointer !important; pointer-events: auto !important; font-size: 12px !important; color: #e2e8f0 !important; font-weight: 500 !important;';

  if (onHover) {
    usernameLabel.addEventListener('mouseenter', (e) => onHover(e.target, username));
    usernameLabel.addEventListener('mousemove', (e) => onHover && onHover.moveTo && onHover.moveTo(e.clientX, e.clientY));
    usernameLabel.addEventListener('mouseleave', () => onHover && onHover.leave && onHover.leave());
  }

  return usernameLabel;
}

/**
 * Create follower count element
 * @param {Object} admin - Admin object from API
 * @returns {HTMLSpanElement|null} Follower count span or null if not available
 */
function createFollowerCount(admin) {
  const followers = admin.followers_count || admin.followers || 0;
  if (!followers) return null;

  const separator = document.createElement('span');
  separator.className = 'admin-separator';
  separator.textContent = ' • ';
  separator.style.cssText = 'font-size: 12px !important; color: #94a3b8 !important;';

  const followerCount = document.createElement('span');
  followerCount.className = 'admin-follower-count';
  followerCount.textContent = formatFollowerCount(followers);
  followerCount.style.cssText = 'font-size: 12px !important; color: #94a3b8 !important;';

  return { separator, followerCount };
}

/**
 * Create sheet score element
 * @param {Object} admin - Admin object from API
 * @param {Object} SheetsData - SheetsData module with getAdminStats and formatScore
 * @returns {Promise<HTMLSpanElement|null>} Score span or null if no data
 */
async function createSheetScore(admin, SheetsData) {
  const stats = await SheetsData.getAdminStats(admin.screen_name || admin.userName);
  if (!stats || stats.total_rating < 0) return null;

  const scoreData = SheetsData.formatScore(stats.total_rating);

  const separator = document.createElement('span');
  separator.className = 'admin-separator';
  separator.textContent = ' - ';
  separator.style.cssText = 'font-size: 12px !important; color: #94a3b8 !important;';

  const scoreSpan = document.createElement('span');
  scoreSpan.className = `admin-sheet-score ${scoreData.class}`;
  scoreSpan.textContent = scoreData.formatted;
  scoreSpan.style.cssText = `font-size: 12px !important; color: ${scoreData.color} !important; font-weight: 600 !important;`;
  // Add data attribute for hot reload
  scoreSpan.setAttribute('data-admin-username', admin.screen_name || admin.userName || '');

  return { separator, scoreSpan };
}

/**
 * Create track button element
 * @param {Object} admin - Admin object from API
 * @returns {HTMLButtonElement} Track button
 */
function createTrackButton(admin) {
  const trackBtn = document.createElement('button');
  trackBtn.className = 'admin-track-btn';
  trackBtn.setAttribute('data-admin-username', admin.screen_name || admin.userName || '');
  trackBtn.style.cssText = 'background: transparent !important; border: none !important; cursor: pointer !important; padding: 2px !important; display: flex !important; align-items: center !important; justify-content: center !important; opacity: 0.6 !important; transition: opacity 0.2s !important; flex-shrink: 0 !important;';
  return trackBtn;
}

/**
 * Create blacklist button element
 * @param {Object} admin - Admin object from API
 * @returns {HTMLButtonElement} Blacklist button
 */
function createBlacklistButton(admin) {
  const blacklistBtn = document.createElement('button');
  blacklistBtn.className = 'admin-blacklist-btn';
  blacklistBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
    <circle cx="12" cy="12" r="10"></circle>
    <line x1="15" y1="9" x2="9" y2="15"></line>
    <line x1="9" y1="9" x2="15" y2="15"></line>
  </svg>`;
  blacklistBtn.title = `Blacklist @${admin.screen_name || admin.userName}`;
  blacklistBtn.style.cssText = 'background: transparent !important; border: none !important; cursor: pointer !important; padding: 2px !important; display: flex !important; align-items: center !important; justify-content: center !important; color: #f43f5e !important; opacity: 0.6 !important; transition: opacity 0.2s !important; flex-shrink: 0 !important;';
  return blacklistBtn;
}

// Export for use in content scripts
if (typeof window !== 'undefined') {
  window.AdminDisplayCore = {
    formatFollowerCount,
    createAdminAvatar,
    createUsernameLabel,
    createFollowerCount,
    createSheetScore,
    createTrackButton,
    createBlacklistButton
  };
  window.AdminDisplayHotReload = AdminDisplayHotReload;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    formatFollowerCount,
    createAdminAvatar,
    createUsernameLabel,
    createFollowerCount,
    createSheetScore,
    createTrackButton,
    createBlacklistButton,
    AdminDisplayHotReload
  };
}

} // End of duplicate load guard
