/**
 * Admin Avatar Refresh Module
 *
 * Automatically detects and refreshes missing, broken, or stale admin avatars
 * using the existing API client with rate limiting and error handling.
 */

/**
 * Avatar refresh options
 * @typedef {Object} AvatarRefreshOptions
 * @property {number} [retryDelay=60000] - Delay between retries for failed avatars (ms)
 * @property {number} [staleThreshold=86400000] - Age threshold for stale avatars (ms, default 24h)
 * @property {number} [maxConcurrent=3] - Maximum concurrent refresh requests
 * @property {boolean} [useCache=true] - Use API cache for fresh data
 * @property {string} [listType='tracked'] - Which list to refresh ('tracked' or 'blacklist')
 */

const DEFAULT_REFRESH_OPTIONS = {
  retryDelay: 60000, // 1 minute
  staleThreshold: 86400000, // 24 hours
  maxConcurrent: 3,
  useCache: true,
  listType: 'tracked'
};

// Rate limiting state
const refreshState = {
  pendingRequests: new Map(),
  lastAttemptTime: new Map(),
  failedAttempts: new Map()
};

/**
 * Check if an avatar URL is valid/available
 * @param {string} url - Avatar URL to check
 * @returns {boolean} True if URL appears valid
 */
function isValidAvatarUrl(url) {
  if (!url || typeof url !== 'string') return false;
  if (url === 'undefined' || url === 'null' || url === '') return false;
  if (url.includes('chrome-extension://') && url.includes('icon48.png')) return false; // Placeholder
  return url.startsWith('http://') || url.startsWith('https://');
}

/**
 * Check if avatar is stale (older than threshold)
 * @param {Object} admin - Admin object
 * @param {number} staleThreshold - Staleness threshold in milliseconds
 * @returns {boolean} True if avatar is stale
 */
function isAvatarStale(admin, staleThreshold) {
  const avatarTimestamp = admin.avatarFetchedAt || admin.addedAt || admin.dateAdded || 0;
  if (!avatarTimestamp) return false;
  return (Date.now() - avatarTimestamp) > staleThreshold;
}

/**
 * Fetch user profile from API with rate limiting
 * @param {string} username - Username to fetch
 * @param {Object} options - Refresh options
 * @returns {Promise<Object>} User profile data
 */
async function fetchFreshProfile(username, options) {
  // Check rate limiting
  const now = Date.now();
  const lastAttempt = refreshState.lastAttemptTime.get(username) || 0;
  const failedCount = refreshState.failedAttempts.get(username) || 0;

  // Exponential backoff for failed attempts
  const backoffDelay = options.retryDelay * Math.pow(2, Math.min(failedCount, 5));
  if (now - lastAttempt < backoffDelay) {
    throw new Error(`Rate limited: retry after ${Math.ceil((backoffDelay - (now - lastAttempt)) / 1000)}s`);
  }

  // Check for pending request
  if (refreshState.pendingRequests.has(username)) {
    return refreshState.pendingRequests.get(username);
  }

  refreshState.lastAttemptTime.set(username, now);

  // Make API request
  const request = new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: 'fetchUserProfile',
      username: username
    }, (response) => {
      refreshState.pendingRequests.delete(username);

      if (chrome.runtime.lastError) {
        refreshState.failedAttempts.set(username, failedCount + 1);
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }

      if (response && response.success) {
        const userData = response.data?.data || response.data;
        if (userData && (userData.userName || userData.screen_name)) {
          refreshState.failedAttempts.delete(username);
          resolve(userData);
        } else {
          refreshState.failedAttempts.set(username, failedCount + 1);
          reject(new Error('Invalid API response format'));
        }
      } else {
        refreshState.failedAttempts.set(username, failedCount + 1);
        reject(new Error(response?.error || 'Failed to fetch profile'));
      }
    });
  });

  refreshState.pendingRequests.set(username, request);
  return request;
}

/**
 * Update admin avatar in storage
 * @param {string} username - Username to update
 * @param {Object} profileData - New profile data
 * @param {string} [listType='tracked'] - Which list to update ('tracked' or 'blacklist')
 * @returns {Promise<void>}
 */
async function updateAdminAvatar(username, profileData, listType = 'tracked') {
  const storageKey = listType === 'blacklist' ? 'blacklistedAdmins' : 'trackedAdmins';
  const listName = listType === 'blacklist' ? 'blacklist' : 'tracked';

  return new Promise((resolve, reject) => {
    chrome.storage.local.get([storageKey], (result) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }

      const admins = result[storageKey] || [];
      const adminIndex = admins.findIndex(a => {
        const adminUsername = a.username || a.userName || a.screen_name;
        return adminUsername && adminUsername.toLowerCase() === username.toLowerCase();
      });

      if (adminIndex === -1) {
        reject(new Error(`Admin not found in ${listName} list`));
        return;
      }

      // Update admin with new avatar data
      admins[adminIndex] = {
        ...admins[adminIndex],
        profileImage: profileData.profilePicture || profileData.profile_image_url_https,
        profilePicture: profileData.profilePicture || profileData.profile_image_url_https,
        profile_image_url_https: profileData.profile_image_url_https,
        name: profileData.name,
        followersCount: profileData.followers || profileData.followers_count,
        followers: profileData.followers || profileData.followers_count,
        followers_count: profileData.followers_count,
        banner: profileData.coverPicture || profileData.profile_banner_url,
        description: profileData.description,
        avatarFetchedAt: Date.now()
      };

      chrome.storage.local.set({ [storageKey]: admins }, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
  });
}

/**
 * Get placeholder avatar URL
 * @returns {string} Placeholder avatar URL
 */
function getPlaceholderAvatar() {
  return chrome.runtime.getURL('icons/icon48.png');
}

/**
 * Check and refresh a single admin's avatar
 * @param {Object} admin - Admin object
 * @param {Object} options - Refresh options
 * @param {string} [listType='tracked'] - Which list to update ('tracked' or 'blacklist')
 * @returns {Promise<Object>} Refresh result
 */
async function refreshAdminAvatar(admin, options, listType = 'tracked') {
  const username = admin.username || admin.userName || admin.screen_name;
  if (!username) {
    return { success: false, reason: 'no_username' };
  }

  // Check if avatar needs refresh
  const currentAvatar = admin.profileImage || admin.profilePicture || admin.profile_image_url_https;

  if (isValidAvatarUrl(currentAvatar) && !isAvatarStale(admin, options.staleThreshold)) {
    return { success: true, action: 'skipped', reason: 'valid_and_fresh' };
  }

  try {
    const profileData = await fetchFreshProfile(username, options);
    await updateAdminAvatar(username, profileData, listType);
    return { success: true, action: 'refreshed', username };
  } catch (error) {
    console.warn(`[AvatarRefresh] Failed to refresh @${username}:`, error.message);

    // Set placeholder if avatar is invalid and refresh failed
    if (!isValidAvatarUrl(currentAvatar)) {
      await updateAdminAvatar(username, {
        profilePicture: getPlaceholderAvatar(),
        profile_image_url_https: getPlaceholderAvatar()
      }, listType);
      return { success: true, action: 'placeholder', reason: error.message };
    }

    return { success: false, action: 'failed', reason: error.message };
  }
}

/**
 * Batch process admin avatar refreshes with concurrency limit
 * @param {Array} admins - Admins to refresh
 * @param {Object} options - Refresh options
 * @param {string} [listType='tracked'] - Which list to update ('tracked' or 'blacklist')
 * @returns {Promise<Array>} Array of refresh results
 */
async function refreshBatch(admins, options, listType = 'tracked') {
  const results = [];
  const queue = [...admins];
  const concurrent = [];

  while (queue.length > 0 || concurrent.length > 0) {
    // Fill concurrent queue
    while (concurrent.length < options.maxConcurrent && queue.length > 0) {
      const admin = queue.shift();
      const promise = refreshAdminAvatar(admin, options, listType)
        .then(result => ({ admin, result }))
        .finally(() => {
          const index = concurrent.indexOf(promise);
          if (index > -1) concurrent.splice(index, 1);
        });
      concurrent.push(promise);
    }

    // Wait for at least one to complete
    if (concurrent.length > 0) {
      const result = await Promise.race(concurrent);
      results.push(result);
    }
  }

  return results;
}

/**
 * Main function to check and refresh admin avatars
 *
 * Detects avatars that are:
 * - Missing (undefined, empty, or "undefined" string)
 * - Broken (placeholder images)
 * - Stale (older than staleThreshold)
 *
 * @param {AvatarRefreshOptions} options - Refresh options
 * @returns {Promise<Object>} Refresh summary with results
 *
 * @example
 * // Check and refresh all tracked admins
 * const result = await refreshAdminAvatars();
 *
 * @example
 * // Refresh only stale avatars older than 1 hour
 * const result = await refreshAdminAvatars({ staleThreshold: 3600000 });
 *
 * @example
 * // Check without refreshing (dry run)
 * const result = await checkAvatarStatus();
 */
export async function refreshAdminAvatars(options = {}) {
  const opts = { ...DEFAULT_REFRESH_OPTIONS, ...options };
  const listType = opts.listType || 'tracked';
  const storageKey = listType === 'blacklist' ? 'blacklistedAdmins' : 'trackedAdmins';

  // Get all admins from the specified list
  const admins = await new Promise((resolve) => {
    chrome.storage.local.get([storageKey], (result) => {
      resolve(result[storageKey] || []);
    });
  });

  if (admins.length === 0) {
    return {
      success: true,
      checked: 0,
      refreshed: 0,
      skipped: 0,
      failed: 0,
      results: []
    };
  }

  // Process all admins
  const results = await refreshBatch(admins, opts, listType);

  // Summarize results
  const summary = {
    success: true,
    checked: admins.length,
    refreshed: 0,
    skipped: 0,
    placeholders: 0,
    failed: 0,
    results: results
  };

  results.forEach(({ result }) => {
    if (result.action === 'refreshed') summary.refreshed++;
    else if (result.action === 'skipped') summary.skipped++;
    else if (result.action === 'placeholder') summary.placeholders++;
    else if (result.action === 'failed') summary.failed++;
  });

  return summary;
}

/**
 * Check avatar status without refreshing (dry run)
 * @returns {Promise<Object>} Status summary
 */
export async function checkAvatarStatus() {
  const admins = await new Promise((resolve) => {
    chrome.storage.local.get(['trackedAdmins'], (result) => {
      resolve(result.trackedAdmins || []);
    });
  });

  const status = {
    total: admins.length,
    valid: 0,
    invalid: 0,
    stale: 0,
    placeholder: 0,
    details: []
  };

  admins.forEach(admin => {
    const username = admin.username || admin.userName || admin.screen_name;
    const avatar = admin.profileImage || admin.profilePicture || admin.profile_image_url_https;
    const isValid = isValidAvatarUrl(avatar);
    const isPlaceholder = avatar && avatar.includes('icon48.png');
    const stale = isAvatarStale(admin, DEFAULT_REFRESH_OPTIONS.staleThreshold);

    if (!isValid) status.invalid++;
    else if (isPlaceholder) status.placeholder++;
    else if (stale) status.stale++;
    else status.valid++;

    status.details.push({
      username,
      valid: isValid,
      placeholder: isPlaceholder,
      stale: stale && isValid,
      avatar
    });
  });

  return status;
}

/**
 * Setup image error handler for avatar elements
 * Automatically refreshes avatar on image load failure
 * @param {HTMLImageElement} imgElement - Image element to monitor
 * @param {string} username - Username for avatar refresh
 * @param {string} [listType='tracked'] - Which list to update ('tracked' or 'blacklist')
 */
export function setupAvatarErrorHandler(imgElement, username, listType = 'tracked') {
  const originalHandler = imgElement.onerror;
  const storageKey = listType === 'blacklist' ? 'blacklistedAdmins' : 'trackedAdmins';

  imgElement.onerror = async () => {
    console.log(`[AvatarRefresh] Avatar load failed for @${username} (${listType}), attempting refresh...`);

    try {
      const options = { ...DEFAULT_REFRESH_OPTIONS, listType };
      const result = await refreshAdminAvatar({ username }, options, listType);

      if (result.success && (result.action === 'refreshed' || result.action === 'placeholder')) {
        // Get updated admin data
        const admins = await new Promise((resolve) => {
          chrome.storage.local.get([storageKey], (result) => {
            resolve(result[storageKey] || []);
          });
        });

        const admin = admins.find(a => {
          const adminUsername = a.username || a.userName || a.screen_name;
          return adminUsername && adminUsername.toLowerCase() === username.toLowerCase();
        });

        if (admin) {
          const newAvatar = admin.profileImage || admin.profilePicture || admin.profile_image_url_https;
          if (newAvatar !== imgElement.src) {
            imgElement.src = newAvatar;
            console.log(`[AvatarRefresh] Avatar refreshed for @${username} (${listType})`);
          }
        }
      }
    } catch (error) {
      console.error(`[AvatarRefresh] Failed to refresh avatar for @${username} (${listType}):`, error);
    }

    // Fallback to placeholder
    imgElement.src = getPlaceholderAvatar();
    imgElement.removeAttribute('data-avatar-refresh-enabled');

    // Call original handler if exists
    if (originalHandler) {
      originalHandler.call(imgElement);
    }
  };

  imgElement.setAttribute('data-avatar-refresh-enabled', 'true');
}

/**
 * Clear refresh state (for testing or manual reset)
 */
export function clearRefreshState() {
  refreshState.pendingRequests.clear();
  refreshState.lastAttemptTime.clear();
  refreshState.failedAttempts.clear();
}

// Export for use in non-module contexts
if (typeof window !== 'undefined') {
  window.AvatarRefreshModule = {
    refreshAdminAvatars,
    checkAvatarStatus,
    setupAvatarErrorHandler,
    clearRefreshState
  };
}
