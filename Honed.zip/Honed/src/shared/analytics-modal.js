/**
 * Analytics Dashboard Modal
 * Displays tracked admin performance with key metrics
 */

// Guard against duplicate script loading
if (typeof window.AnalyticsModal !== 'undefined') {
  console.log('[AnalyticsModal] Already loaded, skipping...');
} else {

class AnalyticsModal {
  constructor() {
    this.backdrop = null;
    this.container = null;
    this.isOpen = false;
    this.allAdminsData = []; // Store all admin data

    // View state
    this.currentView = 'calendar'; // 'calendar' or 'day-detail'
    this.calendarCurrentMonth = new Date();
    this.selectedDate = null; // Store selected date for day detail view
    
    // Store bound listeners for cleanup
    this._boundListeners = [];
  }

  /**
   * Show modal
   */
  async show() {
    if (this.isOpen) {
      this.hide();
    }

    this.isOpen = true;

    // Create modal structure
    this._createModal();

    // Add to DOM
    document.body.appendChild(this.backdrop);
    document.body.classList.add('modal-open');

    // Listen for storage changes to auto-refresh when sheet data updates
    this.storageListenerBound = this._handleStorageChange.bind(this);
    chrome.storage.onChanged.addListener(this.storageListenerBound);

    // Load and render data
    await this._loadData();
  }

  /**
   * Hide modal
   */
  hide() {
    if (!this.isOpen) return;

    // Immediately disable pointer events on backdrop to prevent any further interactions
    if (this.backdrop) {
      this.backdrop.style.pointerEvents = 'none';
    }

    // Remove modal from DOM
    if (this.backdrop && this.backdrop.parentNode) {
      this.backdrop.parentNode.removeChild(this.backdrop);
    }

    document.body.classList.remove('modal-open');
    this.isOpen = false;
    this.backdrop = null;
    this.container = null;

    // Remove storage change listener
    if (this.storageListenerBound) {
      chrome.storage.onChanged.removeListener(this.storageListenerBound);
      this.storageListenerBound = null;
    }

    // Remove escape listener
    document.removeEventListener('keydown', this._handleEscape);
    
    // Remove all stored event listeners
    this._boundListeners.forEach(({ element, event, handler }) => {
      if (element && element.removeEventListener) {
        element.removeEventListener(event, handler);
      }
    });
    this._boundListeners = [];
  }

  /**
   * Handle storage changes - refresh modal data when sheet data updates
   * @private
   */
  _handleStorageChange(changes, areaName) {
    // Only care about local storage changes
    if (areaName !== 'local' || !this.isOpen) return;

    // Check if sheet data was updated
    if (changes.sheetsTokens || changes.sheetsAdmins) {
      // Refresh the data with current filters
      this._loadData().catch(err => {
        console.error('[AnalyticsModal] Failed to refresh data:', err);
      });
    }
  }

  /**
   * Create modal DOM structure
   * @private
   */
  _createModal() {
    // Create backdrop
    this.backdrop = document.createElement('div');
    this.backdrop.className = 'analytics-modal-backdrop';

    // Create container
    this.container = document.createElement('div');
    this.container.className = 'analytics-modal-container';

    // Store element reference for tab switching
    this.element = this.container;

    // Create close button
    const closeButton = document.createElement('button');
    closeButton.className = 'analytics-modal-close-button';
    closeButton.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`;
    closeButton.addEventListener('click', () => this.hide());

    // Create header
    const header = document.createElement('div');
    header.className = 'analytics-modal-header';
    header.innerHTML = `
      <div class="analytics-header-left">
        <div class="analytics-modal-title">Tracked Admins Analytics</div>
      </div>
      <div class="analytics-header-right">
        <div class="analytics-tabs">
          <button class="analytics-tab ${this.currentView === 'calendar' ? 'active' : ''}" data-view="calendar">Calendar</button>
        </div>
      </div>`;

    // Create content area with loading state
    const content = document.createElement('div');
    content.className = 'analytics-modal-content';
    content.innerHTML = `
      <div class="analytics-loading">
        <div class="analytics-spinner"></div>
        <div class="analytics-loading-text">Loading analytics...</div>
      </div>
    `;

    // Assemble modal
    this.container.appendChild(closeButton);
    this.container.appendChild(header);
    this.container.appendChild(content);
    this.backdrop.appendChild(this.container);

    // Add event listeners
    this.backdrop.addEventListener('click', (e) => {
      if (e.target === this.backdrop) {
        this.hide();
      }
    });

    document.addEventListener('keydown', this._handleEscape);
  }

  /**
   * Handle ESC key press
   * @private
   */
  _handleEscape = (e) => {
    if (e.key === 'Escape' && this.isOpen) {
      this.hide();
    }
  };

  /**
   * Store event listener for cleanup
   * @private
   */
  _storeListener(element, event, handler) {
    this._boundListeners.push({ element, event, handler });
  }

  /**
   * Load and render data
   * @private
   */
  async _loadData() {
    const content = this.container.querySelector('.analytics-modal-content');
    if (!content) return;

    try {
      // Fetch tracked admins and their stats
      const trackedAdmins = await this._getTrackedAdmins();
      this.allAdminsData = await this._getAdminsData(trackedAdmins);

      if (this.allAdminsData.length === 0) {
        this._renderEmptyState(content);
        return;
      }

      // Render analytics with all admin data
      this._renderAnalytics(content, this.allAdminsData);

    } catch (error) {
      console.error('[AnalyticsModal] Failed to load data:', error);
      this._renderError(content, error);
    }
  }

  /**
   * Get tracked admins from storage
   * @private
   */
  async _getTrackedAdmins() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['trackedAdmins'], (result) => {
        resolve(result.trackedAdmins || []);
      });
    });
  }

  /**
   * Get admins data with stats from sheets
   * @private
   */
  async _getAdminsData(trackedAdmins) {
    if (typeof SheetsData === 'undefined') return [];

    const adminsData = [];

    for (const admin of trackedAdmins) {
      const username = admin.username || admin.userName || admin.screen_name;
      if (!username) continue;

      const stats = await SheetsData.getAdminStats(username);
      if (stats) {
        adminsData.push({
          username,
          name: admin.name,
          profileImage: admin.profileImage,
          ...stats
        });
      }
    }

    // Sort by total rating (lower is better)
    return adminsData.sort((a, b) => (a.total_rating || 999) - (b.total_rating || 999));
  }

  /**
   * Calculate aggregate statistics
   * @private
   */
  _calculateStats(adminsData) {
    const totalAdmins = adminsData.length;
    const totalTokens = adminsData.reduce((sum, a) => sum + (a.total_tokens_created || 0), 0);

    // Average rating
    const avgRating = adminsData.reduce((sum, a) => sum + (a.total_rating || 0), 0) / totalAdmins;

    // Average winrate
    const avgWinrate = adminsData.reduce((sum, a) => sum + (a.winrate || 0), 0) / totalAdmins;

    // Success rate (tokens with score 0-1)
    const score0Tokens = adminsData.reduce((sum, a) => sum + (a.tokens_score_0 || 0), 0);
    const score1Tokens = adminsData.reduce((sum, a) => sum + (a.tokens_score_1 || 0), 0);
    const successTokens = score0Tokens + score1Tokens;
    const successRate = totalTokens > 0 ? successTokens / totalTokens : 0;

    // Failed tokens (Score 6) from Admin sheet
    const failedTokens = adminsData.reduce((sum, a) => sum + (a.tokens_score_6 || 0), 0);

    // Best and worst admins
    const bestAdmin = adminsData[0];
    const worstAdmin = adminsData[adminsData.length - 1];

    return {
      totalAdmins,
      totalTokens,
      avgRating,
      avgWinrate,
      successRate,
      successTokens,
      failedTokens,
      bestAdmin,
      worstAdmin
    };
  }

  /**
   * Render analytics content
   * @private
   */
  _renderAnalytics(content, adminsData) {
    const stats = this._calculateStats(adminsData);

    const avgRatingColor = this._getRatingColor(stats.avgRating);
    const avgWinrateColor = stats.avgWinrate >= 0.5 ? '#10b981' : stats.avgWinrate >= 0.3 ? '#fbbf24' : '#ef4444';
    const successRateColor = stats.successRate >= 0.5 ? '#10b981' : stats.successRate >= 0.3 ? '#fbbf24' : '#ef4444';

    content.innerHTML = `
      <!-- Calendar View -->
      <div class="analytics-content analytics-calendar-view ${this.currentView === 'calendar' ? 'active' : ''}">
        ${this._createCalendarView()}
      </div>

      <!-- Day Detail View -->
      <div class="analytics-content analytics-day-detail-view ${this.currentView === 'day-detail' ? 'active' : ''}">
        <div class="analytics-day-detail-loading">
          <div class="analytics-spinner"></div>
          <div class="analytics-loading-text">Loading day details...</div>
        </div>
      </div>
    `;

    // Attach event listeners for tab switching and calendar
    this._attachEventListeners();
  }

  /**
   * Attach event listeners for tabs and calendar
   * @private
   */
  _attachEventListeners() {
    const content = this.container.querySelector('.analytics-modal-content');
    if (!content) return;

    // Tab switching
    const tabs = this.element.querySelectorAll('.analytics-tab');
    tabs.forEach(tab => {
      const tabHandler = () => this._switchView(tab.dataset.view);
      tab.addEventListener('click', tabHandler);
      this._storeListener(tab, 'click', tabHandler);
    });
  }

  /**
   * Attach calendar event listeners
   * @private
   */
  _attachCalendarListeners() {
    const container = this.container;
    if (!container) return;

    // Calendar navigation buttons
    const navButtons = container.querySelectorAll('.analytics-calendar-nav-btn');
    navButtons.forEach(btn => {
      const navHandler = async (e) => {
        const nav = e.currentTarget.dataset.nav;
        if (nav === 'prev') {
          this.calendarCurrentMonth = new Date(this.calendarCurrentMonth.getFullYear(), this.calendarCurrentMonth.getMonth() - 1, 1);
        } else if (nav === 'next') {
          this.calendarCurrentMonth = new Date(this.calendarCurrentMonth.getFullYear(), this.calendarCurrentMonth.getMonth() + 1, 1);
        } else if (nav === 'today') {
          this.calendarCurrentMonth = new Date();
        }
        await this._renderCalendar();
      };
      btn.addEventListener('click', navHandler);
      this._storeListener(btn, 'click', navHandler);
    });

    // Calendar day click
    const dayCells = container.querySelectorAll('.analytics-calendar-day:not(.empty)');
    dayCells.forEach(cell => {
      const dayHandler = async (e) => {
        const date = cell.dataset.date;
        if (date) {
          const stat = await DailyStatsData.getStatsForDate(date);
          this._showDayDetail(date, stat, e);
        }
      };
      cell.addEventListener('click', dayHandler);
      this._storeListener(cell, 'click', dayHandler);
    });
  }

  /**
   * Attach calendar navigation listeners (called once when switching to calendar view)
   * @private
   */
  _attachCalendarNavigationListeners() {
    const container = this.container;
    if (!container) return;

    // Remove old listeners by cloning the navigation buttons
    const navButtons = container.querySelectorAll('.analytics-calendar-nav-btn');
    navButtons.forEach(btn => {
      // Clone and replace to remove old event listeners
      const newBtn = btn.cloneNode(true);
      btn.parentNode.replaceChild(newBtn, btn);

      // Add new event listener
      const navHandler = async (e) => {
        const nav = e.currentTarget.dataset.nav;
        if (nav === 'prev') {
          this.calendarCurrentMonth = new Date(this.calendarCurrentMonth.getFullYear(), this.calendarCurrentMonth.getMonth() - 1, 1);
        } else if (nav === 'next') {
          this.calendarCurrentMonth = new Date(this.calendarCurrentMonth.getFullYear(), this.calendarCurrentMonth.getMonth() + 1, 1);
        } else if (nav === 'today') {
          this.calendarCurrentMonth = new Date();
        }
        await this._renderCalendar();
      };
      newBtn.addEventListener('click', navHandler);
      this._storeListener(newBtn, 'click', navHandler);
    });
  }

  /**
   * Attach day cell click listeners (called each time calendar is rendered)
   * @private
   */
  _attachDayCellListeners() {
    const container = this.container;
    if (!container) return;

    // Calendar day click - these are dynamically created each render
    const dayCells = container.querySelectorAll('.analytics-calendar-day:not(.empty)');
    dayCells.forEach(cell => {
      const dayHandler = async (e) => {
        const date = cell.dataset.date;
        if (date) {
          const stat = await DailyStatsData.getStatsForDate(date);
          this._showDayDetail(date, stat, e);
        }
      };
      cell.addEventListener('click', dayHandler);
      this._storeListener(cell, 'click', dayHandler);
    });
  }

  /**
   * Show profile modal for clicked admin
   * @private
   */
  _showProfileModal(username, name) {
    // Create a simple inline profile card
    const existingModal = document.querySelector('.analytics-profile-modal');
    if (existingModal) {
      existingModal.remove();
    }

    const modal = document.createElement('div');
    modal.className = 'analytics-profile-modal';
    modal.innerHTML = `
      <div class="analytics-profile-backdrop"></div>
      <div class="analytics-profile-card">
        <button class="analytics-profile-close">&times;</button>
        <div class="analytics-profile-header">
          <img class="analytics-profile-avatar" src="">
          <div class="analytics-profile-info">
            <div class="analytics-profile-name">${name || '@' + username}</div>
            <div class="analytics-profile-username">@${username}</div>
          </div>
        </div>
        <div class="analytics-profile-stats">
          <div class="analytics-profile-stat">
            <div class="analytics-profile-stat-label">Total Tokens</div>
            <div class="analytics-profile-stat-value" id="profile-tokens">-</div>
          </div>
          <div class="analytics-profile-stat">
            <div class="analytics-profile-stat-label">Win Rate</div>
            <div class="analytics-profile-stat-value" id="profile-winrate">-</div>
          </div>
          <div class="analytics-profile-stat">
            <div class="analytics-profile-stat-label">Score</div>
            <div class="analytics-profile-stat-value" id="profile-score">-</div>
          </div>
        </div>
        <div class="analytics-profile-scores">
          <div class="analytics-profile-scores-title">Score Distribution</div>
          <div class="analytics-profile-scores-grid" id="profile-scores-grid"></div>
        </div>
        <div class="analytics-profile-actions">
          <a href="https://twitter.com/${username}" target="_blank" class="analytics-profile-btn">Open Twitter Profile</a>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    // Find admin data
    const admin = this.allAdminsData.find(a => a.username.toLowerCase() === username.toLowerCase());

    if (admin) {
      const avatar = modal.querySelector('.analytics-profile-avatar');
      avatar.src = admin.profileImage || 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23666%22><circle cx=%2212%22 cy=%228%22 r=%224%22/><path d=%22M12 14c-4.42 0-8 1.79-8 4v2h16v-2c0-2.21-3.58-4-8-4z%22/></svg>';

      modal.querySelector('#profile-tokens').textContent = admin.total_tokens_created || 0;
      modal.querySelector('#profile-winrate').textContent = (admin.winrate * 100).toFixed(0) + '%';

      const scoreData = SheetsData ? SheetsData.formatScore(admin.total_rating) : { formatted: 'N/A', color: '#888' };
      const scoreEl = modal.querySelector('#profile-score');
      scoreEl.textContent = scoreData.formatted;
      scoreEl.style.color = scoreData.color;

      // Score distribution
      const scoresGrid = modal.querySelector('#profile-scores-grid');
      scoresGrid.innerHTML = `
        ${[0,1,2,3,4,5].map(score => {
          const count = admin[`tokens_score_${score}`] || 0;
          if (count === 0) return '';
          return `<div class="profile-score-item profile-score-${score}"><span class="profile-score-num">${score}</span><span class="profile-score-count">${count}</span></div>`;
        }).join('')}
      `;
    }

    // Close handlers
    const closeBtn = modal.querySelector('.analytics-profile-close');
    const backdrop = modal.querySelector('.analytics-profile-backdrop');

    const close = () => modal.remove();
    closeBtn.addEventListener('click', close);
    backdrop.addEventListener('click', close);
  }

  /**
   * Switch between calendar and day-detail view
   * @private
   */
  _switchView(view) {
    this.currentView = view;

    // Update tab buttons
    const tabs = this.element.querySelectorAll('.analytics-tab');
    tabs.forEach(tab => {
      tab.classList.toggle('active', tab.dataset.view === view);
    });

    // Update view containers
    const contentDivs = this.container.querySelectorAll('.analytics-content');
    contentDivs.forEach(content => {
      content.classList.remove('active');
    });

    if (view === 'calendar') {
      this.container.querySelector('.analytics-calendar-view').classList.add('active');
      this._renderCalendar();
      // Attach navigation listeners only once (they persist across renders)
      this._attachCalendarNavigationListeners();
    } else if (view === 'day-detail') {
      this.container.querySelector('.analytics-day-detail-view').classList.add('active');
      this._renderDayDetail();
    }
  }

  /**
   * Create calendar view HTML
   * @private
   */
  _createCalendarView() {
    return `
      <div class="analytics-calendar-header">
        <div class="analytics-calendar-title">
          <span id="calendarTitle">January 2025</span>
        </div>
        <div class="analytics-calendar-nav">
          <button class="analytics-calendar-nav-btn" data-nav="prev">← Previous</button>
          <button class="analytics-calendar-nav-btn" data-nav="today">Today</button>
          <button class="analytics-calendar-nav-btn" data-nav="next">Next →</button>
        </div>
      </div>

      <div class="analytics-calendar-day-headers">
        <div class="analytics-calendar-day-header">Sun</div>
        <div class="analytics-calendar-day-header">Mon</div>
        <div class="analytics-calendar-day-header">Tue</div>
        <div class="analytics-calendar-day-header">Wed</div>
        <div class="analytics-calendar-day-header">Thu</div>
        <div class="analytics-calendar-day-header">Fri</div>
        <div class="analytics-calendar-day-header">Sat</div>
      </div>

      <div class="analytics-calendar-grid" id="calendarGrid">
        <!-- Calendar days will be rendered here -->
      </div>

      <div class="analytics-calendar-legend">
        <div class="analytics-calendar-legend-item">
          <div class="analytics-calendar-legend-color excellent"></div>
          <span>Excellent (0-1.0)</span>
        </div>
        <div class="analytics-calendar-legend-item">
          <div class="analytics-calendar-legend-color good"></div>
          <span>Good (1.0-1.8)</span>
        </div>
        <div class="analytics-calendar-legend-item">
          <div class="analytics-calendar-legend-color fair"></div>
          <span>Fair (1.8-2.6)</span>
        </div>
        <div class="analytics-calendar-legend-item">
          <div class="analytics-calendar-legend-color mixed"></div>
          <span>Mixed (2.6-3.4)</span>
        </div>
        <div class="analytics-calendar-legend-item">
          <div class="analytics-calendar-legend-color poor"></div>
          <span>Poor (3.4-4.2)</span>
        </div>
        <div class="analytics-calendar-legend-item">
          <div class="analytics-calendar-legend-color bad"></div>
          <span>Bad (4.2+)</span>
        </div>
      </div>
    `;
  }

  /**
   * Render calendar for current month
   * @private
   */
  async _renderCalendar() {
    const dailyStats = await DailyStatsData.getAllStats();
    const statsByDate = {};
    dailyStats.forEach(stat => {
      statsByDate[stat.date] = stat;
    });

    const year = this.calendarCurrentMonth.getFullYear();
    const month = this.calendarCurrentMonth.getMonth();

    // Update title
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                        'July', 'August', 'September', 'October', 'November', 'December'];
    const titleEl = document.getElementById('calendarTitle');
    if (titleEl) {
      titleEl.textContent = `${monthNames[month]} ${year}`;
    }

    // Get first day of month and number of days
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    // Build calendar grid
    const grid = document.getElementById('calendarGrid');
    if (!grid) return;

    grid.innerHTML = '';

    // Empty cells for days before first of month
    for (let i = 0; i < firstDay; i++) {
      const emptyCell = document.createElement('div');
      emptyCell.className = 'analytics-calendar-day empty';
      grid.appendChild(emptyCell);
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const stat = statsByDate[date];

      const dayCell = document.createElement('div');
      dayCell.className = 'analytics-calendar-day';
      dayCell.dataset.date = date;

      if (stat) {
        const colorInfo = DailyStatsData.getScoreColor(stat.avg_score);
        dayCell.classList.add(colorInfo.class);

        dayCell.innerHTML = `
          <div class="analytics-calendar-day-number">${day}</div>
          <div class="analytics-calendar-day-stats">
            <div class="analytics-calendar-day-tokens">${stat.tokens_created} tokens</div>
            <div class="analytics-calendar-day-avg">${stat.avg_score.toFixed(1)} avg</div>
          </div>
          <div class="analytics-calendar-day-score"></div>
        `;
      } else {
        dayCell.innerHTML = `
          <div class="analytics-calendar-day-number">${day}</div>
          <div class="analytics-calendar-day-stats">No data</div>
        `;
      }

      grid.appendChild(dayCell);
    }

    // Attach day cell listeners (dynamically created cells need new listeners each render)
    this._attachDayCellListeners();
  }

  /**
   * Show day detail view
   * @private
   */
  async _showDayDetail(date, stat, clickEvent) {
    if (!stat) return;

    this.selectedDate = date;
    this._switchView('day-detail');
  }

  /**
   * Render day detail view
   * @private
   */
  async _renderDayDetail() {
    const content = this.container.querySelector('.analytics-day-detail-view');
    if (!content || !this.selectedDate) return;

    // Get daily stats for the selected date
    const stat = await DailyStatsData.getStatsForDate(this.selectedDate);

    if (!stat) {
      content.innerHTML = `
        <div class="analytics-day-detail-full">
          <div class="analytics-day-detail-full-header">
            <button class="analytics-day-detail-back-btn" id="dayDetailBackBtn">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
              </svg>
              Back to Calendar
            </button>
          </div>
          <div class="analytics-empty">
            <div class="analytics-empty-icon">No Data</div>
            <div class="analytics-empty-title">No Data Available</div>
            <div class="analytics-empty-desc">No stats found for this date</div>
          </div>
        </div>
      `;
      content.querySelector('#dayDetailBackBtn').addEventListener('click', () => {
        this._switchView('calendar');
      });
      return;
    }

    // Get all tokens for this date
    const allTokens = await this._getAllTokensForDate(this.selectedDate);

    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const dateObj = new Date(this.selectedDate);
    const formattedDate = `${monthNames[dateObj.getMonth()]} ${dateObj.getDate()}, ${dateObj.getFullYear()}`;

    const colorInfo = DailyStatsData.getScoreColor(stat.avg_score);
    const totalTokens = stat.tokens_created || 0;
    const winRate = (stat.win_rate * 100).toFixed(1);

    // Build top tokens HTML
    const topTokens = [];
    for (let i = 1; i <= 3; i++) {
      const address = stat[`token_${i}_address`];
      const score = stat[`token_${i}_score`];
      const ath = stat[`token_${i}_ath`];
      if (address && score !== null) {
        const tokenColorInfo = DailyStatsData.getScoreColor(score);
        topTokens.push(`
          <div class="day-detail-top-token">
            <div class="day-detail-token-header">
              <span class="day-detail-token-address" title="${address}">${address.substring(0, 20)}...</span>
              <button class="day-detail-copy-btn" data-address="${address}" title="Copy address">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
              </button>
            </div>
            <div class="day-detail-token-metrics">
              <span class="day-detail-token-score" style="background: ${tokenColorInfo.color}20; color: ${tokenColorInfo.color};">${score}</span>
              <span class="day-detail-token-ath">ATH: $${ath.toLocaleString()}</span>
            </div>
          </div>
        `);
      }
    }

    // Get tracked admins to find profile pictures
    const trackedAdmins = await this._getTrackedAdmins();

    content.innerHTML = `
      <div class="analytics-day-detail-full">
        <div class="analytics-day-detail-full-header">
          <button class="analytics-day-detail-back-btn" id="dayDetailBackBtn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Back to Calendar
          </button>
          <div class="analytics-day-detail-title">${formattedDate}</div>
        </div>

        <!-- Daily Summary Stats -->
        <div class="day-detail-summary">
          <div class="day-detail-metric">
            <div class="day-detail-metric-label">Tokens Created</div>
            <div class="day-detail-metric-value">${stat.tokens_created}</div>
          </div>
          <div class="day-detail-metric">
            <div class="day-detail-metric-label">Avg Score</div>
            <div class="day-detail-metric-value" style="color: ${colorInfo.color}">${stat.avg_score.toFixed(2)}</div>
          </div>
          <div class="day-detail-metric">
            <div class="day-detail-metric-label">Win Rate</div>
            <div class="day-detail-metric-value" style="color: ${stat.win_rate >= 0.5 ? '#10b981' : stat.win_rate >= 0.3 ? '#fbbf24' : '#ef4444'}">${winRate}%</div>
          </div>
          <div class="day-detail-metric">
            <div class="day-detail-metric-label">Good Tokens (0-2)</div>
            <div class="day-detail-metric-value">${stat.good_tokens_0_2}</div>
          </div>
        </div>

        <!-- Top Admin Section -->
        ${stat.top_admin ? `
          <div class="day-detail-top-admin">
            <div class="day-detail-admin-badge">
              <span class="day-detail-admin-label">Top Performer</span>
              <span class="day-detail-admin-score" style="background: ${colorInfo.color}20; color: ${colorInfo.color};">
                ${stat.top_admin_avg_score.toFixed(2)} avg
              </span>
            </div>
            <div class="day-detail-admin-card">
              <img class="day-detail-admin-avatar" src="${this._getAdminProfileImage(stat.top_admin, trackedAdmins)}" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23666%22><circle cx=%2212%22 cy=%228%22 r=%224%22/><path d=%22M12 14c-4.42 0-8 1.79-8 4v2h16v-2c0-2.21-3.58-4-8-4z%22/></svg>'">
              <div class="day-detail-admin-info">
                <div class="day-detail-admin-name">@${stat.top_admin}</div>
                <div class="day-detail-admin-stats">${stat.top_admin_tokens} tokens created</div>
              </div>
            </div>
          </div>
        ` : ''}

        <!-- Top 3 Tokens by ATH -->
        ${topTokens.length > 0 ? `
          <div class="day-detail-section">
            <div class="day-detail-section-title">Top 3 Tokens by All-Time High</div>
            <div class="day-detail-top-tokens">${topTokens.join('')}</div>
          </div>
        ` : ''}

        <!-- All Tokens List -->
        <div class="day-detail-section">
          <div class="day-detail-section-title">All Tokens (${allTokens.length})</div>
          <div class="day-detail-tokens-list" id="dayDetailTokensList">
            <div class="analytics-date-tokens-loading">
              <div class="analytics-spinner"></div>
            </div>
          </div>
        </div>
      </div>
    `;

    // Attach back button listener
    content.querySelector('#dayDetailBackBtn').addEventListener('click', () => {
      this._switchView('calendar');
    });

    // Attach copy button listeners
    content.querySelectorAll('.day-detail-copy-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const address = btn.dataset.address;
        navigator.clipboard.writeText(address).then(() => {
          const originalHTML = btn.innerHTML;
          btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" width="14" height="14"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
          setTimeout(() => {
            btn.innerHTML = originalHTML;
          }, 1500);
        });
      });
    });

    // Render all tokens
    await this._renderAllTokensList(allTokens, trackedAdmins);
  }

  /**
   * Render all tokens list in day detail view
   * @private
   */
  async _renderAllTokensList(allTokens, trackedAdmins) {
    const listContainer = document.getElementById('dayDetailTokensList');
    if (!listContainer) return;

    if (allTokens.length === 0) {
      listContainer.innerHTML = `
        <div class="analytics-empty">
          <div class="analytics-empty-desc">No tokens found for this date</div>
        </div>
      `;
      return;
    }

    // Get top 20 tokens by ATH
    const topTokens = [...allTokens]
      .sort((a, b) => {
        const athA = typeof a.ath_market_cap === 'number' ? a.ath_market_cap : 0;
        const athB = typeof b.ath_market_cap === 'number' ? b.ath_market_cap : 0;
        return athB - athA;
      })
      .slice(0, 20);

    // Group tokens by admin
    const tokensByAdmin = {};
    for (const token of topTokens) {
      const admin = token.admin_username || 'unknown';
      if (!tokensByAdmin[admin]) {
        tokensByAdmin[admin] = [];
      }
      tokensByAdmin[admin].push(token);
    }

    let tokensHtml = '';
    for (const [admin, tokens] of Object.entries(tokensByAdmin)) {
      const adminProfileImage = this._getAdminProfileImage(admin, trackedAdmins);
      const adminScore = tokens.reduce((sum, t) => sum + (t.token_score || 0), 0) / tokens.length;
      const adminColorInfo = DailyStatsData.getScoreColor(adminScore);

      tokensHtml += `
        <div class="day-detail-admin-tokens">
          <div class="day-detail-admin-tokens-header" style="background: rgba(34, 211, 238, 0.08); border-left: 3px solid ${adminColorInfo.color};">
            <img class="day-detail-admin-avatar-small" src="${adminProfileImage}" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23666%22><circle cx=%2212%22 cy=%228%22 r=%224%22/><path d=%22M12 14c-4.42 0-8 1.79-8 4v2h16v-2c0-2.21-3.58-4-8-4z%22/></svg>'">
            <span class="day-detail-admin-name-small">@${admin}</span>
            <span class="day-detail-admin-count">${tokens.length} tokens</span>
          </div>
          <div class="day-detail-admin-tokens-list">
      `;

      // Sort tokens by ATH descending
      const sortedTokens = [...tokens].sort((a, b) => {
        const athA = typeof a.ath_market_cap === 'number' ? a.ath_market_cap : 0;
        const athB = typeof b.ath_market_cap === 'number' ? b.ath_market_cap : 0;
        return athB - athA;
      });

      for (const token of sortedTokens) {
        const score = token.token_score ?? 0;
        const scoreColorInfo = DailyStatsData.getScoreColor(score);
        const ath = typeof token.ath_market_cap === 'number' ? token.ath_market_cap : 0;
        const currentMc = typeof token.market_cap === 'number' ? token.market_cap : 0;
        const tokenImage = this._getTokenImage(token);

        tokensHtml += `
          <div class="day-detail-token-card">
            <div class="day-detail-token-left">
              <img class="day-detail-token-image" src="${tokenImage}" data-token-address="${token.base_token}" onerror="this._handleTokenImageError(this)">
              <div class="day-detail-token-info">
                <div class="day-detail-token-symbol">${token.token_symbol || 'N/A'}</div>
                <div class="day-detail-token-name">${token.token_name || 'Unknown'}</div>
                <div class="day-detail-token-address-small">${token.base_token?.substring(0, 10)}...</div>
              </div>
            </div>
            <div class="day-detail-token-right">
              <div class="day-detail-token-score-badge" style="background: ${scoreColorInfo.color}20; color: ${scoreColorInfo.color};">
                ${score}
              </div>
              <div class="day-detail-token-ath">ATH: $${ath.toLocaleString()}</div>
              <button class="day-detail-copy-icon-btn" data-address="${token.base_token}" title="Copy address">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
              </button>
            </div>
          </div>
        `;
      }

      tokensHtml += `
          </div>
        </div>
      `;
    }

    listContainer.innerHTML = tokensHtml;

    // Attach copy button listeners for all tokens
    listContainer.querySelectorAll('.day-detail-copy-icon-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const address = btn.dataset.address;
        navigator.clipboard.writeText(address).then(() => {
          btn.style.color = '#10b981';
          setTimeout(() => {
            btn.style.color = '';
          }, 1500);
        });
      });
    });

    // Fetch token images from MevX API
    this._fetchTokenImagesFromMevX(topTokens);
  }

  /**
   * Fetch token images from MevX API
   * @private
   */
  async _fetchTokenImagesFromMevX(tokens) {
    if (typeof MevxApiClient === 'undefined') return;

    const mevxClient = new MevxApiClient();
    const tokenAddresses = tokens.map(t => t.base_token).filter(a => a);

    const results = await mevxClient.fetchBatchTokens(tokenAddresses);

    // Update token images with MevX data
    results.forEach((data, address) => {
      if (data && data.logo) {
        const imgEl = document.querySelector(`img[data-token-address="${address}"]`);
        if (imgEl) {
          imgEl.src = data.logo;
        }
      }
    });
  }

  /**
   * Handle token image error (fallback to MevX or default)
   * @private
   */
  async _handleTokenImageError(imgElement) {
    const tokenAddress = imgElement.dataset.tokenAddress;
    if (!tokenAddress) return;

    // Try fetching from MevX
    if (typeof MevxApiClient !== 'undefined') {
      try {
        const mevxClient = new MevxApiClient();
        const data = await mevxClient.fetchTokenDetails(tokenAddress);
        if (data && data.logo) {
          imgElement.src = data.logo;
          return;
        }
      } catch (e) {
        console.log('[AnalyticsModal] Failed to fetch MevX image for', tokenAddress);
      }
    }

    // Fallback to default
    imgElement.src = 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23444%22><circle cx=%2212%22 cy=%2212%22 r=%2210%22/><text x=%2250%%25%22 y=%2250%%25%22 text-anchor=%22middle%22 dy=%22.3em%22 fill=%22%23888%22 font-size=%2212%22>\$</text></svg>';
  }

  /**
   * Get admin profile image from tracked admins
   * @private
   */
  _getAdminProfileImage(username, trackedAdmins) {
    const admin = trackedAdmins.find(a =>
      (a.username || '').toLowerCase() === username.toLowerCase() ||
      (a.userName || '').toLowerCase() === username.toLowerCase() ||
      (a.screen_name || '').toLowerCase() === username.toLowerCase()
    );
    return admin?.profileImage || 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23666%22><circle cx=%2212%22 cy=%228%22 r=%224%22/><path d=%22M12 14c-4.42 0-8 1.79-8 4v2h16v-2c0-2.21-3.58-4-8-4z%22/></svg>';
  }

  /**
   * Get token image
   * @private
   */
  _getTokenImage(token) {
    // Try to construct a token image URL from various sources
    if (token.token_image) {
      return token.token_image;
    }
    // You could add logic to fetch token images from DexScreener or other APIs
    return 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23444%22><circle cx=%2212%22 cy=%2212%22 r=%2210%22/><text x=%2250%%25%22 y=%2250%%25%22 text-anchor=%22middle%22 dy=%22.3em%22 fill=%22%23888%22 font-size=%2212%22>\$</text></svg>';
  }

  /**
   * View all tokens created on a specific date
   * @private
   */
  async _viewTokensForDate(date) {
    // Show a modal with all tokens created on this date
    const allTokens = await this._getAllTokensForDate(date);

    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const dateObj = new Date(date);
    const formattedDate = `${monthNames[dateObj.getMonth()]} ${dateObj.getDate()}, ${dateObj.getFullYear()}`;

    // Create tokens modal
    const existingModal = document.querySelector('.analytics-date-tokens-modal');
    if (existingModal) {
      existingModal.remove();
    }

    const modal = document.createElement('div');
    modal.className = 'analytics-date-tokens-modal';
    modal.innerHTML = `
      <div class="analytics-date-tokens-backdrop"></div>
      <div class="analytics-date-tokens-card">
        <div class="analytics-date-tokens-header">
          <div class="analytics-date-tokens-title">Tokens from ${formattedDate}</div>
          <button class="analytics-date-tokens-close">&times;</button>
        </div>
        <div class="analytics-date-tokens-content" id="dateTokensContent">
          <div class="analytics-date-tokens-loading">
            <div class="analytics-spinner"></div>
            <div class="analytics-loading-text">Loading tokens...</div>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    // Populate tokens
    const contentEl = modal.querySelector('#dateTokensContent');
    if (allTokens.length === 0) {
      contentEl.innerHTML = `
        <div class="analytics-date-tokens-empty">
          <div class="analytics-empty-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="48" height="48">
              <rect x="3" y="3" width="18" height="18" rx="2"/>
              <line x1="3" y1="9" x2="21" y2="9"/>
              <line x1="9" y1="21" x2="9" y2="9"/>
            </svg>
          </div>
          <div class="analytics-empty-title">No Tokens Found</div>
          <div class="analytics-empty-desc">No tokens were created on ${formattedDate}</div>
        </div>
      `;
    } else {
      // Group tokens by admin
      const tokensByAdmin = {};
      for (const token of allTokens) {
        const admin = token.admin_username || 'unknown';
        if (!tokensByAdmin[admin]) {
          tokensByAdmin[admin] = [];
        }
        tokensByAdmin[admin].push(token);
      }

      let tokensHtml = '';
      for (const [admin, tokens] of Object.entries(tokensByAdmin)) {
        const adminColorInfo = DailyStatsData.getScoreColor(
          tokens.reduce((sum, t) => sum + (t.token_score || 0), 0) / tokens.length
        );

        tokensHtml += `
          <div class="analytics-date-admin-section">
            <div class="analytics-date-admin-header">
              <span class="analytics-date-admin-name">@${admin}</span>
              <span class="analytics-date-admin-count">${tokens.length} tokens</span>
            </div>
            <div class="analytics-date-tokens-list">
        `;

        // Sort tokens by ATH descending
        const sortedTokens = [...tokens].sort((a, b) => {
          const athA = typeof a.ath_market_cap === 'number' ? a.ath_market_cap : 0;
          const athB = typeof b.ath_market_cap === 'number' ? b.ath_market_cap : 0;
          return athB - athA;
        });

        for (const token of sortedTokens) {
          const score = token.token_score || 0;
          const scoreColorInfo = DailyStatsData.getScoreColor(score);
          const ath = typeof token.ath_market_cap === 'number' ? token.ath_market_cap : 0;
          const currentMc = typeof token.market_cap === 'number' ? token.market_cap : 0;

          tokensHtml += `
            <div class="analytics-date-token-item">
              <div class="analytics-date-token-info">
                <div class="analytics-date-token-symbol">${token.token_symbol || 'N/A'}</div>
                <div class="analytics-date-token-name">${token.token_name || 'Unknown Token'}</div>
              </div>
              <div class="analytics-date-token-metrics">
                <div class="analytics-date-token-score" style="background: ${scoreColorInfo.color}20; color: ${scoreColorInfo.color};">
                  ${score}
                </div>
                <div class="analytics-date-token-ath">ATH: $${ath.toLocaleString()}</div>
                <div class="analytics-date-token-mc">MC: $${currentMc.toLocaleString()}</div>
              </div>
              ${token.community_link ? `
                <a href="${token.community_link}" target="_blank" class="analytics-date-token-link">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </a>
              ` : ''}
            </div>
          `;
        }

        tokensHtml += `
            </div>
          </div>
        `;
      }

      contentEl.innerHTML = `
        <div class="analytics-date-tokens-summary">
          <div class="analytics-date-tokens-summary-stat">
            <span class="analytics-date-tokens-summary-label">Total Tokens</span>
            <span class="analytics-date-tokens-summary-value">${allTokens.length}</span>
          </div>
        </div>
        ${tokensHtml}
      `;
    }

    // Close handlers
    const closeBtn = modal.querySelector('.analytics-date-tokens-close');
    const backdrop = modal.querySelector('.analytics-date-tokens-backdrop');

    const close = () => modal.remove();
    closeBtn.addEventListener('click', close);
    backdrop.addEventListener('click', close);
    modal.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') close();
    });
  }

  /**
   * Get all tokens for a specific date
   * @private
   */
  async _getAllTokensForDate(date) {
    // Get all tokens from IndexedDB
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { action: 'getAllTokens' },
        (response) => {
          if (response?.success && response.tokens) {
            // Filter tokens by creation date
            const targetTokens = [];
            const targetDateStr = date; // YYYY-MM-DD format

            for (const [username, tokenList] of Object.entries(response.tokens)) {
              for (const token of tokenList) {
              // Try to use created_at timestamp if available (Unix timestamp in seconds)
              let tokenDateStr = null;

              if (token.created_at) {
                // created_at is a Unix timestamp in seconds
                const createdAt = typeof token.created_at === 'string'
                  ? parseInt(token.created_at, 10)
                  : token.created_at;

                // Check if it's in seconds (Unix timestamp) or milliseconds (JavaScript timestamp)
                // Unix timestamps are typically around 1.7 billion for 2024, JS timestamps are much larger
                const timestamp = createdAt > 10000000000 ? createdAt : createdAt * 1000;
                const creationDate = new Date(timestamp);
                tokenDateStr = creationDate.toISOString().split('T')[0];
              } else {
                // Fallback to parsing token_age (e.g., "24d ago")
                const tokenAge = token.token_age || '';
                if (!tokenAge) continue;

                let creationDate = null;
                if (tokenAge.includes('d')) {
                  const days = parseInt(tokenAge) || 0;
                  creationDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
                } else if (tokenAge.includes('h')) {
                  const hours = parseInt(tokenAge) || 0;
                  creationDate = new Date(Date.now() - hours * 60 * 60 * 1000);
                } else if (tokenAge.includes('m')) {
                  const minutes = parseInt(tokenAge) || 0;
                  creationDate = new Date(Date.now() - minutes * 60 * 1000);
                }

                if (creationDate) {
                  tokenDateStr = creationDate.toISOString().split('T')[0];
                }
              }

              if (tokenDateStr === targetDateStr) {
                targetTokens.push(token);
              }
            }
            }

            resolve(targetTokens);
          } else {
            resolve([]);
          }
        }
      );
    });
  }

  /**
   * Get color for rating value
   * @private
   */
  _getRatingColor(rating) {
    const r = parseFloat(rating) || 0;
    if (r <= 1.5) return '#10b981';
    if (r <= 2.5) return '#22d3ee';
    if (r <= 3.5) return '#fbbf24';
    return '#ef4444';
  }

  /**
   * Create score distribution bars for ranking table
   * @private
   */
  _createScoreDistributionBars(admin) {
    const totalTokens = (admin.tokens_score_0 || 0) + (admin.tokens_score_1 || 0) +
                        (admin.tokens_score_2 || 0) + (admin.tokens_score_3 || 0) +
                        (admin.tokens_score_4 || 0) + (admin.tokens_score_5 || 0) +
                        (admin.tokens_score_6 || 0);

    if (totalTokens === 0) return '<span class="analytics-no-data">-</span>';

    return `
      <div class="dist-grid">
        ${[0,1,2,3,4,5].map(score => {
          const count = admin[`tokens_score_${score}`] || 0;
          return `
            <div class="dist-cell dist-cell-${score}">
              <span class="dist-cell-score">${score}</span>
              <div class="dist-cell-divider"></div>
              <span class="dist-cell-count">${count}</span>
            </div>
          `;
        }).join('')}
      </div>
    `;
  }

  /**
   * Render empty state
   * @private
   */
  _renderEmptyState(content) {
    content.innerHTML = `
      <div class="analytics-empty">
        <div class="analytics-empty-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="48" height="48">
            <rect x="3" y="3" width="18" height="18" rx="2"/>
            <line x1="3" y1="9" x2="21" y2="9"/>
            <line x1="9" y1="21" x2="9" y2="9"/>
          </svg>
        </div>
        <div class="analytics-empty-title">No Tracked Admins</div>
        <div class="analytics-empty-desc">Start tracking admins to see analytics here.<br>Click the star icon on any admin card to track them.</div>
      </div>
    `;
  }

  /**
   * Render error state
   * @private
   */
  _renderError(content, error) {
    content.innerHTML = `
      <div class="analytics-error">
        <div class="analytics-error-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="40" height="40">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
            <line x1="12" y1="9" x2="12" y2="13"/>
            <line x1="12" y1="17" x2="12.01" y2="17"/>
          </svg>
        </div>
        <div class="analytics-error-title">Failed to Load Analytics</div>
        <div class="analytics-error-desc">${this._escapeHtml(error.message)}</div>
      </div>
    `;
  }

  /**
   * Format number for display
   * @private
   */
  _formatNumber(num) {
    const number = parseInt(num) || 0;
    if (number >= 1000000) {
      return (number / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    }
    if (number >= 1000) {
      return (number / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
    }
    return number.toString();
  }

  /**
   * Escape HTML to prevent XSS
   * @private
   */
  _escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Export for use in content scripts
if (typeof window !== 'undefined') {
  window.AnalyticsModal = AnalyticsModal;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = AnalyticsModal;
}

} // End of duplicate load guard
