/**
 * IndexedDB Storage Layer for Honed Extension
 * Replaces chrome.storage.local for large datasets with no quota limits
 *
 * Stores:
 * - admin_stats (from Google Sheets Admins)
 * - comments (from Google Sheets Comments)
 * - api_cache (Twitter API cache: community, user profiles, MEVX tokens)
 */

const DB_NAME = 'HonedExtensionDB';
const DB_VERSION = 4;

// Store names
const STORES = {
  ADMIN_STATS: 'admin_stats',
  TOKENS: 'tokens',
  API_CACHE: 'api_cache',
  METADATA: 'metadata',
  DAILY_STATS: 'daily_stats'
};

/**
 * IndexedDB wrapper class
 */
class IndexedDBStorage {
  constructor() {
    this.db = null;
    this.initPromise = null;
    this.deduplicationRunning = false;
  }

  /**
   * Initialize the database
   */
  async init() {
    if (this.initPromise) {
      return this.initPromise;
    }

    this.initPromise = this._initInternal();
    return this.initPromise;
  }

  async _initInternal() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => {
        console.error('[IndexedDB] Open failed:', request.error);
        reject(request.error);
      };

      request.onsuccess = async () => {
        this.db = request.result;
        console.log('[IndexedDB] Initialized successfully');

        // NON-BLOCKING: Schedule deduplication in background
        this._scheduleDeduplication();

        // Resolve immediately - don't wait for deduplication
        resolve(this.db);
      };

      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        // Create admin_stats store (keyed by username)
        if (!db.objectStoreNames.contains(STORES.ADMIN_STATS)) {
          const adminStatsStore = db.createObjectStore(STORES.ADMIN_STATS, { keyPath: 'username' });
          adminStatsStore.createIndex('admin_username', 'admin_username', { unique: false });
        }

        // Create tokens store (keyed by composite key: username_tokenSymbol)
        if (!db.objectStoreNames.contains(STORES.TOKENS)) {
          const tokensStore = db.createObjectStore(STORES.TOKENS, { keyPath: 'id', autoIncrement: true });
          tokensStore.createIndex('admin_username', 'admin_username', { unique: false });
          tokensStore.createIndex('token_symbol', 'token_symbol', { unique: false });
          tokensStore.createIndex('base_token', 'base_token', { unique: false });
          tokensStore.createIndex('created_at', 'created_at', { unique: false });
        }

        // Create api_cache store (keyed by cache_key)
        if (!db.objectStoreNames.contains(STORES.API_CACHE)) {
          const cacheStore = db.createObjectStore(STORES.API_CACHE, { keyPath: 'cache_key' });
          cacheStore.createIndex('cache_type', 'cache_type', { unique: false });
          cacheStore.createIndex('expires_at', 'expires_at', { unique: false });
        }

        // Create metadata store
        if (!db.objectStoreNames.contains(STORES.METADATA)) {
          db.createObjectStore(STORES.METADATA, { keyPath: 'key' });
        }

        // Create daily_stats store (keyed by date)
        if (!db.objectStoreNames.contains(STORES.DAILY_STATS)) {
          const dailyStatsStore = db.createObjectStore(STORES.DAILY_STATS, { keyPath: 'date' });
          dailyStatsStore.createIndex('tokens_created', 'tokens_created', { unique: false });
          dailyStatsStore.createIndex('avg_score', 'avg_score', { unique: false });
          dailyStatsStore.createIndex('win_rate', 'win_rate', { unique: false });
        }

        console.log('[IndexedDB] Schema created');
      };
    });
  }

  /**
   * Helper to get a transaction and store
   */
  _getStore(storeName, mode = 'readonly') {
    if (!this.db) {
      throw new Error('Database not initialized. Call init() first.');
    }
    const transaction = this.db.transaction([storeName], mode);
    return transaction.objectStore(storeName);
  }

  /**
   * Helper to promisify a request
   */
  _promisify(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  // =========================================================================
  // Admin Stats Operations (replaces sheetsAdmins)
  // =========================================================================

  /**
   * Batch upsert admin stats
   * @param {Object} admins - Object mapping username -> admin data
   */
  async setAdminStats(admins) {
    await this.init();
    const store = this._getStore(STORES.ADMIN_STATS, 'readwrite');

    // Use a single transaction for all operations
    const promises = [];

    for (const [username, data] of Object.entries(admins)) {
      const record = {
        username: username.toLowerCase(),
        ...data,
        updated_at: Date.now()
      };
      const request = store.put(record);
      promises.push(this._promisify(request));
    }

    await Promise.all(promises);
    console.log(`[IndexedDB] Set ${Object.keys(admins).length} admin stats`);
  }

  /**
   * Get single admin stats by username
   */
  async getAdminStats(username) {
    await this.init();
    const store = this._getStore(STORES.ADMIN_STATS);
    const request = store.get(username.toLowerCase());
    return await this._promisify(request);
  }

  /**
   * Get all admin stats
   * Returns object keyed by username (for compatibility with existing code)
   */
  async getAllAdminStats() {
    await this.init();
    const store = this._getStore(STORES.ADMIN_STATS);
    const request = store.getAll();
    const results = await this._promisify(request);

    // Convert array to object keyed by username
    const admins = {};
    for (const row of results) {
      admins[row.username] = row;
    }
    return admins;
  }

  /**
   * Clear all admin stats
   */
  async clearAdminStats() {
    await this.init();
    const store = this._getStore(STORES.ADMIN_STATS, 'readwrite');
    const request = store.clear();
    await this._promisify(request);
    console.log('[IndexedDB] Cleared admin stats');
  }

  // =========================================================================
  // Comments Operations (replaces sheetsComments)
  // =========================================================================

  /**
   * Batch upsert comments
   * @param {Object} comments - Object mapping username -> array of comments
   */
  // =========================================================================
  // Tokens Operations (stores all tokens from Google Sheets)
  // =========================================================================

  /**
   * Set tokens for admins (clears existing and replaces)
   * Use this for full sync only - for incremental updates use upsertTokens()
   * @param {Object} tokens - Object mapping username -> array of tokens
   */
  async setTokens(tokens) {
    await this.init();

    // Use a single transaction for both clear and add operations
    const transaction = this.db.transaction([STORES.TOKENS], 'readwrite');
    const store = transaction.objectStore(STORES.TOKENS);

    // Clear existing tokens first (within the same transaction)
    const clearRequest = store.clear();
    await this._promisify(clearRequest);

    // Insert all tokens (within the same transaction)
    const promises = [];
    for (const [username, tokenList] of Object.entries(tokens)) {
      for (const token of tokenList) {
        const record = {
          ...token,
          admin_username: (token.admin_username || username).toLowerCase()
        };
        const request = store.add(record);
        promises.push(this._promisify(request));
      }
    }

    // Wait for all add operations to complete
    await Promise.all(promises);

    // Wait for transaction to complete
    await new Promise((resolve, reject) => {
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error);
    });

    console.log(`[IndexedDB] Set tokens for ${Object.keys(tokens).length} admins`);
  }

  /**
   * Upsert tokens - updates existing tokens and adds new ones
   * More efficient than setTokens for incremental updates
   * @param {Object} tokens - Object mapping username -> array of tokens
   * @param {Object} options - Options { deleteMissing: true } - whether to delete tokens not in the update
   * @returns {Object} Stats about the upsert operation
   */
  async upsertTokens(tokens, options = {}) {
    const { deleteMissing = true } = options;
    await this.init();

    const transaction = this.db.transaction([STORES.TOKENS], 'readwrite');
    const store = transaction.objectStore(STORES.TOKENS);
    const adminUsernameIndex = store.index('admin_username');
    const baseTokenIndex = store.index('base_token');

    let updated = 0;
    let added = 0;
    let deleted = 0;

    // Track seen base tokens for each admin to detect deletions
    const seenTokens = new Map(); // username -> Set of base_token

    // First, collect all existing tokens for the affected admins
    const adminUsernames = Object.keys(tokens);
    const existingTokensByAdmin = new Map();

    for (const username of adminUsernames) {
      const existing = await new Promise((resolve, reject) => {
        const request = adminUsernameIndex.openCursor(IDBKeyRange.only(username.toLowerCase()));
        const results = [];
        request.onsuccess = (event) => {
          const cursor = event.target.result;
          if (cursor) {
            results.push(cursor.value);
            cursor.continue();
          } else {
            resolve(results);
          }
        };
        request.onerror = () => reject(request.error);
      });
      // Map by base_token for O(1) lookup
      existingTokensByAdmin.set(username, new Map(existing.map(t => [t.base_token, t])));
      seenTokens.set(username, new Set());
    }

    // Upsert each token
    const putPromises = [];
    const deletePromises = [];

    for (const [username, tokenList] of Object.entries(tokens)) {
      const existingMap = existingTokensByAdmin.get(username) || new Map();
      const seenSet = seenTokens.get(username);

      for (const token of tokenList) {
        seenSet.add(token.base_token);

        // Check if this token exists by base_token (the unique identifier)
        const existingToken = existingMap.get(token.base_token);

        if (existingToken) {
          // Update existing token - preserve the id to avoid duplicates
          const record = {
            ...token,
            id: existingToken.id,  // Preserve the existing id
            admin_username: (token.admin_username || username).toLowerCase()
          };
          const request = store.put(record);
          putPromises.push(this._promisify(request));
          updated++;
        } else {
          // Add new token - let IndexedDB auto-generate the id
          const record = {
            ...token,
            admin_username: (token.admin_username || username).toLowerCase()
          };
          const request = store.add(record);
          putPromises.push(this._promisify(request));
          added++;
        }
      }

      // Delete tokens that no longer exist (only if deleteMissing is true)
      if (deleteMissing) {
        for (const [baseToken, existingToken] of existingMap) {
          if (!seenSet.has(baseToken)) {
            // Delete by id (primary key)
            const deleteRequest = store.delete(existingToken.id);
            deletePromises.push(this._promisify(deleteRequest));
            deleted++;
          }
        }
      }
    }

    await Promise.all([...putPromises, ...deletePromises]);

    // Wait for transaction to complete
    await new Promise((resolve, reject) => {
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error);
    });

    const stats = { added, updated, deleted, total: added + updated };
    console.log(`[IndexedDB] Upserted tokens (deleteMissing=${deleteMissing}): ${added} added, ${updated} updated, ${deleted} deleted`);
    return stats;
  }

  /**
   * Upsert tokens for a single admin
   * @param {string} username - Admin username
   * @param {Array} tokens - Array of token objects
   */
  async upsertAdminTokens(username, tokens) {
    return this.upsertTokens({ [username]: tokens });
  }

  /**
   * Deduplicate tokens - removes duplicate tokens (same admin_username + base_token)
   * Keeps the most recent token (based on id, which is roughly insertion order)
   * @returns {Object} Stats about deduplication { duplicatesRemoved, totalRemaining }
   */
  async deduplicateTokens() {
    await this.init();
    return this._deduplicateTokensInternal();
  }

  /**
   * Internal deduplication method - assumes database is already initialized
   * @private
   * @returns {Object} Stats about deduplication { duplicatesRemoved, totalRemaining }
   */
  async _deduplicateTokensInternal() {
    const transaction = this.db.transaction([STORES.TOKENS], 'readwrite');
    const store = transaction.objectStore(STORES.TOKENS);

    // Get all tokens
    const allTokens = await new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });

    // Group tokens by admin_username + base_token
    const tokenGroups = new Map();
    for (const token of allTokens) {
      const key = `${token.admin_username}:${token.base_token}`;
      if (!tokenGroups.has(key)) {
        tokenGroups.set(key, []);
      }
      tokenGroups.get(key).push(token);
    }

    // Find duplicates (groups with more than 1 token)
    let duplicatesRemoved = 0;
    const idsToDelete = [];

    for (const [key, tokens] of tokenGroups) {
      if (tokens.length > 1) {
        // Sort by id descending (most recent first) and keep the first one
        tokens.sort((a, b) => (b.id || 0) - (a.id || 0));
        const toKeep = tokens[0];
        const toDelete = tokens.slice(1);

        // Log what's being removed for debugging
        const adminName = toKeep.admin_username || 'unknown';
        console.log(`[IndexedDB] Dedup: Found ${tokens.length} duplicates for ${adminName}:${toKeep.base_token?.slice(0, 8)}... keeping id=${toKeep.id} (score=${toKeep.token_score}), removing ${toDelete.map(t => `id=${t.id}(score=${t.token_score})`).join(', ')}`);

        for (const token of toDelete) {
          idsToDelete.push(token.id);
          duplicatesRemoved++;
        }
      }
    }

    // Delete duplicates
    for (const id of idsToDelete) {
      store.delete(id);
    }

    // Wait for transaction to complete
    await new Promise((resolve, reject) => {
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error);
    });

    const totalRemaining = allTokens.length - duplicatesRemoved;
    console.log(`[IndexedDB] Deduplicated tokens: removed ${duplicatesRemoved} duplicates, ${totalRemaining} remaining`);
    return { duplicatesRemoved, totalRemaining };
  }

  /**
   * Schedule deduplication to run after 2 seconds
   * Skips if already running or ran within last hour
   * @private
   */
  _scheduleDeduplication() {
    if (this.deduplicationRunning || !this.db) return;

    // Wait 2 seconds to let critical operations complete
    setTimeout(() => {
      this._performAsyncDeduplication();
    }, 2000);
  }

  /**
   * Perform async deduplication with rate limiting
   * Skips if ran within last hour
   * @private
   */
  async _performAsyncDeduplication() {
    if (this.deduplicationRunning || !this.db) return;

    this.deduplicationRunning = true;

    try {
      // Check if deduplication recently ran (skip if < 1 hour ago)
      const lastDedup = await this.getMetadata('lastDeduplicationTime');
      const oneHourAgo = Date.now() - 3600000;

      if (lastDedup && lastDedup > oneHourAgo) {
        const minutesSinceLastRun = Math.round((Date.now() - lastDedup) / 60000);
        console.log(`[IndexedDB] Deduplication skipped (ran ${minutesSinceLastRun} minutes ago)`);
        return;
      }

      console.log('[IndexedDB] Starting async deduplication...');
      const result = await this._deduplicateTokensInternal();

      if (result.duplicatesRemoved > 0) {
        console.log(`[IndexedDB] Cleaned up ${result.duplicatesRemoved} duplicates (async)`);
      } else {
        console.log('[IndexedDB] No duplicates found (async)');
      }

      // Mark completion time
      await this.setMetadata('lastDeduplicationTime', Date.now());

    } catch (err) {
      console.error('[IndexedDB] Async deduplication failed:', err);
      // Don't fail - this is non-critical
    } finally {
      this.deduplicationRunning = false;
    }
  }

  /**
   * Get tokens for a specific admin
   * PERFORMANCE: Uses cursor with limit to avoid fetching all tokens unnecessarily
   * @param {string} username - Admin username
   * @param {number} limit - Maximum tokens to fetch (default: 50)
   */
  async getTokens(username, limit = 50) {
    await this.init();
    const store = this._getStore(STORES.TOKENS);
    const index = store.index('admin_username');

    const results = [];
    await new Promise((resolve, reject) => {
      const request = index.openCursor(IDBKeyRange.only(username.toLowerCase()));

      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor && results.length < limit) {
          results.push(cursor.value);
          cursor.continue();
        } else {
          resolve();
        }
      };
      request.onerror = () => reject(request.error);
    });

    console.log(`[IndexedDB] getTokens for "${username.toLowerCase()}": found ${results.length} tokens (limit: ${limit})`);
    return results;
  }

  /**
   * Get all tokens keyed by username (for compatibility)
   */
  async getAllTokens() {
    await this.init();
    const store = this._getStore(STORES.TOKENS);
    const request = store.getAll();
    const results = await this._promisify(request);

    // Convert to object keyed by username
    const tokens = {};
    for (const row of results) {
      const username = row.admin_username.toLowerCase();
      if (!tokens[username]) {
        tokens[username] = [];
      }
      tokens[username].push(row);
    }

    console.log(`[IndexedDB] getAllTokens: ${results.length} total tokens for ${Object.keys(tokens).length} admins`);
    return tokens;
  }

  /**
   * Clear all tokens
   */
  async clearTokens() {
    await this.init();
    const store = this._getStore(STORES.TOKENS, 'readwrite');
    const request = store.clear();
    await this._promisify(request);
    console.log('[IndexedDB] Cleared tokens');
  }

  // =========================================================================
  // Daily Stats Operations
  // =========================================================================

  /**
   * Set daily stats (clears existing and replaces)
   * @param {Array} dailyStats - Array of daily stats objects
   */
  async setDailyStats(dailyStats) {
    await this.init();
    const transaction = this.db.transaction([STORES.DAILY_STATS], 'readwrite');
    const store = transaction.objectStore(STORES.DAILY_STATS);

    const clearRequest = store.clear();
    await this._promisify(clearRequest);

    const promises = [];
    for (const stat of dailyStats) {
      const request = store.put(stat);
      promises.push(this._promisify(request));
    }

    await Promise.all(promises);
    console.log(`[IndexedDB] Set ${dailyStats.length} daily stats`);
  }

  /**
   * Get daily stats for a specific date
   * @param {string} date - Date in YYYY-MM-DD format
   */
  async getDailyStats(date) {
    await this.init();
    const store = this._getStore(STORES.DAILY_STATS);
    const request = store.get(date);
    return await this._promisify(request);
  }

  /**
   * Get all daily stats
   * @returns {Array} Array of daily stats objects
   */
  async getAllDailyStats() {
    await this.init();
    const store = this._getStore(STORES.DAILY_STATS);
    const request = store.getAll();
    return await this._promisify(request);
  }

  // =========================================================================
  // API Cache Operations (replaces chrome.storage.local cache)
  // =========================================================================

  /**
   * Set cache value with optional expiration
   * @param {string} key - Cache key
   * @param {any} value - Value to cache
   * @param {number} ttlSeconds - Time to live in seconds (null = no expiration)
   * @param {string} cacheType - Type of cache (community, user_profile, mevx_token, etc.)
   */
  async setCache(key, value, ttlSeconds = null, cacheType = 'default') {
    await this.init();
    const store = this._getStore(STORES.API_CACHE, 'readwrite');

    const record = {
      cache_key: key,
      cache_type: cacheType,
      value: JSON.stringify(value),
      expires_at: ttlSeconds ? Date.now() + (ttlSeconds * 1000) : null,
      created_at: Date.now()
    };

    const request = store.put(record);
    await this._promisify(request);
  }

  /**
   * Get cache value
   */
  async getCache(key) {
    await this.init();
    const store = this._getStore(STORES.API_CACHE);
    const request = store.get(key);
    const result = await this._promisify(request);

    if (!result) return null;

    // Check expiration
    if (result.expires_at && result.expires_at < Date.now()) {
      // Expired, delete and return null
      await this.deleteCache(key);
      return null;
    }

    return JSON.parse(result.value);
  }

  /**
   * Delete cache entry
   */
  async deleteCache(key) {
    await this.init();
    const store = this._getStore(STORES.API_CACHE, 'readwrite');
    const request = store.delete(key);
    await this._promisify(request);
  }

  /**
   * Clear expired cache entries
   */
  async clearExpiredCache() {
    await this.init();
    const store = this._getStore(STORES.API_CACHE, 'readwrite');
    const index = store.index('expires_at');
    const request = index.openCursor(IDBKeyRange.upperBound(Date.now()));

    const deletes = [];
    await new Promise((resolve, reject) => {
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor) {
          deletes.push(cursor.delete());
          cursor.continue();
        } else {
          resolve();
        }
      };
      request.onerror = () => reject(request.error);
    });

    await Promise.all(deletes);
    console.log(`[IndexedDB] Cleared ${deletes.length} expired cache entries`);
  }

  /**
   * Clear all cache entries (or by type)
   */
  async clearCache(cacheType = null) {
    await this.init();
    const store = this._getStore(STORES.API_CACHE, 'readwrite');

    if (cacheType) {
      const index = store.index('cache_type');
      const request = index.openCursor(IDBKeyRange.only(cacheType));

      const deletes = [];
      await new Promise((resolve, reject) => {
        request.onsuccess = (event) => {
          const cursor = event.target.result;
          if (cursor) {
            deletes.push(cursor.delete());
            cursor.continue();
          } else {
            resolve();
          }
        };
        request.onerror = () => reject(request.error);
      });

      await Promise.all(deletes);
      console.log(`[IndexedDB] Cleared ${deletes.length} cache entries (type: ${cacheType})`);
    } else {
      const request = store.clear();
      await this._promisify(request);
      console.log('[IndexedDB] Cleared all cache');
    }
  }

  // =========================================================================
  // Metadata Operations
  // =========================================================================

  /**
   * Set metadata value
   */
  async setMetadata(key, value) {
    await this.init();
    const store = this._getStore(STORES.METADATA, 'readwrite');
    const request = store.put({ key, value });
    await this._promisify(request);
  }

  /**
   * Get metadata value
   */
  async getMetadata(key) {
    await this.init();
    const store = this._getStore(STORES.METADATA);
    const request = store.get(key);
    const result = await this._promisify(request);
    return result ? result.value : null;
  }

  /**
   * Set last sync timestamp
   */
  async setLastSyncTime(timestamp = Date.now()) {
    await this.setMetadata('sheetsLastSync', timestamp);
  }

  /**
   * Get last sync timestamp
   */
  async getLastSyncTime() {
    return await this.getMetadata('sheetsLastSync');
  }

  // =========================================================================
  // Utility Methods
  // =========================================================================

  /**
   * Get database statistics
   */
  async getStats() {
    await this.init();

    const stats = {
      admin_stats: 0,
      tokens: 0,
      api_cache: 0,
      daily_stats: 0
    };

    stats.admin_stats = await this._countStore(STORES.ADMIN_STATS);
    stats.tokens = await this._countStore(STORES.TOKENS);
    stats.api_cache = await this._countStore(STORES.API_CACHE);
    stats.daily_stats = await this._countStore(STORES.DAILY_STATS);

    return stats;
  }

  /**
   * Count records in a store
   */
  async _countStore(storeName) {
    const store = this._getStore(storeName);
    const request = store.count();
    return await this._promisify(request);
  }

  /**
   * Clear all data (for testing/debugging)
   */
  async clearAll() {
    await this.init();

    for (const storeName of Object.values(STORES)) {
      const store = this._getStore(storeName, 'readwrite');
      const request = store.clear();
      await this._promisify(request);
    }

    console.log('[IndexedDB] Cleared all data');
  }

  /**
   * Close database connection
   */
  close() {
    if (this.db) {
      this.db.close();
      this.db = null;
      this.initPromise = null;
    }
  }
}

// Export singleton instance
const storage = new IndexedDBStorage();

// ES module export
export { storage, IndexedDBStorage, STORES };

// Make available globally for non-module scripts
if (typeof window !== 'undefined') {
  window.IndexedDBStorage = IndexedDBStorage;
  window.indexedDBStorage = storage;

  // Simple debug function that logs stats
  window.honedDebug = async () => {
    try {
      await storage.init();
      const stats = await storage.getStats();
      console.log('%c[Honed Debug] IndexedDB Stats:', 'color: #4ade80; font-weight: bold');
      console.table(stats);
      console.log('%cAdmin stats sample (first 3):', 'color: #60a5fa');
      const admins = await storage.getAllAdminStats();
      const sampleAdmins = Object.values(admins).slice(0, 3);
      console.table(sampleAdmins);
      return stats;
    } catch (err) {
      console.error('Honed debug error:', err);
    }
  };
  console.log('%c[Honed] Type honedDebug() to see IndexedDB stats', 'color: #fbbf24');
}
