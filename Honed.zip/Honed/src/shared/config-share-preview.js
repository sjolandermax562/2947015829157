// Config Share Preview Module

// API URL - using the same Vercel API as the rest of the extension
function getApiUrl() {
  return 'https://2947015829157.vercel.app/api';
}

// Toast notification helper (defined locally since popup.js has its own)
function showToast(message, type = 'success') {
  // Remove existing toast
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  // Create toast element
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  // Remove after delay
  setTimeout(() => {
    toast.classList.add('hiding');
    toast.addEventListener('animationend', () => toast.remove());
  }, 3000);
}

export class ConfigSharePreview {
  constructor(configId) {
    this.configId = configId;
    this.overlay = null;
    this.modal = null;
    this.isVisible = false;
    this.configData = null;
  }

  async show() {
    if (this.isVisible) return;
    this.isVisible = true;

    this.createOverlay();
    document.body.appendChild(this.overlay);
    this.overlay.classList.add('active');

    await this.loadConfig();
  }

  hide() {
    if (!this.isVisible) return;
    this.isVisible = false;
    this.overlay.classList.remove('active');
    setTimeout(() => {
      if (this.overlay && this.overlay.parentNode) {
        this.overlay.parentNode.removeChild(this.overlay);
      }
      this.overlay = null;
      this.modal = null;
    }, 200);
  }

  createOverlay() {
    this.overlay = document.createElement('div');
    this.overlay.className = 'config-share-overlay';
    this.overlay.innerHTML = this.getModalHTML();

    this.modal = this.overlay.querySelector('.config-share-modal');
    this.modal.classList.add('config-share-preview-modal');

    // Add event listeners
    const closeBtn = this.overlay.querySelector('.config-share-close');
    closeBtn.addEventListener('click', () => this.hide());

    this.overlay.addEventListener('click', (e) => {
      if (e.target === this.overlay) {
        this.hide();
      }
    });

    // Close on Escape key
    this.escapeHandler = (e) => {
      if (e.key === 'Escape') {
        this.hide();
      }
    };
    document.addEventListener('keydown', this.escapeHandler);
  }

  getModalHTML() {
    return `
      <div class="config-share-modal config-share-preview-modal">
        <div class="config-share-header">
          <h2>Config Preview</h2>
          <button class="config-share-close">&times;</button>
        </div>
        <div class="config-share-body" id="configPreviewBody">
          <div class="config-share-loading">
            <div class="config-share-spinner"></div>
            <div class="config-share-loading-text">Loading config...</div>
          </div>
        </div>
        <div class="config-share-footer" id="configPreviewFooter" style="display: none;">
          <button class="config-share-btn config-share-btn-primary config-share-btn-full" id="copyConfigBtn">
            Copy This Config
          </button>
        </div>
      </div>
    `;
  }

  async loadConfig() {
    const body = this.overlay.querySelector('#configPreviewBody');

    try {
      const response = await fetch(`${getApiUrl()}/config-share?action=preview&id=${this.configId}`);

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Failed to load config');
      }

      this.configData = result.config;
      this.renderConfig();

    } catch (error) {
      console.error('Load config error:', error);
      body.innerHTML = `
        <div class="config-share-empty">
          <div class="config-share-empty-text">Failed to load config</div>
          <div class="config-share-empty-subtext">${error.message}</div>
        </div>
      `;
    }
  }

  renderConfig() {
    const body = this.overlay.querySelector('#configPreviewBody');
    const footer = this.overlay.querySelector('#configPreviewFooter');
    const config = this.configData;
    const data = config.config_data || {};
    const settings = data.settings || {};

    const date = new Date(config.created_at).toLocaleDateString();
    const profileCache = data.adminProfileCache || {};

    // Build HTML
    let html = `
      <div class="config-share-preview-header">
        <h3 class="config-share-preview-title">${this.escapeHtml(config.display_name || 'Unnamed Config')}</h3>
        ${config.description ? `<p class="config-share-preview-description">${this.escapeHtml(config.description)}</p>` : ''}
        <div class="config-share-preview-meta">
          <span>${config.admins_count || 0} admins</span>
          <span>${config.tweets_count || 0} tweets</span>
          <span>${config.blacklist_count || 0} blacklist</span>
          <span>${config.copy_count || 0} copies</span>
          <span>${config.view_count || 0} views</span>
          <span>Created ${date}</span>
        </div>
      </div>
    `;

    // Settings section
    html += `
      <div class="config-share-preview-section">
        <h4 class="config-share-preview-section-title">Settings</h4>
        <div class="config-share-preview-settings">
          ${this.renderSetting('Detect X Community', settings.detectXCommunity)}
          ${this.renderSetting('Admin Alert Sound', settings.adminAlertSound)}
          ${this.renderSetting('Show Admin Info', settings.showAdminInfo)}
        </div>
      </div>
    `;

    // Admins section
    const adminsList = settings.adminAlertsList || [];
    html += `
      <div class="config-share-preview-section">
        <h4 class="config-share-preview-section-title">
          Admins <span class="count">${adminsList.length}</span>
        </h4>
        ${adminsList.length > 0 ? this.renderAdminsList(adminsList, profileCache) : '<p style="color: #8899a6; font-size: 14px;">No admins</p>'}
      </div>
    `;

    // Tweets section
    const tweetsList = settings.trackedTweetsList || [];
    html += `
      <div class="config-share-preview-section">
        <h4 class="config-share-preview-section-title">
          Tracked Tweets <span class="count">${tweetsList.length}</span>
        </h4>
        ${tweetsList.length > 0 ? this.renderTweetsList(tweetsList) : '<p style="color: #8899a6; font-size: 14px;">No tracked tweets</p>'}
      </div>
    `;

    // Blacklist section
    const blacklistList = settings.adminBlacklistList || [];
    html += `
      <div class="config-share-preview-section">
        <h4 class="config-share-preview-section-title">
          Blacklist <span class="count">${blacklistList.length}</span>
        </h4>
        ${blacklistList.length > 0 ? this.renderBlacklistList(blacklistList, profileCache) : '<p style="color: #8899a6; font-size: 14px;">No blacklisted users</p>'}
      </div>
    `;

    body.innerHTML = html;

    // Show copy button only for public configs
    if (config.is_public) {
      footer.style.display = 'flex';
      const copyBtn = footer.querySelector('#copyConfigBtn');
      copyBtn.addEventListener('click', () => this.copyConfig());
    }
  }

  renderSetting(label, value) {
    const valueClass = value ? 'enabled' : 'disabled';
    const valueText = value ? 'Enabled' : 'Disabled';
    return `
      <div class="config-share-preview-setting-row">
        <span class="config-share-preview-setting-label">${label}</span>
        <span class="config-share-preview-setting-value ${valueClass}">${valueText}</span>
      </div>
    `;
  }

  renderAdminsList(adminsList, profileCache) {
    let html = '<div class="config-share-preview-list">';

    adminsList.forEach(admin => {
      const profile = profileCache[admin.username] || {};
      const profilePic = admin.profileImage || profile.profileImage || '';
      const followersCount = admin.followersCount || profile.followersCount || 0;
      const name = admin.name || profile.name || admin.username;
      const description = admin.description || profile.description || '';

      html += `
        <div class="config-share-preview-item">
          ${profilePic ? `
            <img src="${this.escapeHtml(profilePic)}" alt="" class="config-share-preview-avatar">
          ` : `
            <div class="config-share-preview-avatar" style="display: flex; align-items: center; justify-content: center; font-size: 16px;">
              @${this.escapeHtml(admin.username.charAt(0).toUpperCase())}
            </div>
          `}
          <div class="config-share-preview-item-content">
            <div class="config-share-preview-item-name">${this.escapeHtml(name)}</div>
            <div class="config-share-preview-item-username">@${this.escapeHtml(admin.username)}</div>
            ${description ? `<div style="font-size: 12px; color: #8899a6; margin-top: 4px;">${this.escapeHtml(description.substring(0, 100))}${description.length > 100 ? '...' : ''}</div>` : ''}
          </div>
          <div class="config-share-preview-item-meta">
            ${this.formatNumber(followersCount)} followers
          </div>
        </div>
      `;
    });

    html += '</div>';
    return html;
  }

  renderTweetsList(tweetsList) {
    let html = '<div class="config-share-preview-list">';

    tweetsList.forEach(tweet => {
      html += `
        <div class="config-share-preview-tweet">
          <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
            <strong>@${this.escapeHtml(tweet.username || 'unknown')}</strong>
            <span style="color: #8899a6; font-size: 12px;">${this.formatNumber(tweet.likes || 0)} likes</span>
          </div>
          ${tweet.content ? `<div>${this.escapeHtml(tweet.content)}</div>` : ''}
        </div>
      `;
    });

    html += '</div>';
    return html;
  }

  renderBlacklistList(blacklistList, profileCache) {
    let html = '<div class="config-share-preview-list">';

    blacklistList.forEach(entry => {
      const username = typeof entry === 'string' ? entry : entry.username;
      const profile = profileCache[username] || {};

      html += `
        <div class="config-share-preview-item">
          <div class="config-share-preview-avatar" style="display: flex; align-items: center; justify-content: center; background: #f4212e; font-size: 16px;">
            🚫
          </div>
          <div class="config-share-preview-item-content">
            <div class="config-share-preview-item-name">@${this.escapeHtml(username)}</div>
            ${profile.name ? `<div class="config-share-preview-item-username">${this.escapeHtml(profile.name)}</div>` : ''}
          </div>
        </div>
      `;
    });

    html += '</div>';
    return html;
  }

  async copyConfig() {
    const confirmed = await this.showConfirmDialog(
      'Copy Config',
      'This will replace your current config with the copied one. Are you sure?'
    );

    if (!confirmed) return;

    try {
      const response = await fetch(`${getApiUrl()}/config-share?action=copy&id=${this.configId}`, {
        method: 'POST'
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Failed to copy config');
      }

      // Import the config data
      await this.importConfig(result.configData);

      showToast('Config copied successfully!', 'success');
      this.hide();

    } catch (error) {
      console.error('Copy config error:', error);
      showToast(error.message || 'Failed to copy config', 'error');
    }
  }

  async importConfig(configData) {
    const settings = configData?.settings || {};

    // Import visual settings to chrome.storage.sync (color pickers, toggles, sliders)
    const syncSettings = {
      xCommunityEnabled: settings.detectXCommunity,
      showAdminInfo: settings.showAdminInfo,
      showMemberPreview: settings.showMemberPreview,
      showFollowerCount: settings.showFollowerCount,
      adminBackgroundEnabled: settings.adminBackgroundEnabled,
      normalAdminColor: settings.normalAdminColor,
      trackedGradientEnabled: settings.trackedGradientEnabled,
      trackedBorderColor: settings.trackedBorderColor,
      trackedGradientColor: settings.trackedGradientColor,
      trackedGradientOpacity: settings.trackedGradientOpacity,
      tweetsGradientEnabled: settings.tweetsGradientEnabled,
      tweetsShowOverlay: settings.tweetsShowOverlay,
      tweetsBorderColor: settings.tweetsBorderColor,
      tweetsGradientColor: settings.tweetsGradientColor,
      tweetsGradientOpacity: settings.tweetsGradientOpacity,
      adminAlertEnabled: settings.adminAlertSound,
      adminAlertVolume: settings.adminAlertVolume,
      adminAlertCustomSound: settings.adminAlertCustomSound,
      communityVerificationEnabled: settings.communityVerificationEnabled,
      showQuickStatsPopup: settings.showQuickStatsPopup,
      scoreAlertBorderColor: settings.scoreAlertBorderColor,
      scoreAlertGradientColor: settings.scoreAlertGradientColor,
      scoreAlertGradientOpacity: settings.scoreAlertGradientOpacity,
      scoreAlertGradientEnabled: settings.scoreAlertGradientEnabled
    };

    // Remove undefined values
    Object.keys(syncSettings).forEach(key => {
      if (syncSettings[key] === undefined) {
        delete syncSettings[key];
      }
    });

    // Import lists and cache to chrome.storage.local
    const localData = {
      trackedAdmins: settings.adminAlertsList || [],
      blacklistedAdmins: settings.adminBlacklistList || [],
      trackedTweets: settings.trackedTweetsList || [],
      blacklistedTweets: settings.blacklistedTweetsList || [],
      adminProfileCache: configData.adminProfileCache || {}
    };

    // First save to sync storage (settings)
    await new Promise((resolve, reject) => {
      chrome.storage.sync.set(syncSettings, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });

    // Then save to local storage (lists and cache)
    await new Promise((resolve, reject) => {
      chrome.storage.local.set(localData, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
  }

  showConfirmDialog(title, message) {
    return new Promise((resolve) => {
      const overlay = document.createElement('div');
      overlay.className = 'config-share-dialog-overlay';
      overlay.innerHTML = `
        <div class="config-share-dialog">
          <h3 class="config-share-dialog-title">${title}</h3>
          <p class="config-share-dialog-message">${message}</p>
          <div class="config-share-dialog-actions">
            <button class="config-share-btn config-share-btn-secondary" data-action="cancel">Cancel</button>
            <button class="config-share-btn config-share-btn-primary" data-action="confirm">Confirm</button>
          </div>
        </div>
      `;

      document.body.appendChild(overlay);

      requestAnimationFrame(() => {
        overlay.classList.add('active');
      });

      const closeDialog = () => {
        overlay.classList.remove('active');
        setTimeout(() => {
          if (overlay.parentNode) {
            overlay.parentNode.removeChild(overlay);
          }
        }, 200);
      };

      overlay.querySelector('[data-action="cancel"]').addEventListener('click', () => {
        closeDialog();
        resolve(false);
      });

      overlay.querySelector('[data-action="confirm"]').addEventListener('click', () => {
        closeDialog();
        resolve(true);
      });

      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          closeDialog();
          resolve(false);
        }
      });
    });
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  formatNumber(num) {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  }
}
