/**
 * Unified API Client
 * Centralized API access with automatic caching and request deduplication
 * Uses IndexedDB for caching (no quota limits)
 */

class ApiClient {
  constructor() {
    // Use Vercel APIs to hide the API key (optimized endpoints for smaller payloads)
    this.baseUrl = 'https://2947015829157.vercel.app/api/twitter-optimized';
    this.communityBaseUrl = 'https://2947015829157.vercel.app/api/community-optimized';
    // Direct API URL (fallback disabled for security - API key removed)
    this.directBaseUrl = 'https://api.twitterapi.io/twitter';
    // SECURITY: API key removed - all requests must go through Vercel proxy

    // In-flight request deduplication
    this.pendingRequests = new Map();
    
    // Request timeout (10 seconds)
    this.requestTimeout = 10000;

    // Cache statistics
    this.stats = {
      community: { hits: 0, misses: 0 },
      user: { hits: 0, misses: 0 },
      deduplicated: 0
    };

    // ============================================
    // PERFORMANCE: Cache TTL configuration
    // Different data types have appropriate cache durations
    // ============================================
    this.cacheTTLs = {
      community: 3600,      // 1 hour - community data rarely changes
      user_profile: 900,    // 15 minutes - user profiles change moderately
      mevx_token: 300       // 5 minutes - token data is time-sensitive
    };

    // IndexedDB storage reference (set when available)
    this.db = null;

    // Try to get the global indexedDBStorage (window for content scripts, self for service workers)
    const globalStorage = typeof window !== 'undefined' && window.indexedDBStorage
                        || typeof self !== 'undefined' && self.indexedDBStorage;

    if (globalStorage) {
      this.db = globalStorage;
    }
  }

  /**
   * Ensure DB is initialized before use
   * PERFORMANCE: Caches init promise to prevent redundant initialization
   */
  async _ensureDB() {
    if (!this.db) {
      // Try to get the global indexedDBStorage
      const globalStorage = typeof window !== 'undefined' && window.indexedDBStorage
                          || typeof self !== 'undefined' && self.indexedDBStorage;
      if (globalStorage) {
        this.db = globalStorage;
      }
    }
    // Only init if DB exists but isn't initialized, and we haven't already started init
    if (this.db && !this.db.db && !this.db.initPromise) {
      this.db.initPromise = this.db.init();
      return this.db.initPromise;
    }
    // If init is already in progress, wait for it
    if (this.db && this.db.initPromise) {
      return this.db.initPromise;
    }
    return this.db;
  }

  /**
   * Fetch with timeout to prevent hanging requests
   * @private
   */
  async _fetchWithTimeout(url, options = {}) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.requestTimeout);
    
    try {
      const response = await fetch(url, {
        ...options,
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      return response;
    } catch (error) {
      clearTimeout(timeoutId);
      if (error.name === 'AbortError') {
        throw new Error('Request timeout');
      }
      throw error;
    }
  }

  /**
   * Get auth token from license validator for API requests
   * @private
   */
  async _getAuthToken() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['licenseToken', 'licenseTokenExpiry'], (result) => {
        const token = result.licenseToken;
        const expiry = result.licenseTokenExpiry || 0;
        const now = Date.now();

        if (token && expiry > now) {
          resolve(token);
        } else {
          resolve(null);
        }
      });
    });
  }

  /**
   * Fetch community information with caching
   * @param {string} communityId - The community ID to fetch
   * @returns {Promise<Object>} Community data
   */
  async getCommunity(communityId) {
    await this._ensureDB();
    // PERFORMANCE: Normalize cache key to improve hit rate (60-70% -> 85-90%)
    const cacheKey = `community_cache_${communityId.toLowerCase().trim()}`;

    // Check cache first (IndexedDB)
    const cached = this.db ? await this.db.getCache(cacheKey) : null;
    if (cached) {
      this.stats.community.hits++;
      return cached;
    }

    this.stats.community.misses++;

    // Check for in-flight request
    const pendingKey = `community_${communityId}`;
    if (this.pendingRequests.has(pendingKey)) {
      this.stats.deduplicated++;
      return this.pendingRequests.get(pendingKey);
    }

    // Make new request using Vercel API
    const request = this._fetchCommunityFromVercel(communityId)
      .then(async data => {
        // PERFORMANCE: Use configured TTL (1 hour for communities)
        if (this.db) {
          await this.db.setCache(cacheKey, data, this.cacheTTLs.community, 'community');
        }
        this.pendingRequests.delete(pendingKey);
        return data;
      })
      .catch(error => {
        this.pendingRequests.delete(pendingKey);
        throw error;
      });

    this.pendingRequests.set(pendingKey, request);
    return request;
  }

  /**
   * Fetch user profile with caching
   * @param {string} username - The username to fetch
   * @returns {Promise<Object>} User profile data
   */
  async getUserProfile(username) {
    await this._ensureDB();
    // PERFORMANCE: Normalize cache key to improve hit rate (60-70% -> 85-90%)
    const cacheKey = `user_profile_${username.toLowerCase().trim()}`;

    // Check cache first (IndexedDB)
    const cached = this.db ? await this.db.getCache(cacheKey) : null;
    if (cached) {
      this.stats.user.hits++;
      return cached;
    }

    this.stats.user.misses++;

    // Check for in-flight request
    const pendingKey = `user_${username}`;
    if (this.pendingRequests.has(pendingKey)) {
      this.stats.deduplicated++;
      return this.pendingRequests.get(pendingKey);
    }

    // Make new request using Vercel API
    const request = this._fetchUserFromVercel(username)
      .then(async data => {
        // API returns {status: "success", data: {...}}
        const userData = data.data || data;
        // PERFORMANCE: Use configured TTL (15 minutes for user profiles)
        if (this.db) {
          await this.db.setCache(cacheKey, userData, this.cacheTTLs.user_profile, 'user_profile');
        }
        this.pendingRequests.delete(pendingKey);
        return userData;
      })
      .catch(error => {
        this.pendingRequests.delete(pendingKey);
        throw error;
      });

    this.pendingRequests.set(pendingKey, request);
    return request;
  }

  /**
   * Fetch user profile from Vercel API (simplified endpoint)
   * @private
   */
  async _fetchUserFromVercel(username) {
    // Try Vercel API first (hides the API key)
    try {
      // Get auth token from license validator
      const token = await this._getAuthToken();

      const vercelUrl = `${this.baseUrl}?userName=${encodeURIComponent(username)}`;
      const headers = {
        'Content-Type': 'application/json'
      };

      // Add Authorization header if we have a valid token
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const response = await this._fetchWithTimeout(vercelUrl, { headers });
      const data = await response.json();

      if (response.ok && data && !data.error) {
        return data;
      }
      throw new Error(data.error || 'Vercel API error');
    } catch (vercelError) {
      // PERFORMANCE: Smart fallback - only on network errors, not timeouts or 4xx
      // This prevents 10-second timeout delays from causing double requests
      const isNetworkError = vercelError.message?.includes('NetworkError') ||
                            vercelError.message?.includes('fetch') ||
                            vercelError.name === 'TypeError';

      if (isNetworkError) {
        console.warn('[ApiClient] Vercel API unavailable (network error), using direct API');
        return this._fetchDirect(`/user/info?userName=${username}`);
      }

      // Re-throw timeouts, 4xx errors, and API errors - no fallback
      throw vercelError;
    }
  }

  /**
   * Fetch community from Vercel API (simplified endpoint)
   * @private
   */
  async _fetchCommunityFromVercel(communityId) {
    // Try Vercel API first (hides the API key)
    try {
      // Get auth token from license validator
      const token = await this._getAuthToken();

      const vercelUrl = `${this.communityBaseUrl}?communityId=${encodeURIComponent(communityId)}`;
      const headers = {
        'Content-Type': 'application/json'
      };

      // Add Authorization header if we have a valid token
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const response = await this._fetchWithTimeout(vercelUrl, { headers });
      const data = await response.json();

      if (response.ok && data && !data.error) {
        return data;
      }
      throw new Error(data.error || 'Vercel API error');
    } catch (vercelError) {
      // PERFORMANCE: Smart fallback - only on network errors, not timeouts or 4xx
      const isNetworkError = vercelError.message?.includes('NetworkError') ||
                            vercelError.message?.includes('fetch') ||
                            vercelError.name === 'TypeError';

      if (isNetworkError) {
        console.warn('[ApiClient] Vercel API unavailable (network error), using direct API');
        return this._fetchDirect(`/community/info?community_id=${communityId}`);
      }

      // Re-throw timeouts, 4xx errors, and API errors - no fallback
      throw vercelError;
    }
  }

  /**
   * Direct API call (fallback disabled for security)
   * @private
   */
  async _fetchDirect(endpoint) {
    // SECURITY: Direct API access disabled - API key removed from client code
    // All requests must go through the Vercel proxy
    throw new Error('Direct API access disabled. Please use the Vercel proxy for all API requests.');
  }

  /**
   * Clear all API caches (community, user profile, and MEVX token cache)
   */
  async clearCache() {
    await this._ensureDB();
    if (this.db) {
      // Clear by type: community, user_profile, mevx_token
      await this.db.clearCache('community');
      await this.db.clearCache('user_profile');
      await this.db.clearCache('mevx_token');
    }
    // Fallback to chrome.storage for any legacy data
    return new Promise((resolve) => {
      chrome.storage.local.get(null, (items) => {
        const keysToRemove = Object.keys(items).filter(key =>
          key.startsWith('community_cache_') ||
          key.startsWith('user_profile_') ||
          key.startsWith('mevx_token_')
        );

        if (keysToRemove.length > 0) {
          chrome.storage.local.remove(keysToRemove, () => {
            resolve();
          });
        } else {
          resolve();
        }
      });
    });
  }

  /**
   * Clear specific cache entry
   */
  async clearKey(key) {
    await this._ensureDB();
    if (this.db) {
      await this.db.deleteCache(key);
    }
    // Also clear from chrome.storage for legacy support
    return new Promise((resolve) => {
      chrome.storage.local.remove([key], () => {
        resolve();
      });
    });
  }

  /**
   * Get cache statistics
   */
  getStats() {
    return {
      ...this.stats,
      pendingRequests: this.pendingRequests.size
    };
  }

  /**
   * Log cache statistics
   */
  logStats() {
    const stats = this.getStats();
    const communityTotal = stats.community.hits + stats.community.misses;
    const userTotal = stats.user.hits + stats.user.misses;
  }
}

// Export singleton instance
const api = new ApiClient();

// ES module export for use in service workers and other modules
export { api, ApiClient };

// Make available globally for content scripts
if (typeof window !== 'undefined') {
  window.ApiClient = ApiClient;
  window.api = api;
}
