// Config Share Browse Module - Direct Supabase Access
// Bypasses Vercel API and connects directly to Supabase

// Supabase configuration (same as supabase-client.js)
const SUPABASE_URL = 'https://otmflwmqqjiatzvtsoys.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im90bWZsd21xcWppYXR6dnRzb3lzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjkxODY5NTUsImV4cCI6MjA4NDc2Mjk1NX0.Dy6pc_K64_riHTVxUuCLwzH5tE73Ze-nONyfdCp00_c';

// Toast notification helper
function showToast(message, type = 'success') {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('hiding');
    toast.addEventListener('animationend', () => toast.remove());
  }, 3000);
}

// Import ConfigSharePreview class
import { ConfigSharePreview } from './config-share-preview.js';

export class ConfigShareBrowse {
  constructor() {
    this.overlay = null;
    this.modal = null;
    this.isVisible = false;
    this.currentTab = 'community'; // 'community' or 'my-configs'
    this.currentPage = 1;
    this.totalPages = 1;
    this.configs = [];
    this.isLoading = false;
    this.pageSize = 20;
  }

  async show() {
    if (this.isVisible) return;
    this.isVisible = true;
    this.currentPage = 1;
    this.currentTab = 'community';

    this.createOverlay();
    document.body.appendChild(this.overlay);
    this.overlay.classList.add('active');

    await this.loadConfigs();
  }

  hide() {
    if (!this.isVisible) return;
    this.isVisible = false;
    this.overlay.classList.remove('active');
    setTimeout(() => {
      if (this.overlay && this.overlay.parentNode) {
        this.overlay.parentNode.removeChild(this.overlay);
      }
      this.overlay = null;
      this.modal = null;
    }, 200);
  }

  createOverlay() {
    this.overlay = document.createElement('div');
    this.overlay.className = 'config-share-overlay';
    this.overlay.innerHTML = this.getModalHTML();

    this.modal = this.overlay.querySelector('.config-share-modal');

    // Add event listeners
    const closeBtn = this.overlay.querySelector('.config-share-close');
    closeBtn.addEventListener('click', () => this.hide());

    this.overlay.addEventListener('click', (e) => {
      if (e.target === this.overlay) {
        this.hide();
      }
    });

    // Tab switching
    const tabs = this.overlay.querySelectorAll('.config-share-tab');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        const tabName = tab.dataset.tab;
        this.switchTab(tabName);
      });
    });

    // Close on Escape key
    this.escapeHandler = (e) => {
      if (e.key === 'Escape') {
        this.hide();
      }
    };
    document.addEventListener('keydown', this.escapeHandler);
  }

  getModalHTML() {
    return `
      <div class="config-share-modal">
        <div class="config-share-header">
          <h2>Browse Configs</h2>
          <button class="config-share-close">&times;</button>
        </div>
        <div class="config-share-tabs">
          <button class="config-share-tab active" data-tab="community">Community</button>
          <button class="config-share-tab" data-tab="my-configs">My Configs</button>
        </div>
        <div class="config-share-body" id="configShareListContainer">
          <div class="config-share-loading">
            <div class="config-share-spinner"></div>
            <div class="config-share-loading-text">Loading configs...</div>
          </div>
        </div>
      </div>
    `;
  }

  switchTab(tabName) {
    if (this.currentTab === tabName) return;
    this.currentTab = tabName;
    this.currentPage = 1;

    // Update tab styles
    const tabs = this.overlay.querySelectorAll('.config-share-tab');
    tabs.forEach(tab => {
      tab.classList.toggle('active', tab.dataset.tab === tabName);
    });

    this.loadConfigs();
  }

  /**
   * Direct Supabase query - no Vercel API needed
   */
  async loadConfigs() {
    if (this.isLoading) return;
    this.isLoading = true;

    const container = this.overlay.querySelector('#configShareListContainer');
    container.innerHTML = `
      <div class="config-share-loading">
        <div class="config-share-spinner"></div>
        <div class="config-share-loading-text">Loading configs...</div>
      </div>
    `;

    try {
      const offset = (this.currentPage - 1) * this.pageSize;
      
      // Build the Supabase query URL
      let url = `${SUPABASE_URL}/rest/v1/shared_configs?select=*`;
      
      if (this.currentTab === 'community') {
        // Public configs only
        url += `&is_public=eq.true`;
      }
      // For 'my-configs' tab - we show all configs since there's no auth
      // In a real implementation, you'd filter by device_id here
      
      // Ordering and pagination
      url += `&order=created_at.desc&limit=${this.pageSize}&offset=${offset}`;
      
      // Get total count for pagination
      const countUrl = `${SUPABASE_URL}/rest/v1/shared_configs?select=id${this.currentTab === 'community' ? '&is_public=eq.true' : ''}`;
      
      const [dataResponse, countResponse] = await Promise.all([
        fetch(url, {
          headers: {
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json'
          }
        }),
        fetch(countUrl, {
          headers: {
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
            'Prefer': 'count=exact'
          }
        })
      ]);

      if (!dataResponse.ok) {
        const errorText = await dataResponse.text();
        throw new Error(`Failed to fetch configs: ${dataResponse.status} ${errorText}`);
      }

      const data = await dataResponse.json();
      
      // Parse count from header if available
      let totalCount = 0;
      const countHeader = countResponse.headers.get('content-range');
      if (countHeader) {
        const match = countHeader.match(/(\d+)$/);
        if (match) totalCount = parseInt(match[1]);
      } else {
        // Fallback: count the results
        const countData = await countResponse.json();
        totalCount = countData?.length || 0;
      }
      
      this.configs = data || [];
      this.totalPages = Math.ceil(totalCount / this.pageSize) || 1;

      this.renderConfigs();

    } catch (error) {
      console.error('Load configs error:', error);
      container.innerHTML = `
        <div class="config-share-empty">
          <div class="config-share-empty-text">Failed to load configs</div>
          <div class="config-share-empty-subtext">${error.message}</div>
          <button class="config-share-btn config-share-btn-primary" style="margin-top: 16px;" onclick="location.reload()">Retry</button>
        </div>
      `;
    } finally {
      this.isLoading = false;
    }
  }

  renderConfigs() {
    const container = this.overlay.querySelector('#configShareListContainer');

    if (this.configs.length === 0) {
      const emptyMessage = this.currentTab === 'community'
        ? 'No public configs available yet'
        : 'You haven\'t uploaded any configs yet';

      container.innerHTML = `
        <div class="config-share-empty">
          <div class="config-share-empty-text">${emptyMessage}</div>
        </div>
      `;
      return;
    }

    let html = '<div class="config-share-list">';

    this.configs.forEach(config => {
      const date = new Date(config.created_at).toLocaleDateString();
      const badgeClass = config.is_public ? 'public' : 'private';
      const badgeText = config.is_public ? 'Public' : 'Private';

      html += `
        <div class="config-share-card" data-config-id="${config.id}">
          <div class="config-share-card-header">
            <h3 class="config-share-card-name">${this.escapeHtml(config.display_name || 'Unnamed Config')}</h3>
            <span class="config-share-card-badge ${badgeClass}">${badgeText}</span>
          </div>
          ${config.description ? `<div class="config-share-card-description">${this.escapeHtml(config.description)}</div>` : ''}
          <div class="config-share-card-meta">
            <span class="config-share-card-meta-item">
              <strong>${config.admins_count || 0}</strong> admins
            </span>
            <span class="config-share-card-meta-item">
              <strong>${config.tweets_count || 0}</strong> tweets
            </span>
            <span class="config-share-card-meta-item">
              <strong>${config.blacklist_count || 0}</strong> blacklist
            </span>
            ${config.copy_count > 0 ? `
              <span class="config-share-card-meta-item">
                <strong>${config.copy_count}</strong> copies
              </span>
            ` : ''}
            <span class="config-share-card-meta-item">
              ${date}
            </span>
          </div>
          <div class="config-share-card-actions" style="margin-top: 12px; display: flex; gap: 8px;">
            <button class="config-share-action-btn config-share-action-btn-preview" data-action="preview" data-config-id="${config.id}">Preview</button>
            ${config.is_public ? `
              <button class="config-share-action-btn config-share-action-btn-copy" data-action="copy" data-config-id="${config.id}">Copy</button>
            ` : ''}
            ${this.currentTab === 'my-configs' ? `
              <button class="config-share-action-btn config-share-action-btn-visibility" data-action="visibility" data-config-id="${config.id}" data-public="${config.is_public}">
                ${config.is_public ? 'Make Private' : 'Make Public'}
              </button>
              <button class="config-share-action-btn config-share-action-btn-delete" data-action="delete" data-config-id="${config.id}">Delete</button>
            ` : ''}
          </div>
        </div>
      `;
    });

    html += '</div>';

    // Add pagination if needed
    if (this.totalPages > 1) {
      html += `
        <div class="config-share-pagination">
          <button class="config-share-page-btn" data-action="prev-page" ${this.currentPage === 1 ? 'disabled' : ''}>← Prev</button>
          <span class="config-share-page-info">Page ${this.currentPage} of ${this.totalPages}</span>
          <button class="config-share-page-btn" data-action="next-page" ${this.currentPage === this.totalPages ? 'disabled' : ''}>Next →</button>
        </div>
      `;
    }

    container.innerHTML = html;

    // Add event listeners for actions
    this.attachActionListeners();
  }

  attachActionListeners() {
    const container = this.overlay.querySelector('#configShareListContainer');

    // Preview buttons
    container.querySelectorAll('[data-action="preview"]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const configId = btn.dataset.configId;
        this.openPreview(configId);
      });
    });

    // Copy buttons
    container.querySelectorAll('[data-action="copy"]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const configId = btn.dataset.configId;
        this.copyConfig(configId);
      });
    });

    // Visibility buttons
    container.querySelectorAll('[data-action="visibility"]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const configId = btn.dataset.configId;
        const currentPublic = btn.dataset.public === 'true';
        this.toggleVisibility(configId, !currentPublic);
      });
    });

    // Delete buttons
    container.querySelectorAll('[data-action="delete"]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const configId = btn.dataset.configId;
        this.deleteConfig(configId);
      });
    });

    // Pagination
    container.querySelectorAll('[data-action="prev-page"]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (this.currentPage > 1) {
          this.currentPage--;
          this.loadConfigs();
        }
      });
    });

    container.querySelectorAll('[data-action="next-page"]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (this.currentPage < this.totalPages) {
          this.currentPage++;
          this.loadConfigs();
        }
      });
    });
  }

  async openPreview(configId) {
    const previewModal = new ConfigSharePreview(configId);
    await previewModal.show();
  }

  /**
   * Copy config - direct Supabase query
   */
  async copyConfig(configId) {
    const confirmed = await this.showConfirmDialog(
      'Copy Config',
      'This will replace your current config with the copied one. Are you sure?'
    );

    if (!confirmed) return;

    try {
      // Fetch config directly from Supabase
      const url = `${SUPABASE_URL}/rest/v1/shared_configs?id=eq.${configId}&is_public=eq.true&select=*`;
      const response = await fetch(url, {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch config');
      }

      const data = await response.json();
      if (!data || data.length === 0) {
        throw new Error('Config not found or is private');
      }

      const config = data[0];

      // Increment copy count
      await this.incrementCopyCount(configId);

      // Import the config data
      await this.importConfig(config.config_data);

      showToast('Config copied successfully!', 'success');
      this.hide();

    } catch (error) {
      console.error('Copy config error:', error);
      showToast(error.message || 'Failed to copy config', 'error');
    }
  }

  /**
   * Increment copy count via RPC or direct update
   */
  async incrementCopyCount(configId) {
    try {
      // Try to use RPC if available, otherwise use PATCH
      const url = `${SUPABASE_URL}/rest/v1/rpc/increment_copy_count`;
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ config_id: configId })
      });

      // If RPC doesn't exist, fallback to direct update (may fail due to RLS)
      if (!response.ok) {
        console.log('[ConfigShare] RPC not available, skipping copy count update');
      }
    } catch (err) {
      console.log('[ConfigShare] Failed to update copy count:', err);
    }
  }

  /**
   * Toggle visibility - direct Supabase update
   */
  async toggleVisibility(configId, isPublic) {
    try {
      const url = `${SUPABASE_URL}/rest/v1/shared_configs?id=eq.${configId}`;
      const response = await fetch(url, {
        method: 'PATCH',
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify({ is_public: isPublic })
      });

      if (!response.ok) {
        throw new Error('Failed to update visibility');
      }

      showToast(`Config is now ${isPublic ? 'public' : 'private'}`, 'success');
      this.loadConfigs(); // Reload to show updated state

    } catch (error) {
      console.error('Toggle visibility error:', error);
      showToast(error.message || 'Failed to update visibility', 'error');
    }
  }

  /**
   * Delete config - direct Supabase delete
   */
  async deleteConfig(configId) {
    const confirmed = await this.showConfirmDialog(
      'Delete Config',
      'Are you sure you want to delete this config? This action cannot be undone.'
    );

    if (!confirmed) return;

    try {
      const url = `${SUPABASE_URL}/rest/v1/shared_configs?id=eq.${configId}`;
      const response = await fetch(url, {
        method: 'DELETE',
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Failed to delete config');
      }

      showToast('Config deleted successfully', 'success');
      this.loadConfigs(); // Reload to show updated list

    } catch (error) {
      console.error('Delete config error:', error);
      showToast(error.message || 'Failed to delete config', 'error');
    }
  }

  async importConfig(configData) {
    const settings = configData?.settings || {};

    // Import visual settings to chrome.storage.sync
    const syncSettings = {
      xCommunityEnabled: settings.detectXCommunity,
      showAdminInfo: settings.showAdminInfo,
      showMemberPreview: settings.showMemberPreview,
      showFollowerCount: settings.showFollowerCount,
      adminBackgroundEnabled: settings.adminBackgroundEnabled,
      normalAdminColor: settings.normalAdminColor,
      trackedGradientEnabled: settings.trackedGradientEnabled,
      trackedBorderColor: settings.trackedBorderColor,
      trackedGradientColor: settings.trackedGradientColor,
      trackedGradientOpacity: settings.trackedGradientOpacity,
      tweetsGradientEnabled: settings.tweetsGradientEnabled,
      tweetsShowOverlay: settings.tweetsShowOverlay,
      tweetsBorderColor: settings.tweetsBorderColor,
      tweetsGradientColor: settings.tweetsGradientColor,
      tweetsGradientOpacity: settings.tweetsGradientOpacity,
      adminAlertEnabled: settings.adminAlertSound,
      adminAlertVolume: settings.adminAlertVolume,
      adminAlertCustomSound: settings.adminAlertCustomSound,
      communityVerificationEnabled: settings.communityVerificationEnabled,
      showQuickStatsPopup: settings.showQuickStatsPopup,
      scoreAlertBorderColor: settings.scoreAlertBorderColor,
      scoreAlertGradientColor: settings.scoreAlertGradientColor,
      scoreAlertGradientOpacity: settings.scoreAlertGradientOpacity,
      scoreAlertGradientEnabled: settings.scoreAlertGradientEnabled
    };

    // Remove undefined values
    Object.keys(syncSettings).forEach(key => {
      if (syncSettings[key] === undefined) {
        delete syncSettings[key];
      }
    });

    // Import lists and cache to chrome.storage.local
    const localData = {
      trackedAdmins: settings.adminAlertsList || [],
      blacklistedAdmins: settings.adminBlacklistList || [],
      trackedTweets: settings.trackedTweetsList || [],
      blacklistedTweets: settings.blacklistedTweetsList || [],
      adminProfileCache: configData.adminProfileCache || {}
    };

    // First save to sync storage (settings)
    await new Promise((resolve, reject) => {
      chrome.storage.sync.set(syncSettings, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });

    // Then save to local storage (lists and cache)
    await new Promise((resolve, reject) => {
      chrome.storage.local.set(localData, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
  }

  showConfirmDialog(title, message) {
    return new Promise((resolve) => {
      const overlay = document.createElement('div');
      overlay.className = 'config-share-dialog-overlay';
      overlay.innerHTML = `
        <div class="config-share-dialog">
          <h3 class="config-share-dialog-title">${title}</h3>
          <p class="config-share-dialog-message">${message}</p>
          <div class="config-share-dialog-actions">
            <button class="config-share-btn config-share-btn-secondary" data-action="cancel">Cancel</button>
            <button class="config-share-btn config-share-btn-primary" data-action="confirm">Confirm</button>
          </div>
        </div>
      `;

      document.body.appendChild(overlay);

      // Trigger animation
      requestAnimationFrame(() => {
        overlay.classList.add('active');
      });

      const closeDialog = () => {
        overlay.classList.remove('active');
        setTimeout(() => {
          if (overlay.parentNode) {
            overlay.parentNode.removeChild(overlay);
          }
        }, 200);
      };

      overlay.querySelector('[data-action="cancel"]').addEventListener('click', () => {
        closeDialog();
        resolve(false);
      });

      overlay.querySelector('[data-action="confirm"]').addEventListener('click', () => {
        closeDialog();
        resolve(true);
      });

      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          closeDialog();
          resolve(false);
        }
      });
    });
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}
