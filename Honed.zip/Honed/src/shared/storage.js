/**
 * Storage Helper Module
 * Abstraction layer for chrome.storage with typed access
 */

/**
 * Default settings values
 */
const DEFAULT_SETTINGS = {
  xCommunityEnabled: true,
  tweetTrackingEnabled: true,
  showAdminInfo: true,
  showMemberPreview: true,
  showFollowerCount: true,
  normalAdminColor: '#1a1a2e',
  trackedBorderColor: '#22d3ee',
  trackedGradientColor: '#22d3ee',
  trackedGradientOpacity: 20,
  adminAlertEnabled: false,
  adminAlertVolume: 50,
  adminAlertCustomSound: null,
  communityVerificationEnabled: true,
  showQuickStatsPopup: true
};

/**
 * ============================================
 * PERFORMANCE: In-memory settings cache
 * Reduces chrome.storage calls from O(n) to O(1) after init
 * ============================================
 */
class SettingsCache {
  constructor() {
    this.cache = { ...DEFAULT_SETTINGS };
    this.initialized = false;
    this.initPromise = null;
    this.listeners = [];
  }

  /**
   * Initialize the cache once
   */
  async init() {
    if (this.initialized) return this.cache;
    if (this.initPromise) return this.initPromise;

    this.initPromise = new Promise((resolve) => {
      chrome.storage.sync.get(DEFAULT_SETTINGS, (settings) => {
        this.cache = { ...settings };
        this.initialized = true;

        // Listen for changes and update cache
        chrome.storage.onChanged.addListener((changes, area) => {
          if (area === 'sync') {
            for (const [key, { newValue }] of Object.entries(changes)) {
              if (newValue !== undefined) {
                this.cache[key] = newValue;
                // Notify listeners
                this.listeners.forEach(fn => fn(key, newValue));
              }
            }
          }
        });

        resolve(this.cache);
        this.initPromise = null;
      });
    });

    return this.initPromise;
  }

  /**
   * Get a setting value (sync after init)
   */
  get(key) {
    return this.cache[key];
  }

  /**
   * Get all settings (sync after init)
   */
  getAll() {
    return { ...this.cache };
  }

  /**
   * Listen for setting changes
   */
  onChange(callback) {
    this.listeners.push(callback);
    // Return unsubscribe function
    return () => {
      this.listeners = this.listeners.filter(fn => fn !== callback);
    };
  }
}

// Singleton instance
const settingsCache = new SettingsCache();

/**
 * Storage client for settings (chrome.storage.sync)
 * Enhanced with in-memory caching for performance
 */
class SettingsStorage {
  /**
   * Get all settings (cached after first call)
   * @returns {Promise<Object>} Settings object
   */
  static async getAll() {
    await settingsCache.init();
    return settingsCache.getAll();
  }

  /**
   * Get a single setting (cached after init - no async needed!)
   * @param {string} key - Setting key
   * @returns {Promise<any>} Setting value
   */
  static async get(key) {
    await settingsCache.init();
    return settingsCache.get(key);
  }

  /**
   * Get a setting synchronously (only works after cache is initialized)
   * Use this for hot paths where you can't await
   * @param {string} key - Setting key
   * @returns {any} Setting value or undefined if not initialized
   */
  static getSync(key) {
    if (settingsCache.initialized) {
      return settingsCache.get(key);
    }
    return undefined;
  }

  /**
   * Set a single setting
   * @param {string} key - Setting key
   * @param {any} value - New value
   */
  static async set(key, value) {
    return new Promise((resolve) => {
      chrome.storage.sync.set({ [key]: value }, () => {
        resolve();
      });
    });
  }

  /**
   * Set multiple settings
   * @param {Object} settings - Settings object
   */
  static async setMultiple(settings) {
    return new Promise((resolve) => {
      chrome.storage.sync.set(settings, () => {
        resolve();
      });
    });
  }

  /**
   * Listen for settings changes
   * @param {Function} callback - Callback(changes, areaName)
   */
  static onChanged(callback) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'sync') {
        callback(changes, areaName);
      }
    });
  }
}

/**
 * Storage client for local data (chrome.storage.local)
 */
class LocalStorage {
  /**
   * Get value by key
   * @param {string} key - Storage key
   * @returns {Promise<any>} Stored value
   */
  static async get(key) {
    return new Promise((resolve) => {
      chrome.storage.local.get([key], (result) => {
        resolve(result[key] || null);
      });
    });
  }

  /**
   * Set value by key
   * @param {string} key - Storage key
   * @param {any} value - Value to store
   */
  static async set(key, value) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [key]: value }, () => {
        resolve();
      });
    });
  }

  /**
   * Remove value by key
   * @param {string} key - Storage key
   */
  static async remove(key) {
    return new Promise((resolve) => {
      chrome.storage.local.remove([key], () => {
        resolve();
      });
    });
  }

  /**
   * Clear all local storage
   */
  static async clear() {
    return new Promise((resolve) => {
      chrome.storage.local.clear(() => {
        resolve();
      });
    });
  }

  /**
   * Get all keys matching a pattern
   * @param {string} pattern - RegExp pattern string
   * @returns {Promise<Array<string>>} Matching keys
   */
  static async getKeysByPattern(pattern) {
    return new Promise((resolve) => {
      chrome.storage.local.get(null, (items) => {
        const regex = new RegExp(pattern);
        const keys = Object.keys(items).filter(key => regex.test(key));
        resolve(keys);
      });
    });
  }

  /**
   * Clear all keys matching a pattern
   * @param {string} pattern - RegExp pattern string
   */
  static async clearByPattern(pattern) {
    const keys = await this.getKeysByPattern(pattern);
    if (keys.length > 0) {
      return new Promise((resolve) => {
        chrome.storage.local.remove(keys, () => {
          resolve();
        });
      });
    }
  }

  /**
   * Listen for local storage changes
   * @param {Function} callback - Callback(changes, areaName)
   */
  static onChanged(callback) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'local') {
        callback(changes, areaName);
      }
    });
  }
}

/**
 * Core admins storage helper
 */
class CoreAdminsStorage {
  static STORAGE_KEY = 'coreAdmins';

  /**
   * Get all core admins
   * @returns {Promise<Array>} Array of admin objects
   */
  static async getAll() {
    return new Promise((resolve) => {
      chrome.storage.local.get([this.STORAGE_KEY], (result) => {
        resolve(result[this.STORAGE_KEY] || []);
      });
    });
  }

  /**
   * Add a core admin
   * @param {Object} admin - Admin object
   */
  static async add(admin) {
    const admins = await this.getAll();
    admins.push(admin);
    return this.setAll(admins);
  }

  /**
   * Remove a core admin by username
   * @param {string} username - Username to remove
   */
  static async remove(username) {
    const admins = await this.getAll();
    const filtered = admins.filter(a => {
      const adminUsername = a.username || a.userName || a.screen_name;
      return adminUsername !== username;
    });
    return this.setAll(filtered);
  }

  /**
   * Set all core admins
   * @param {Array} admins - Array of admin objects
   */
  static async setAll(admins) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: admins }, () => {
        resolve();
      });
    });
  }

  /**
   * Clear all core admins
   */
  static async clear() {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: [] }, () => {
        resolve();
      });
    });
  }

  /**
   * Check if username is in core list
   * @param {string} username - Username to check
   * @returns {Promise<boolean>} True if in core list
   */
  static async isCore(username) {
    const admins = await this.getAll();
    const normalizedUsername = username.toLowerCase().replace('@', '');
    return admins.some(a => {
      const adminUsername = (a.username || a.userName || a.screen_name || '').toLowerCase();
      return adminUsername === normalizedUsername;
    });
  }
}

/**
 * Tracked admins storage helper
 */
class TrackedAdminsStorage {
  static STORAGE_KEY = 'trackedAdmins';

  /**
   * Get all tracked admins
   * @returns {Promise<Array>} Array of admin objects
   */
  static async getAll() {
    return new Promise((resolve) => {
      chrome.storage.local.get([this.STORAGE_KEY], (result) => {
        resolve(result[this.STORAGE_KEY] || []);
      });
    });
  }

  /**
   * Add a tracked admin
   * @param {Object} admin - Admin object
   */
  static async add(admin) {
    const admins = await this.getAll();
    admins.push(admin);
    return this.setAll(admins);
  }

  /**
   * Remove a tracked admin by username
   * @param {string} username - Username to remove
   */
  static async remove(username) {
    const admins = await this.getAll();
    const filtered = admins.filter(a => {
      const adminUsername = a.username || a.userName || a.screen_name;
      return adminUsername !== username;
    });
    return this.setAll(filtered);
  }

  /**
   * Set all tracked admins
   * @param {Array} admins - Array of admin objects
   */
  static async setAll(admins) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: admins }, () => {
        resolve();
      });
    });
  }

  /**
   * Clear all tracked admins
   */
  static async clear() {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: [] }, () => {
        resolve();
      });
    });
  }

  /**
   * Check if username is tracked
   * @param {string} username - Username to check
   * @returns {Promise<boolean>} True if tracked
   */
  static async isTracked(username) {
    const admins = await this.getAll();
    const normalizedUsername = username.toLowerCase().replace('@', '');
    return admins.some(a => {
      const adminUsername = (a.username || a.userName || a.screen_name || '').toLowerCase();
      return adminUsername === normalizedUsername;
    });
  }
}

/**
 * Tracked tweets storage helper
 */
class TrackedTweetsStorage {
  static STORAGE_KEY = 'trackedTweets';

  /**
   * Get all tracked tweets
   * @returns {Promise<Array>} Array of tweet username objects
   */
  static async getAll() {
    return new Promise((resolve) => {
      chrome.storage.local.get([this.STORAGE_KEY], (result) => {
        resolve(result[this.STORAGE_KEY] || []);
      });
    });
  }

  /**
   * Add a tracked tweet username
   * @param {Object} tweet - Tweet username object
   */
  static async add(tweet) {
    const tweets = await this.getAll();
    tweets.push(tweet);
    return this.setAll(tweets);
  }

  /**
   * Remove a tracked tweet by username
   * @param {string} username - Username to remove
   */
  static async remove(username) {
    const tweets = await this.getAll();
    const filtered = tweets.filter(t => {
      const tweetUsername = t.username || t.userName || t.screen_name;
      return tweetUsername !== username;
    });
    return this.setAll(filtered);
  }

  /**
   * Set all tracked tweets
   * @param {Array} tweets - Array of tweet username objects
   */
  static async setAll(tweets) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: tweets }, () => {
        resolve();
      });
    });
  }

  /**
   * Clear all tracked tweets
   */
  static async clear() {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: [] }, () => {
        resolve();
      });
    });
  }

  /**
   * Check if username is tracked
   * @param {string} username - Username to check
   * @returns {Promise<boolean>} True if tracked
   */
  static async isTracked(username) {
    const tweets = await this.getAll();
    const normalizedUsername = username.toLowerCase().replace('@', '');
    return tweets.some(t => {
      const tweetUsername = (t.username || t.userName || t.screen_name || '').toLowerCase();
      return tweetUsername === normalizedUsername;
    });
  }
}

/**
 * Blacklisted tweets storage helper
 */
class BlacklistedTweetsStorage {
  static STORAGE_KEY = 'blacklistedTweets';

  /**
   * Get all blacklisted tweets
   * @returns {Promise<Array>} Array of blacklisted tweet username objects
   */
  static async getAll() {
    return new Promise((resolve) => {
      chrome.storage.local.get([this.STORAGE_KEY], (result) => {
        resolve(result[this.STORAGE_KEY] || []);
      });
    });
  }

  /**
   * Add a blacklisted tweet username
   * @param {Object} tweet - Tweet username object
   */
  static async add(tweet) {
    const tweets = await this.getAll();
    tweets.push(tweet);
    return this.setAll(tweets);
  }

  /**
   * Remove a blacklisted tweet by username
   * @param {string} username - Username to remove
   */
  static async remove(username) {
    const tweets = await this.getAll();
    const filtered = tweets.filter(t => {
      const tweetUsername = t.username || t.userName || t.screen_name;
      return tweetUsername !== username;
    });
    return this.setAll(filtered);
  }

  /**
   * Set all blacklisted tweets
   * @param {Array} tweets - Array of blacklisted tweet username objects
   */
  static async setAll(tweets) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: tweets }, () => {
        resolve();
      });
    });
  }

  /**
   * Clear all blacklisted tweets
   */
  static async clear() {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: [] }, () => {
        resolve();
      });
    });
  }

  /**
   * Check if username is blacklisted
   * @param {string} username - Username to check
   * @returns {Promise<boolean>} True if blacklisted
   */
  static async isBlacklisted(username) {
    const tweets = await this.getAll();
    const normalizedUsername = username.toLowerCase().replace('@', '');
    return tweets.some(t => {
      const tweetUsername = (t.username || t.userName || t.screen_name || '').toLowerCase();
      return tweetUsername === normalizedUsername;
    });
  }
}

/**
 * Quick Stats Popup position storage helper
 */
class QuickStatsPopupStorage {
  static STORAGE_KEY = 'quickStatsPopupPosition';

  /**
   * Get saved position
   * @returns {Promise<Object|null>} { x, y } or null
   */
  static async getPosition() {
    return new Promise((resolve) => {
      chrome.storage.local.get([this.STORAGE_KEY], (result) => {
        resolve(result[this.STORAGE_KEY] || null);
      });
    });
  }

  /**
   * Save position
   * @param {number} x - X coordinate
   * @param {number} y - Y coordinate
   */
  static async setPosition(x, y) {
    return new Promise((resolve) => {
      chrome.storage.local.set({
        [this.STORAGE_KEY]: { x, y }
      }, resolve);
    });
  }

  /**
   * Clear saved position
   */
  static async clear() {
    return new Promise((resolve) => {
      chrome.storage.local.remove([this.STORAGE_KEY], resolve);
    });
  }
}

// Export for use in scripts
if (typeof window !== 'undefined') {
  window.SettingsStorage = SettingsStorage;
  window.SettingsCache = SettingsCache;
  window.settingsCache = settingsCache;
  window.LocalStorage = LocalStorage;
  window.CoreAdminsStorage = CoreAdminsStorage;
  window.TrackedAdminsStorage = TrackedAdminsStorage;
  window.TrackedTweetsStorage = TrackedTweetsStorage;
  window.BlacklistedTweetsStorage = BlacklistedTweetsStorage;
  window.QuickStatsPopupStorage = QuickStatsPopupStorage;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    DEFAULT_SETTINGS,
    SettingsStorage,
    SettingsCache,
    settingsCache,
    LocalStorage,
    CoreAdminsStorage,
    TrackedAdminsStorage,
    TrackedTweetsStorage,
    BlacklistedTweetsStorage,
    QuickStatsPopupStorage
  };
}

// ES6 module exports
export { DEFAULT_SETTINGS, SettingsStorage, SettingsCache, settingsCache, LocalStorage, CoreAdminsStorage, TrackedAdminsStorage, TrackedTweetsStorage, BlacklistedTweetsStorage, QuickStatsPopupStorage };
