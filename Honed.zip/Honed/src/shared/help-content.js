/**
 * Help Content Module
 * Centralized help documentation content for the Honed extension
 */

// Guard against duplicate script loading
if (typeof window.HelpContent !== 'undefined') {
  console.log('[HelpContent] Already loaded, skipping...');
} else {

class HelpContent {
  /**
   * Get all help topics
   * @returns {Object} Help topics organized by category
   */
  static getTopics() {
    return {
      gettingStarted: {
        id: 'gettingStarted',
        title: 'Getting Started',
        icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"></circle>
          <polygon points="10 8 16 12 10 16 10 8"></polygon>
        </svg>`,
        sections: [
          {
            title: 'What is Honed?',
            content: `
              <p>Honed is a Chrome extension that helps you track <strong>X (Twitter) community admins</strong> on Solana memecoin trading platforms like <strong>padre.gg</strong> and <strong>axiom.trade</strong>.</p>
              <p>When you track admins, you'll be notified when they launch new tokens, see their performance scores, and avoid tokens from blacklisted admins.</p>
            `,
            screenshot: null
          },
          {
            title: 'Supported Platforms',
            content: `
              <p>Honed works on these platforms:</p>
              <ul>
                <li><strong>trade.padre.gg</strong> - /trenches and /trade pages</li>
                <li><strong>axiom.trade</strong> - entire site</li>
              </ul>
              <p>Simply navigate to these sites and Honed will automatically detect community admins and their tokens.</p>
            `,
            screenshot: null
          },
          {
            title: 'First Steps',
            content: `
              <ol>
                <li><strong>Add admins to track</strong> - Click the star icon on any admin card or add them manually in the popup</li>
                <li><strong>Set up alerts</strong> - Enable admin alert sounds in Settings to get notified of new tokens</li>
                <li><strong>Blacklist unwanted admins</strong> - Hide tokens from admins you don't want to see</li>
                <li><strong>Check scores</strong> - Lower scores (0-1) indicate better performing admins</li>
              </ol>
            `,
            screenshot: null
          }
        ]
      },
      trackingAdmins: {
        id: 'trackingAdmins',
        title: 'Tracking Admins',
        icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
          <circle cx="9" cy="7" r="4"></circle>
          <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
          <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
        </svg>`,
        sections: [
          {
            title: 'How to Track an Admin',
            content: `
              <p>There are two ways to track admins:</p>
              <p><strong>Method 1: From the page</strong></p>
              <ol>
                <li>Find an admin card on padre.gg or axiom.trade</li>
                <li>Click the <span style="color: #fbbf24;">⭐ star icon</span> on the admin card</li>
                <li>The admin is automatically added to your tracked list!</li>
              </ol>
              <p><strong>Method 2: From the popup</strong></p>
              <ol>
                <li>Click the extension icon to open the popup</li>
                <li>Go to the <strong>Admins</strong> tab</li>
                <li>Select <strong>X Comm</strong> category</li>
                <li>Enter the username (e.g., @username) and click <strong>Add</strong></li>
              </ol>
            `,
            screenshot: chrome.runtime.getURL('help-images/add-admin.png')
          },
          {
            title: 'Removing Tracked Admins',
            content: `
              <p>To remove an admin from your tracked list:</p>
              <ol>
                <li>Open the extension popup</li>
                <li>Go to the <strong>Admins</strong> tab</li>
                <li>Make sure <strong>X Comm</strong> > <strong>Tracked</strong> is selected</li>
                <li>Find the admin in your tracked list</li>
                <li>Click the <strong>trash icon</strong> next to their name</li>
              </ol>
              <p>You can also click <strong>Clear All</strong> to remove all tracked admins at once.</p>
            `,
            screenshot: chrome.runtime.getURL('help-images/remove-admin.png')
          },
          {
            title: 'What Happens When You Track?',
            content: `
              <p>When you track an admin, Honed will:</p>
              <ul>
                <li><strong>Highlight their tokens</strong> with a colored gradient border</li>
                <li><strong>Play an alert sound</strong> (if enabled) when they launch a new token</li>
                <li><strong>Display their score</strong> from the Google Sheets database</li>
                <li><strong>Show their profile</strong> when you click on their username</li>
              </ul>
            `,
            screenshot: null
          }
        ]
      },
      blacklisting: {
        id: 'blacklisting',
        title: 'Blacklisting Admins',
        icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="15" y1="9" x2="9" y2="15"></line>
          <line x1="9" y1="9" x2="15" y2="15"></line>
        </svg>`,
        sections: [
          {
            title: 'What is Blacklisting?',
            content: `
              <p>Blacklisting allows you to <strong>hide tokens from specific admins</strong> that you don't want to see or trade.</p>
              <p>When an admin is blacklisted:</p>
              <ul>
                <li>Their tokens will be <strong>hidden</strong> from the main view</li>
                <li>A <strong>red overlay with X icon</strong> appears on their tokens</li>
                <li>You won't receive alerts for their new tokens</li>
              </ul>
              <p>This is useful for avoiding admins who consistently launch failed tokens or rugs.</p>
            `,
            screenshot: chrome.runtime.getURL('help-images/blacklist-admin.png')
          },
          {
            title: 'How to Blacklist an Admin',
            content: `
              <p>To blacklist an admin:</p>
              <ol>
                <li>Open the extension popup</li>
                <li>Go to the <strong>Admins</strong> tab</li>
                <li>Select <strong>X Comm</strong> category</li>
                <li>Click on the <strong>Blacklist</strong> sub-tab</li>
                <li>Enter the username (e.g., @username) and click <strong>Add</strong></li>
              </ol>
              <p>The admin will be added to your blacklist and their tokens will be hidden.</p>
            `,
            screenshot: null
          },
          {
            title: 'Removing from Blacklist',
            content: `
              <p>To remove an admin from your blacklist:</p>
              <ol>
                <li>Open the extension popup</li>
                <li>Go to the <strong>Admins</strong> tab</li>
                <li>Select <strong>X Comm</strong> > <strong>Blacklist</strong></li>
                <li>Find the admin in your blacklist</li>
                <li>Click the <strong>trash icon</strong> next to their name</li>
              </ol>
              <p>You can also click <strong>Clear All</strong> to remove all blacklisted admins.</p>
            `,
            screenshot: null
          }
        ]
      },
      scores: {
        id: 'scores',
        title: 'Score System',
        icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 2.91 6.96L12 17.77l-7.91 3.33L9 16.14l-5-4.87 6.91-1.01L12 2z"></path>
        </svg>`,
        sections: [
          {
            title: 'Understanding Scores',
            content: `
              <p>Admin scores range from <strong>0 to 6</strong> and are based on historical token performance data from Google Sheets.</p>
              <p><strong>Lower scores are better!</strong></p>
              <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; margin: 12px 0;">
                <div style="padding: 8px; background: rgba(16, 185, 129, 0.2); border-radius: 6px; border-left: 3px solid #10b981;">
                  <strong style="color: #10b981;">Score 0</strong><br>
                  <span style="font-size: 12px;">Excellent ($100k+ ATH)</span>
                </div>
                <div style="padding: 8px; background: rgba(160, 160, 160, 0.15); border-radius: 6px; border-left: 3px solid #a0a0a0;">
                  <strong style="color: #a0a0a0;">Score 1</strong><br>
                  <span style="font-size: 12px;">Fast migration</span>
                </div>
                <div style="padding: 8px; background: rgba(140, 140, 140, 0.15); border-radius: 6px; border-left: 3px solid #8c8c8c;">
                  <strong style="color: #8c8c8c;">Score 2</strong><br>
                  <span style="font-size: 12px;">Slow migration</span>
                </div>
                <div style="padding: 8px; background: rgba(251, 191, 36, 0.2); border-radius: 6px; border-left: 3px solid #fbbf24;">
                  <strong style="color: #fbbf24;">Score 3</strong><br>
                  <span style="font-size: 12px;">$30k+ ATH</span>
                </div>
                <div style="padding: 8px; background: rgba(251, 146, 60, 0.2); border-radius: 6px; border-left: 3px solid #fb923c;">
                  <strong style="color: #fb923c;">Score 4</strong><br>
                  <span style="font-size: 12px;">$20k+ ATH</span>
                </div>
                <div style="padding: 8px; background: rgba(239, 68, 68, 0.2); border-radius: 6px; border-left: 3px solid #ef4444;">
                  <strong style="color: #ef4444;">Score 5</strong><br>
                  <span style="font-size: 12px;">$10k+ ATH</span>
                </div>
                <div style="padding: 8px; background: rgba(239, 68, 68, 0.2); border-radius: 6px; border-left: 3px solid #ef4444; grid-column: 1 / -1;">
                  <strong style="color: #ef4444;">Score 6</strong><br>
                  <span style="font-size: 12px;">Failed (rug or poor performance)</span>
                </div>
              </div>
              <p>The score is based on the admin's <strong>All-Time High (ATH) market cap</strong> and how quickly their tokens migrated to Solana.</p>
            `,
            screenshot: chrome.runtime.getURL('help-images/score-system.png')
          },
          {
            title: 'Where to Find Scores',
            content: `
              <p>Scores are displayed in multiple places:</p>
              <ul>
                <li><strong>On admin cards</strong> - Shows the admin's average score</li>
                <li><strong>In the admin tokens modal</strong> - Click an admin's username to see detailed stats</li>
                <li><strong>Score distribution</strong> - Shows how many tokens the admin has at each score level</li>
              </ul>
              <p>You can toggle score display in <strong>Settings > Functionality > Show Sheet Scores</strong>.</p>
            `,
            screenshot: null
          },
          {
            title: 'Score Alerts',
            content: `
              <p>You can set up <strong>Score Alerts</strong> to notify you when an admin's token score meets a certain threshold.</p>
              <p>To configure score alerts:</p>
              <ol>
                <li>Open the extension popup</li>
                <li>Go to <strong>Settings > Functionality</strong></li>
                <li>Find the <strong>Score Alert</strong> section</li>
                <li>Enable <strong>Enable Score Alerts</strong></li>
                <li>Set the <strong>Score Threshold</strong> (0-5, lower is better)</li>
                <li>Adjust the alert volume</li>
              </ol>
              <p>Example: Setting threshold to 2 will alert you when an admin launches a token with score 0, 1, or 2.</p>
            `,
            screenshot: null
          }
        ]
      },
      alerts: {
        id: 'alerts',
        title: 'Alerts',
        icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
        </svg>`,
        sections: [
          {
            title: 'Admin Alert Sound',
            content: `
              <p>When <strong>Admin Alert</strong> is enabled, Honed will play a sound notification when a tracked admin creates a new token.</p>
              <p>This is especially useful if you're actively monitoring for launches from specific admins.</p>
              <p><strong>To configure:</strong></p>
              <ol>
                <li>Open the extension popup</li>
                <li>Go to <strong>Settings > Functionality</strong></li>
                <li>Find the <strong>Admin Alert</strong> section</li>
                <li>Enable <strong>Enable Alert Sound</strong></li>
                <li>Adjust the <strong>Volume</strong> slider (0-100%)</li>
                <li>Click <strong>Test Sound</strong> to preview</li>
              </ol>
            `,
            screenshot: null
          },
          {
            title: 'Resetting Alert Session',
            content: `
              <p>Alerts are <strong>session-based</strong>, meaning you'll only be alerted once per token per browser session.</p>
              <p>If you want to clear the session and re-enable alerts for tokens you've already seen:</p>
              <ol>
                <li>Go to <strong>Settings > Functionality</strong></li>
                <li>Find the <strong>Admin Alert</strong> section</li>
                <li>Click <strong>Reset Session</strong></li>
              </ol>
              <p>This will clear the list of tokens you've been alerted about, allowing you to be notified again.</p>
            `,
            screenshot: null
          },
          {
            title: 'Score Alerts',
            content: `
              <p><strong>Score Alerts</strong> notify you when an admin's token meets or exceeds your configured score threshold.</p>
              <p>Remember: <strong>lower scores are better!</strong> A threshold of 2 means you'll be alerted for scores 0, 1, and 2.</p>
              <p><strong>To configure:</strong></p>
              <ol>
                <li>Go to <strong>Settings > Functionality</strong></li>
                <li>Find the <strong>Score Alert</strong> section</li>
                <li>Enable <strong>Enable Score Alerts</strong></li>
                <li>Set the <strong>Score Threshold</strong> (0-5)</li>
                <li>Adjust the <strong>Alert Volume</strong></li>
                <li>Click <strong>Test Score Alert Sound</strong> to preview</li>
              </ol>
            `,
            screenshot: null
          }
        ]
      },
      communityVerification: {
        id: 'communityVerification',
        title: 'Community Verification',
        icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
        </svg>`,
        sections: [
          {
            title: 'How Community Verification Works',
            content: `
              <p>Honed includes <strong>Community Verification</strong> to detect duplicate tokens using the same X community.</p>
              <p>The system tracks which communities have been seen and marks the <strong>first token</strong> with each community as verified.</p>
              <p><strong>Verification badges:</strong></p>
              <ul>
                <li><span style="color: #10b981;">✓ Green checkmark</span> - First token with this community</li>
                <li><span style="color: #ef4444;">✗ Red X</span> - Not the first token (duplicate community)</li>
              </ul>
              <p>Hover over the badge to see which admin launched the first token with that community.</p>
            `,
            screenshot: chrome.runtime.getURL('help-images/verification-badges.png')
          },
          {
            title: 'Why This Matters',
            content: `
              <p>Scammers often create multiple tokens using the same popular community names to trick traders into thinking they're legitimate.</p>
              <p>Community Verification helps you:</p>
              <ul>
                <li><strong>Identify duplicates</strong> - See at a glance if this is the first token or a copycat</li>
                <li><strong>Avoid FOMO</strong> - Don't buy tokens just because they have a recognizable community</li>
                <li><strong>Track originals</strong> - Know which admin was first to launch with a community</li>
                <li><strong>Trade smarter</strong> - Make informed decisions based on verification status</li>
              </ul>
              <p>You can toggle verification badges in <strong>Settings > Functionality > Community Verification</strong>.</p>
            `,
            screenshot: null
          }
        ]
      },
      settings: {
        id: 'settings',
        title: 'Settings Guide',
        icon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="3"></circle>
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
        </svg>`,
        sections: [
          {
            title: 'Functionality Settings',
            content: `
              <p>The <strong>Functionality</strong> tab controls what features are enabled:</p>
              <p><strong>Display Options:</strong></p>
              <ul>
                <li><strong>Show Admin Info</strong> - Display admin avatars and names on tokens</li>
                <li><strong>Show Members</strong> - Show community member preview</li>
                <li><strong>Show Followers</strong> - Display follower counts for admins</li>
                <li><strong>Action Buttons</strong> - Show track/blacklist buttons on admin cards</li>
                <li><strong>Community Verification</strong> - Show fake token detection badges</li>
                <li><strong>Show Sheet Scores</strong> - Display admin scores from Google Sheets</li>
                <li><strong>Chart Score Distribution</strong> - Show score stats on chart pages</li>
                <li><strong>Quick Stats Popup</strong> - Show draggable stats popup on charts</li>
              </ul>
              <p><strong>Alert Settings:</strong></p>
              <ul>
                <li>Configure admin alert sounds and volume</li>
                <li>Set up score-based alerts with thresholds</li>
              </ul>
            `,
            screenshot: null
          },
          {
            title: 'Visual Settings',
            content: `
              <p>The <strong>Visuals</strong> tab controls colors and styling:</p>
              <p><strong>X Comm Visuals:</strong></p>
              <ul>
                <li><strong>Normal Admin Color</strong> - Background for untracked admins</li>
                <li><strong>Tracked Gradient</strong> - Color gradient for tracked admins</li>
                <li><strong>Border Color</strong> - Border color for tracked admins</li>
                <li><strong>Opacity</strong> - Transparency of the gradient overlay</li>
                <li><strong>Score Alert Colors</strong> - Colors for tokens meeting your score threshold</li>
              </ul>
              <p><strong>Tweets Visuals:</strong></p>
              <ul>
                <li><strong>Tracked</strong> - Color for tracked tweets</li>
                <li><strong>Border</strong> - Border color for tracked tweets</li>
                <li><strong>Opacity</strong> - Transparency of tweet overlay</li>
              </ul>
            `,
            screenshot: null
          },
          {
            title: 'Data Management',
            content: `
              <p>The <strong>Data</strong> tab provides options for managing your data:</p>
              <ul>
                <li><strong>Clear Cache</strong> - Clear cached community data to force refresh</li>
                <li><strong>Export</strong> - Download all your data (tracked admins, blacklist, settings) as JSON</li>
                <li><strong>Import</strong> - Load data from a previously exported JSON file</li>
                <li><strong>Share Config</strong> - Upload your config to the cloud for others to use</li>
                <li><strong>Browse Configs</strong> - Explore community-shared configurations</li>
              </ul>
              <p><strong>Google Sheets Integration:</strong></p>
              <ul>
                <li><strong>Last Sync</strong> - Shows when data was last synced from Google Sheets</li>
                <li><strong>Sync Now</strong> - Manually trigger a sync to get latest admin scores</li>
                <li><strong>Test Connection</strong> - Verify connection to Google Sheets</li>
              </ul>
            `,
            screenshot: null
          }
        ]
      }
    };
  }

  /**
   * Get a specific topic by ID
   * @param {string} topicId - The topic ID
   * @returns {Object|null} The topic data or null if not found
   */
  static getTopic(topicId) {
    const topics = this.getTopics();
    return topics[topicId] || null;
  }

  /**
   * Get all topic IDs in order
   * @returns {string[]} Array of topic IDs
   */
  static getTopicIds() {
    return Object.keys(this.getTopics());
  }

  /**
   * Search help content for a query
   * @param {string} query - Search query
   * @returns {Array} Array of matching sections with topic info
   */
  static search(query) {
    if (!query || query.trim().length === 0) return [];

    const searchTerm = query.toLowerCase().trim();
    const topics = this.getTopics();
    const results = [];

    for (const [topicId, topic] of Object.entries(topics)) {
      for (const section of topic.sections) {
        const titleMatch = section.title.toLowerCase().includes(searchTerm);
        const contentMatch = section.content.toLowerCase().includes(searchTerm);

        if (titleMatch || contentMatch) {
          results.push({
            topicId: topicId,
            topicTitle: topic.title,
            sectionTitle: section.title,
            section: section
          });
        }
      }
    }

    return results;
  }
}

// Export for use in other scripts
if (typeof window !== 'undefined') {
  window.HelpContent = HelpContent;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = HelpContent;
}

} // End of duplicate load guard
