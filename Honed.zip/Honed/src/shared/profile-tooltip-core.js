/**
 * Profile Tooltip - Shared Core Module
 * Cursor-following hover tooltip for admin profiles
 * Used by both pump.fun (content.js) and axiom.trade (axiom.js)
 */

// Guard against duplicate script loading
if (typeof window.ProfileTooltipCore !== 'undefined') {
  console.log('[ProfileTooltipCore] Already loaded, skipping...');
} else {

class ProfileTooltip {
  constructor() {
    this.tooltip = null;
    this.currentUsername = null;
    this.showDelay = 200; // ms before showing
    this.showTimer = null;
    this.isActive = false;
    this.targetElement = null;
    this._enabled = true; // Controls whether tooltip can be shown
    this.storageListenerBound = null;

    // Set up hot reload listener for sheet data changes
    this._setupHotReload();
  }

  // Set up storage listener for hot reload
  _setupHotReload() {
    this.storageListenerBound = this._handleStorageChange.bind(this);
    chrome.storage.onChanged.addListener(this.storageListenerBound);
  }

  // Handle storage changes - reload tooltip if currently visible
  _handleStorageChange(changes, areaName) {
    // Only care about local storage changes
    if (areaName !== 'local') return;

    // Check if admin stats were updated (tokens are fetched on-demand, not stored)
    if (changes.sheetsAdmins && this.isActive && this.currentUsername) {
      console.log('[ProfileTooltip] Admin stats updated, reloading tooltip for:', this.currentUsername);
      // Reload the tooltip data
      this._loadAndShow();
    }
  }

  // Cleanup storage listener (call this when destroying the tooltip)
  destroy() {
    if (this.storageListenerBound) {
      chrome.storage.onChanged.removeListener(this.storageListenerBound);
      this.storageListenerBound = null;
    }
  }

  // Create tooltip DOM element (single instance)
  _createTooltip() {
    const tooltip = document.createElement('div');
    tooltip.className = 'profile-tooltip';
    tooltip.innerHTML = `
      <div class="tooltip-banner"></div>
      <div class="tooltip-content">
        <div class="tooltip-avatar"></div>
        <div class="tooltip-info">
          <div class="tooltip-name"></div>
          <div class="tooltip-username"></div>
          <div class="tooltip-bio"></div>
          <div class="tooltip-stats">
            <span class="tooltip-stat">
              <strong class="stat-following">0</strong> Following
            </span>
            <span class="tooltip-stat">
              <strong class="stat-followers">0</strong> Followers
            </span>
          </div>
        </div>
      </div>
    `;
    tooltip.style.display = 'none';
    document.body.appendChild(tooltip);
    return tooltip;
  }

  // Show tooltip at cursor position
  show(element, username) {
    // Don't show if tooltip is disabled (e.g., modal is open)
    if (!this._enabled) return;

    // Check if element has data-no-tooltip attribute
    if (element && element.hasAttribute && element.hasAttribute('data-no-tooltip')) {
      return;
    }

    this.targetElement = element;
    this.currentUsername = username;

    if (this.showTimer) clearTimeout(this.showTimer);

    this.showTimer = setTimeout(async () => {
      await this._loadAndShow();
    }, this.showDelay);
  }

  // Update position as cursor moves
  updatePosition(clientX, clientY) {
    if (!this.tooltip || !this.isActive) return;

    const offset = 12; // px from cursor
    const tooltipRect = this.tooltip.getBoundingClientRect();

    let left = clientX + offset;
    let top = clientY + offset;

    // Prevent right edge overflow
    if (left + tooltipRect.width > window.innerWidth) {
      left = clientX - tooltipRect.width - offset;
    }

    // Prevent bottom edge overflow
    if (top + tooltipRect.height > window.innerHeight) {
      top = clientY - tooltipRect.height - offset;
    }

    this.tooltip.style.left = `${left}px`;
    this.tooltip.style.top = `${top}px`;
  }

  // Hide tooltip
  hide() {
    if (this.showTimer) {
      clearTimeout(this.showTimer);
      this.showTimer = null;
    }

    if (this.tooltip) {
      this.tooltip.style.display = 'none';
      this.tooltip.style.pointerEvents = 'none'; // Ensure it doesn't block clicks when hidden
      this.tooltip.style.visibility = 'hidden'; // Extra safety - ensure it's not visible
      this.tooltip.style.left = '-9999px'; // Move completely off-screen to prevent any click blocking
      this.tooltip.style.top = '-9999px';
      this.tooltip.removeAttribute('data-active'); // Mark as inactive for CSS
      this.isActive = false;
    }

    this.targetElement = null;
    this.currentUsername = null;
  }

  // Hide tooltip and disable hover (for modal coordination)
  hideTooltip() {
    this.hide();
    this._enabled = false;
  }

  // Re-enable tooltip hover (for modal coordination)
  restoreTooltip() {
    this._enabled = true;
  }

  // Fetch profile and populate tooltip (to be called by site-specific implementation)
  async _loadAndShow() {
    throw new Error('_loadAndShow must be implemented by site-specific wrapper');
  }

  // Ensure tooltip is visible and interactive (called by subclasses when showing)
  _ensureVisible() {
    if (this.tooltip) {
      this.tooltip.style.display = 'block';
      this.tooltip.style.pointerEvents = 'auto'; // Enable pointer events when visible
      this.tooltip.style.visibility = 'visible'; // Ensure visibility
      this.tooltip.setAttribute('data-active', 'true'); // Mark as active for CSS
      this.isActive = true;
    }
  }

  // Set loading state
  _setLoading() {
    const t = this.tooltip;

    // Ensure tooltip is visible before setting loading state
    this._ensureVisible();
    const banner = t.querySelector('.tooltip-banner');
    const avatar = t.querySelector('.tooltip-avatar');
    const name = t.querySelector('.tooltip-name');
    const username = t.querySelector('.tooltip-username');
    const bio = t.querySelector('.tooltip-bio');

    banner.style.backgroundImage = 'none';
    banner.style.backgroundColor = '#1a1a2e';
    avatar.style.backgroundImage = 'none';
    name.textContent = 'Loading...';
    username.textContent = '';
    bio.textContent = 'Fetching profile information...';
    t.querySelector('.stat-following').textContent = '-';
    t.querySelector('.stat-followers').textContent = '-';
  }

  // Set error state
  _setError() {
    const t = this.tooltip;
    t.querySelector('.tooltip-name').textContent = 'Profile unavailable';
    t.querySelector('.tooltip-username').textContent = '';
    t.querySelector('.tooltip-bio').textContent = 'Unable to load profile information.';
  }

  // Populate tooltip with data
  _populateData(data) {
    const t = this.tooltip;

    // Banner
    const banner = t.querySelector('.tooltip-banner');
    if (data.coverPicture || data.profile_banner_url) {
      banner.style.backgroundImage = `url('${data.coverPicture || data.profile_banner_url}')`;
    } else {
      banner.style.backgroundImage = 'none';
      banner.style.backgroundColor = '#1a1a2e';
    }

    // Avatar
    const avatar = t.querySelector('.tooltip-avatar');
    if (data.profilePicture || data.profile_image_url_https) {
      avatar.style.backgroundImage = `url('${data.profilePicture || data.profile_image_url_https}')`;
    } else {
      avatar.style.backgroundImage = 'none';
    }

    // Name, username, bio
    t.querySelector('.tooltip-name').textContent = data.name || data.display_name || 'Unknown';
    t.querySelector('.tooltip-username').textContent = `@${data.userName || data.screen_name || 'unknown'}`;
    t.querySelector('.tooltip-bio').textContent = data.description || data.bio || 'No bio available.';

    // Stats
    const following = data.friends_count || data.following || 0;
    const followers = data.followers_count || data.followers || 0;
    t.querySelector('.stat-following').textContent = this._formatNumber(following);
    t.querySelector('.stat-followers').textContent = this._formatNumber(followers);
  }

  // Format number for display
  _formatNumber(num) {
    const number = parseInt(num) || 0;
    if (number >= 1000000) {
      return (number / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    }
    if (number >= 1000) {
      return (number / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
    }
    return number.toString();
  }
}

// Export for use in content scripts
if (typeof window !== 'undefined') {
  window.ProfileTooltipCore = ProfileTooltip;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ProfileTooltip;
}

} // End of duplicate load guard
