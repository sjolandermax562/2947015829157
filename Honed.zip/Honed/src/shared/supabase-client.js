/**
 * Direct Supabase Client
 * Connects directly to Supabase for admin/token data
 * Uses secure RPC functions with license validation
 * 
 * SECURITY: No sensitive credentials exposed - only anon key which is public by design
 * Actual access control happens in Supabase RPC functions via device binding validation
 */

// Supabase public anon key - safe to expose, only grants access to RLS-protected data
const SUPABASE_URL = 'https://otmflwmqqjiatzvtsoys.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im90bWZsd21xcWppYXR6dnRzb3lzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjkxODY5NTUsImV4cCI6MjA4NDc2Mjk1NX0.Dy6pc_K64_riHTVxUuCLwzH5tE73Ze-nONyfdCp00_c';

class SupabaseDirectClient {
  constructor() {
    this.licenseKey = null;
    this.deviceId = null;
    this.isInitialized = false;
    this.pageSize = 1000;
    
    // Sync configuration (matches sheets-sync.js intervals)
    this.syncConfig = {
      recentWindowMs: 60 * 60 * 1000,  // 1 hour for recent syncs
      fullSyncIntervalMs: 60 * 60 * 1000  // 1 hour between full syncs
    };
  }

  async init(licenseKey, deviceId) {
    this.licenseKey = licenseKey;
    this.deviceId = deviceId;
    this.isInitialized = true;
    return this;
  }

  async _getStoredCredentials() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['licenseKey', 'honedDeviceId'], (result) => {
        resolve({
          licenseKey: result.licenseKey,
          deviceId: result.honedDeviceId
        });
      });
    });
  }

  async _ensureInitialized() {
    if (!this.isInitialized) {
      const { licenseKey, deviceId } = await this._getStoredCredentials();
      if (!licenseKey || !deviceId) {
        throw new Error('License not initialized. Please enter your license key.');
      }
      await this.init(licenseKey, deviceId);
    }
  }

  async _callRPC(functionName, params) {
    const url = `${SUPABASE_URL}/rest/v1/rpc/${functionName}`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation'
      },
      body: JSON.stringify(params)
    });

    if (!response.ok) {
      const errorText = await response.text();
      let errorData;
      try {
        errorData = JSON.parse(errorText);
      } catch (e) {
        errorData = { message: errorText };
      }
      
      if (response.status === 404) {
        throw new Error(`RPC function '${functionName}' not found. Please apply SQL migrations.`);
      }
      
      throw new Error(errorData.message || `RPC call failed: ${response.status}`);
    }

    return await response.json();
  }

  /**
   * Fetch all admins with pagination (FULL SYNC)
   */
  async getAdminsFull() {
    await this._ensureInitialized();
    
    console.log('[SupabaseDirect] Fetching all admins (full sync)...');
    
    const allAdmins = [];
    let page = 0;
    let hasMore = true;
    
    while (hasMore) {
      const data = await this._callRPC('get_admins_with_auth', {
        p_license_key: this.licenseKey,
        p_device_id: this.deviceId,
        p_page: page,
        p_page_size: this.pageSize
      });
      
      if (data && data.length > 0) {
        allAdmins.push(...data);
        hasMore = data.length === this.pageSize;
        
        if (hasMore) {
          console.log(`[SupabaseDirect] Admins page ${page + 1}: ${data.length} (total: ${allAdmins.length})`);
          page++;
        }
      } else {
        hasMore = false;
      }
      
      // Safety limit
      if (page > 100) {
        console.warn('[SupabaseDirect] Safety limit reached (100 pages)');
        break;
      }
    }
    
    console.log(`[SupabaseDirect] Full admins sync complete: ${allAdmins.length} records`);
    return this._transformAdmins(allAdmins);
  }

  /**
   * Fetch all tokens with pagination (FULL SYNC)
   */
  async getTokensFull() {
    await this._ensureInitialized();
    
    console.log('[SupabaseDirect] Fetching all tokens (full sync)...');
    
    const allTokens = [];
    let page = 0;
    let hasMore = true;
    
    while (hasMore) {
      const data = await this._callRPC('get_tokens_with_auth', {
        p_license_key: this.licenseKey,
        p_device_id: this.deviceId,
        p_page: page,
        p_page_size: this.pageSize
      });
      
      if (data && data.length > 0) {
        allTokens.push(...data);
        hasMore = data.length === this.pageSize;
        
        if (hasMore) {
          console.log(`[SupabaseDirect] Tokens page ${page + 1}: ${data.length} (total: ${allTokens.length})`);
          page++;
        }
      } else {
        hasMore = false;
      }
      
      // Safety limit
      if (page > 500) {
        console.warn('[SupabaseDirect] Safety limit reached (500 pages)');
        break;
      }
    }
    
    console.log(`[SupabaseDirect] Full tokens sync complete: ${allTokens.length} records`);
    return this._transformTokens(allTokens);
  }

  /**
   * Fetch recent admins (updated since timestamp) - INCREMENTAL SYNC
   * @param {number} since - Unix timestamp in seconds
   */
  async getAdminsRecent(since) {
    await this._ensureInitialized();
    
    console.log(`[SupabaseDirect] Fetching recent admins (since ${new Date(since * 1000).toISOString()})...`);
    
    const data = await this._callRPC('get_admins_recent_auth', {
      p_license_key: this.licenseKey,
      p_device_id: this.deviceId,
      p_since: since
    });
    
    const count = data?.length || 0;
    console.log(`[SupabaseDirect] Recent admins sync: ${count} records`);
    
    return this._transformAdmins(data || []);
  }

  /**
   * Fetch recent tokens (updated since timestamp) - INCREMENTAL SYNC
   * @param {number} since - Unix timestamp in seconds
   */
  async getTokensRecent(since) {
    await this._ensureInitialized();
    
    console.log(`[SupabaseDirect] Fetching recent tokens (since ${new Date(since * 1000).toISOString()})...`);
    
    const data = await this._callRPC('get_tokens_recent_auth', {
      p_license_key: this.licenseKey,
      p_device_id: this.deviceId,
      p_since: since
    });
    
    const count = data?.length || 0;
    console.log(`[SupabaseDirect] Recent tokens sync: ${count} records`);
    
    return this._transformTokens(data || []);
  }

  /**
   * Smart sync: decides between full and recent sync based on lastSync time
   * @param {number|null} lastSync - Unix timestamp of last successful sync (milliseconds)
   */
  async sync(lastSync = null) {
    await this._ensureInitialized();
    
    const now = Date.now();
    const needsFullSync = !lastSync || (now - lastSync) > this.syncConfig.fullSyncIntervalMs;
    
    if (needsFullSync) {
      console.log('[SupabaseDirect] Performing FULL sync...');
      const [admins, tokens] = await Promise.all([
        this.getAdminsFull(),
        this.getTokensFull()
      ]);
      
      return {
        success: true,
        admins,
        tokens,
        failedTokens: [],
        comments: [],
        dailyStats: [],
        syncType: 'FULL'
      };
    } else {
      // Recent sync - get records updated in last hour
      const since = Math.floor((now - this.syncConfig.recentWindowMs) / 1000);
      console.log('[SupabaseDirect] Performing RECENT sync...');
      
      const [admins, tokens] = await Promise.all([
        this.getAdminsRecent(since),
        this.getTokensRecent(since)
      ]);
      
      return {
        success: true,
        admins,
        tokens,
        failedTokens: [],
        comments: [],
        dailyStats: [],
        syncType: 'RECENT'
      };
    }
  }

  /**
   * Legacy method name - delegates to sync()
   */
  async fullSync(lastSync = null) {
    return this.sync(lastSync);
  }

  _transformAdmins(admins) {
    if (!admins || admins.length === 0) {
      return [['admin_username', 'total_rating', 'tokens_score_0', 'tokens_score_1', 'tokens_score_2', 
               'tokens_score_3', 'tokens_score_4', 'tokens_score_5', 'tokens_score_6', 
               'total_tokens_created', 'winrate', 'avg_migrate_time', 'last_active', 'last_updated']];
    }

    const header = ['admin_username', 'total_rating', 'tokens_score_0', 'tokens_score_1', 'tokens_score_2', 
                    'tokens_score_3', 'tokens_score_4', 'tokens_score_5', 'tokens_score_6', 
                    'total_tokens_created', 'winrate', 'avg_migrate_time', 'last_active', 'last_updated'];

    const rows = admins.map(admin => [
      (admin.admin_username || '').toLowerCase().trim(),
      admin.total_rating?.toString() || '0',
      admin.tokens_score_0?.toString() || '0',
      admin.tokens_score_1?.toString() || '0',
      admin.tokens_score_2?.toString() || '0',
      admin.tokens_score_3?.toString() || '0',
      admin.tokens_score_4?.toString() || '0',
      admin.tokens_score_5?.toString() || '0',
      admin.tokens_score_6?.toString() || '0',
      admin.total_tokens_created?.toString() || '0',
      ((admin.winrate || 0) * 100).toString(),
      this._formatMigrateTime(admin.avg_migrate_time),
      this._formatTimestamp(admin.last_active),
      this._formatTimestamp(admin.last_updated)
    ]);

    return [header, ...rows];
  }

  _transformTokens(tokens) {
    if (!tokens || tokens.length === 0) {
      return [['admin_username', 'base_token', 'token_name', 'token_symbol', 'community_link', 
               'token_age', 'market_cap', 'ath_market_cap', 'token_score', 'created_at']];
    }

    const header = ['admin_username', 'base_token', 'token_name', 'token_symbol', 'community_link', 
                    'token_age', 'market_cap', 'ath_market_cap', 'token_score', 'created_at'];

    const rows = tokens.map(token => [
      (token.admin_username || '').toLowerCase().trim(),
      token.base_token || '',
      token.token_name || '',
      token.token_symbol || '',
      token.twitter_url || token.website_url || '',
      this._calculateTokenAge(token.created_at),
      (token.market_cap ?? 0).toString(),
      token.ath_market_cap || '0',
      token.token_score?.toString() || '0',
      token.created_at?.toString() || ''
    ]);

    return [header, ...rows];
  }

  _formatMigrateTime(seconds) {
    if (!seconds || seconds === 0) return '';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${minutes}m`;
    if (minutes > 0) return `${minutes}m`;
    return '< 1m';
  }

  _formatTimestamp(timestamp) {
    if (!timestamp) return '';
    if (typeof timestamp === 'string' && (timestamp.includes('T') || timestamp.includes('-'))) {
      return timestamp;
    }
    const numTimestamp = typeof timestamp === 'string' ? parseInt(timestamp, 10) : timestamp;
    if (typeof numTimestamp === 'number' && !isNaN(numTimestamp) && numTimestamp > 0) {
      return new Date(numTimestamp * 1000).toISOString();
    }
    return '';
  }

  _calculateTokenAge(unixTimestamp) {
    if (!unixTimestamp) return '';
    const now = Math.floor(Date.now() / 1000);
    const diff = now - unixTimestamp;
    const days = Math.floor(diff / 86400);
    const hours = Math.floor((diff % 86400) / 3600);
    const minutes = Math.floor((diff % 3600) / 60);
    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  }
}

const supabaseDirect = new SupabaseDirectClient();

export { supabaseDirect, SupabaseDirectClient };

if (typeof window !== 'undefined') {
  window.SupabaseDirectClient = SupabaseDirectClient;
  window.supabaseDirect = supabaseDirect;
}
