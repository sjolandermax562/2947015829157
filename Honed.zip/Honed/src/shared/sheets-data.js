/**
 * Google Sheets Data Access Layer
 * Shared utilities for accessing cached sheet data from content scripts and popup
 * Uses IndexedDB for storage (no quota limits)
 */

// Guard against duplicate script loading
if (typeof window.SheetsData !== 'undefined') {
  console.log('[SheetsData] Already loaded, skipping...');
} else {

class SheetsData {
  // In-memory cache for instant lookups
  static _adminCache = null;
  static _cachePromise = null;
  static _cacheTimestamp = 0;
  static _cacheVersion = 0;  // Version counter to detect stale cache
  static _currentCacheVersion = 0;  // Expected version
  static _CACHE_TTL = 5 * 60 * 1000; // 5 minutes

  /**
   * Initialize the admin cache (loads all admins once)
   * @private
   */
  static async _ensureCache() {
    // Check if cache is still valid AND matches expected version
    if (this._adminCache &&
        (Date.now() - this._cacheTimestamp) < this._CACHE_TTL &&
        this._cacheVersion === this._currentCacheVersion) {
      return this._adminCache;
    }

    // If already loading with the correct version, wait for it
    if (this._cachePromise) {
      return this._cachePromise;
    }

    // Start loading with new version
    this._cacheVersion = this._currentCacheVersion;
    this._cachePromise = this._loadAllAdmins();

    try {
      const admins = await this._cachePromise;
      // Only store if we're still on the expected version (not invalidated during load)
      if (this._cacheVersion === this._currentCacheVersion) {
        this._adminCache = admins;
        this._cacheTimestamp = Date.now();
        return admins;
      } else {
        // Cache was invalidated during load, load fresh data
        return this._ensureCache();
      }
    } finally {
      this._cachePromise = null;
    }
  }

  /**
   * Load all admins from background into memory
   * @private
   */
  static async _loadAllAdmins() {
    console.log('[SheetsData] Loading all admins into memory cache...');
    const startTime = performance.now();

    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { action: 'getAllAdminStats' },
        (response) => {
          if (chrome.runtime.lastError) {
            console.error('[SheetsData] Cache load error:', chrome.runtime.lastError);
            resolve({});
            return;
          }

          if (response?.success && response.admins) {
            const elapsed = performance.now() - startTime;
            console.log(`[SheetsData] Cached ${Object.keys(response.admins).length} admins in ${elapsed.toFixed(0)}ms`);
            resolve(response.admins);
          } else {
            resolve({});
          }
        }
      );
    });
  }

  /**
   * Get admin stats for a specific username
   * Uses in-memory cache for instant lookups
   * @param {string} username - Admin username
   * @returns {Promise<Object|null>} Admin stats or null
   */
  static async getAdminStats(username) {
    if (!username || typeof username !== 'string') {
      console.warn('[SheetsData] getAdminStats called with invalid username:', username);
      return null;
    }
    const usernameLower = username.toLowerCase().trim();

    // Ensure cache is loaded
    const cache = await this._ensureCache();

    // Instant lookup from memory
    if (cache[usernameLower]) {
      return cache[usernameLower];
    }

    // Not found in cache
    return null;
  }

  /**
   * Invalidate the cache (call after data updates)
   * Forces a complete reload from IndexedDB on next access
   */
  static invalidateCache() {
    console.log('[SheetsData] Cache invalidated - will reload from IndexedDB on next access');
    this._adminCache = null;
    this._cacheTimestamp = 0;
    this._cachePromise = null;  // Also clear any pending load to force fresh data
    this._currentCacheVersion++;  // Increment version to invalidate any in-flight requests
  }

  /**
   * Force refresh - invalidates cache and reloads data immediately
   * Returns the fresh data once loaded
   */
  static async forceRefresh() {
    console.log('[SheetsData] Force refreshing admin data...');
    this.invalidateCache();
    return this._ensureCache();
  }

  /**
   * Get tokens for a specific admin - from background script's IndexedDB
   * Uses message passing to access background's data (content scripts can't access background's IndexedDB)
   * @param {string} username - Admin username
   * @returns {Promise<Array>} Array of token data
   */
  static async getAdminTokens(username) {
    const usernameLower = username.toLowerCase().trim();

    // Use message passing to get tokens from background script's IndexedDB
    // (content scripts and service workers have separate IndexedDB contexts)
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { action: 'fetchAdminTokens', username: usernameLower },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (response?.success) {
            resolve(response.tokens || []);
          } else {
            reject(new Error(response?.error || 'Failed to fetch tokens'));
          }
        }
      );
    });
  }

  /**
   * Get all admin stats (from cache)
   * @returns {Promise<Object>} All admin stats
   */
  static async getAllAdmins() {
    return this._ensureCache();
  }

  /**
   * Get last sync timestamp and error
   * @returns {Promise<Object>} { lastSync: timestamp|null, error: string|null }
   */
  static async getLastSync() {
    // Use message passing to get sync info from background script's IndexedDB
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { action: 'getSyncInfo' },
        (response) => {
          if (chrome.runtime.lastError) {
            console.error('[SheetsData] Message error:', chrome.runtime.lastError);
            resolve({ lastSync: null, error: null });
            return;
          }

          if (response?.success) {
            resolve({
              lastSync: response.lastSync || null,
              error: response.error || null
            });
          } else {
            resolve({ lastSync: null, error: null });
          }
        }
      );
    });
  }

  /**
   * Format score with color based on rating
   * @param {number} rating - Total rating (lower is better)
   * @returns {Object} { formatted: string, color: string, class: string }
   */
  static formatScore(rating) {
    const formatted = rating.toFixed(1);

    if (rating <= 1.5) {
      return { formatted, color: '#10b981', class: 'score-excellent' }; // Green
    } else if (rating <= 2.5) {
      return { formatted, color: '#22d3ee', class: 'score-good' }; // Cyan
    } else if (rating <= 3.5) {
      return { formatted, color: '#fbbf24', class: 'score-fair' }; // Yellow
    } else {
      return { formatted, color: '#ef4444', class: 'score-poor' }; // Red
    }
  }

  /**
   * Check if sheet data is available and recent
   * @param {number} maxAge - Maximum age in milliseconds (default: 1 hour)
   * @returns {Promise<boolean>}
   */
  static async isDataFresh(maxAge = 60 * 60 * 1000) {
    const { lastSync } = await this.getLastSync();
    if (!lastSync) return false;
    return (Date.now() - lastSync) < maxAge;
  }
}

// Export for use in content scripts and popup
if (typeof window !== 'undefined') {
  window.SheetsData = SheetsData;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = SheetsData;
}

} // End of duplicate load guard
