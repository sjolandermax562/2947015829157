/**
 * Single Import Primitive
 *
 * Centralized import functionality for all file-based imports.
 * Supports multiple import formats with backward compatibility.
 *
 * Data Structure Types:
 *
 * TrackedAdmin (stored in trackedAdmins):
 * @typedef {Object} TrackedAdmin
 * @property {string} username - Username handle (e.g., "username")
 * @property {string} [userName] - Alternate username field (legacy)
 * @property {string} [screen_name] - Alternate username field (legacy Twitter API format)
 * @property {string} profileImage - Profile image URL
 * @property {string} [profilePicture] - Alternate profile image field (legacy)
 * @property {string} [profile_image_url_https] - Alternate profile image field (Twitter API format)
 * @property {number} [followersCount] - Follower count
 * @property {number} [followers] - Alternate follower count field
 * @property {number} [followers_count] - Alternate follower count field (Twitter API format)
 * @property {string} [name] - Display name
 * @property {string} [banner] - Banner image URL
 * @property {string} [description] - Bio/description
 * @property {number} [followingCount] - Following count
 * @property {number} [addedAt] - Timestamp when admin was added
 */

/**
 * Import result object
 * @typedef {Object} ImportResult
 * @property {boolean} success - Whether import was successful
 * @property {string[]} messages - List of status messages
 * @property {number} importedCount - Number of admins imported
 * @property {Object} summary - Summary of what was imported
 */

/**
 * Import options
 * @typedef {Object} ImportOptions
 * @property {boolean} [mergeWithExisting=true] - Merge with existing admins or replace
 * @property {boolean} [importSettings=true] - Import settings if present
 * @property {boolean} [importBlacklist=true] - Import blacklist if present
 * @property {boolean} [importProfileCache=true] - Import profile cache if present
 * @property {number} [batchSize=20] - Batch size for importing large lists
 */

const DEFAULT_IMPORT_OPTIONS = {
  mergeWithExisting: true,
  importSettings: true,
  importBlacklist: true,
  importProfileCache: true,
  batchSize: 20
};

/**
 * Parse imported JSON data
 * @param {string|object} data - JSON string or parsed object
 * @returns {Object} Parsed import data with normalized structure
 */
function parseImportData(data) {
  let imported;

  // Parse JSON if string
  if (typeof data === 'string') {
    try {
      imported = JSON.parse(data);
    } catch (error) {
      throw new Error('Invalid JSON: ' + error.message);
    }
  } else {
    imported = data;
  }

  // Normalize to standard structure
  const result = {
    admins: [],
    settings: {},
    blacklist: [],
    profileCache: {},
    tweets: [],
    tweetsBlacklist: []
  };

  // Handle old format (simple array of admins)
  if (Array.isArray(imported)) {
    result.admins = imported;
    return result;
  }

  // Handle new export format (object with settings and lists)
  if (imported && typeof imported === 'object') {
    // Check for admin lists nested under settings
    if (imported.settings && typeof imported.settings === 'object') {
      const settings = imported.settings;

      if (settings.adminAlertsList && Array.isArray(settings.adminAlertsList)) {
        result.admins = settings.adminAlertsList;
      }
      if (settings.adminBlacklistList && Array.isArray(settings.adminBlacklistList)) {
        result.blacklist = settings.adminBlacklistList;
      }
      if (settings.trackedTweetsList && Array.isArray(settings.trackedTweetsList)) {
        result.tweets = settings.trackedTweetsList;
      }
      if (settings.blacklistedTweetsList && Array.isArray(settings.blacklistedTweetsList)) {
        result.tweetsBlacklist = settings.blacklistedTweetsList;
      }

      // Import other settings (remove admin lists as we handle separately)
      result.settings = { ...settings };
      delete result.settings.adminAlertsList;
      delete result.settings.adminBlacklistList;
      delete result.settings.trackedTweetsList;
      delete result.settings.blacklistedTweetsList;
    }

    // Also check for admin lists at root level (alternative format)
    if (imported.adminAlertsList && Array.isArray(imported.adminAlertsList)) {
      result.admins = imported.adminAlertsList;
    }
    if (imported.adminBlacklistList && Array.isArray(imported.adminBlacklistList)) {
      result.blacklist = imported.adminBlacklistList;
    }
    if (imported.trackedTweetsList && Array.isArray(imported.trackedTweetsList)) {
      result.tweets = imported.trackedTweetsList;
    }
    if (imported.blacklistedTweetsList && Array.isArray(imported.blacklistedTweetsList)) {
      result.tweetsBlacklist = imported.blacklistedTweetsList;
    }

    if (imported.adminProfileCache && typeof imported.adminProfileCache === 'object') {
      result.profileCache = imported.adminProfileCache;
    }

    // Store any other root-level settings
    if (imported.settings && typeof imported.settings === 'object') {
      Object.assign(result.settings, imported.settings);
    }
  }

  return result;
}

/**
 * Normalize admin object to standard format
 * @param {Object} admin - Admin object from import
 * @returns {Object} Normalized admin object
 */
function normalizeAdmin(admin) {
  return {
    username: admin.username || admin.userName || admin.screen_name,
    displayName: admin.displayName || admin.name || `@${admin.username || admin.userName || admin.screen_name}`,
    verified: admin.verified || false,
    dateAdded: admin.dateAdded || admin.addedAt || Date.now(),
    profileImage: admin.profileImage || admin.profilePicture || admin.profile_image_url_https,
    followersCount: admin.followersCount || admin.followers || admin.followers_count || 0,
    name: admin.name,
    banner: admin.banner,
    description: admin.description,
    followingCount: admin.followingCount || admin.following || admin.friends_count
  };
}

/**
 * Check if an admin needs profile refetching
 * @param {Object} admin - Admin object to check
 * @returns {boolean} True if admin needs profile refetch
 */
function needsProfileRefetch(admin) {
  const username = admin.username || admin.userName || admin.screen_name;
  const profileImage = admin.profileImage || admin.profilePicture || admin.profile_image_url_https;
  const followersCount = admin.followersCount || admin.followers || admin.followers_count || 0;

  // Needs refetch if:
  // 1. No username (but this shouldn't happen if we got this far)
  if (!username) return false;

  // 2. No profile image or invalid/default image
  const hasInvalidImage = !profileImage ||
    profileImage === 'undefined' ||
    profileImage.includes('default_profile') ||
    profileImage.includes('abs.twimg.com/sticky/default_profile');

  // 3. Has 0 or missing followers (indicates incomplete data)
  const hasZeroFollowers = followersCount === 0;

  return hasInvalidImage || hasZeroFollowers;
}

/**
 * Get existing tracked admins from storage
 * @returns {Promise<Array>} Existing tracked admins
 */
function getExistingAdmins() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['trackedAdmins'], (result) => {
      resolve(result.trackedAdmins || []);
    });
  });
}

/**
 * Save tracked admins to storage
 * @param {Array} admins - Admins to save
 * @returns {Promise<void>}
 */
function saveAdmins(admins) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ trackedAdmins: admins }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

/**
 * Import admins with batch processing to handle quota errors
 * @param {Array} adminsToImport - Admins to import
 * @param {Object} options - Import options
 * @returns {Promise<{importedCount: number, skippedCount: number}>}
 */
async function importAdminsBatch(adminsToImport, options) {
  const existing = await getExistingAdmins();
  const combined = options.mergeWithExisting ? [...existing] : [];
  let importedCount = 0;
  let skippedCount = 0;

  for (const admin of adminsToImport) {
    const normalized = normalizeAdmin(admin);

    if (!normalized.username) {
      skippedCount++;
      continue;
    }

    // Check if admin already exists (case-insensitive)
    const exists = combined.find(a => {
      const existingUsername = a.username || a.userName || a.screen_name;
      return existingUsername && existingUsername.toLowerCase() === normalized.username.toLowerCase();
    });

    if (exists) {
      skippedCount++;
      continue;
    }

    combined.push(normalized);
    importedCount++;
  }

  // Save in batches to handle quota errors
  const batchSize = options.batchSize;
  try {
    await saveAdmins(combined.slice(0, batchSize));
    await new Promise(r => setTimeout(r, 100));

    for (let i = batchSize; i < combined.length; i += batchSize) {
      const batch = combined.slice(0, i + batchSize);
      await saveAdmins(batch);
      await new Promise(r => setTimeout(r, 100));
    }
  } catch (error) {
    console.error('Error saving admins in batches:', error);
    throw error;
  }

  return { importedCount, skippedCount };
}

/**
 * Import settings to sync storage
 * @param {Object} settings - Settings to import
 * @returns {Promise<void>}
 */
function importSettings(settings) {
  return new Promise((resolve, reject) => {
    // Map export setting names to internal setting names
    const settingsToSave = {};
    Object.keys(settings).forEach(key => {
      // Skip large arrays that should be in local storage, not sync storage
      if (key === 'adminAlertsList' || key === 'adminBlacklistList' || key === 'adminProfileCache') {
        return;
      }

      const mappedKey = key === 'detectXCommunity' ? 'xCommunityEnabled' :
                       key === 'adminAlertSound' ? 'adminAlertEnabled' :
                       key === 'adminAlertNotification' ? 'adminAlertEnabled' : key;
      settingsToSave[mappedKey] = settings[key];
    });

    chrome.storage.sync.set(settingsToSave, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

/**
 * Import blacklist to local storage
 * Normalizes blacklist items before saving to ensure consistent data structure
 * @param {Array} blacklist - Blacklist to import
 * @returns {Promise<void>}
 */
function importBlacklist(blacklist) {
  return new Promise((resolve, reject) => {
    // Normalize each blacklist item to ensure it has the required fields
    const normalizedBlacklist = blacklist.map(item => {
      const username = item.username || item.userName || item.screen_name;
      if (!username) {
        return null;
      }
      return {
        username: username,
        displayName: item.displayName || item.name || `@${username}`,
        verified: item.verified || false,
        dateAdded: item.dateAdded || item.addedAt || Date.now(),
        profileImage: item.profileImage || item.profilePicture || item.profile_image_url_https,
        followersCount: item.followersCount || item.followers || item.followers_count || 0,
        name: item.name,
        banner: item.banner,
        description: item.description
      };
    }).filter(Boolean); // Remove any null items

    chrome.storage.local.set({ blacklistedAdmins: normalizedBlacklist }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

/**
 * Save tracked tweets to local storage
 * @param {Array} tweets - Tweets to save
 * @returns {Promise<void>}
 */
function saveTrackedTweets(tweets) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ trackedTweets: tweets }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

/**
 * Import tracked tweets to local storage
 * @param {Array} tweets - Tweets to import
 * @returns {Promise<void>}
 */
function importTrackedTweets(tweets) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ trackedTweets: tweets }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

/**
 * Save tweets blacklist to local storage
 * @param {Array} tweetsBlacklist - Tweets blacklist to save
 * @returns {Promise<void>}
 */
function saveTweetsBlacklist(tweetsBlacklist) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ blacklistedTweets: tweetsBlacklist }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

/**
 * Import tweets blacklist to local storage
 * @param {Array} tweetsBlacklist - Tweets blacklist to import
 * @returns {Promise<void>}
 */
function importTweetsBlacklist(tweetsBlacklist) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ blacklistedTweets: tweetsBlacklist }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

/**
 * Fetch profile data for a single admin
 * @param {string} username - Username to fetch profile for
 * @returns {Promise<Object|null>} Profile data or null if failed
 */
function fetchAdminProfile(username) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({
      action: 'fetchUserProfile',
      username: username
    }, (response) => {
      if (response && response.success) {
        const userData = response.data?.data || response.data;
        if (userData && (userData.userName || userData.screen_name)) {
          resolve({
            username: userData.userName || userData.screen_name,
            profileImage: userData.profilePicture || userData.profile_image_url_https,
            followersCount: userData.followers || userData.followers_count,
            name: userData.name,
            banner: userData.coverPicture || userData.profile_banner_url,
            description: userData.description,
            followingCount: userData.following || userData.friends_count
          });
        } else {
          resolve(null);
        }
      } else {
        resolve(null);
      }
    });
  });
}

/**
 * Batch fetch profile data for admins missing profile images or with incomplete data
 * @param {Array} admins - Admins to fetch profiles for
 * @param {Object} existingCache - Existing profile cache
 * @returns {Promise<Object>} Updated admin list with profile data (filters out failed fetches)
 */
async function fetchMissingProfiles(admins, existingCache = {}) {
  const adminsNeedingFetch = admins.filter(admin => {
    // Check if admin needs refetch based on our criteria
    if (needsProfileRefetch(admin)) {
      return true;
    }

    // Also check if they have valid cached data
    const username = admin.username || admin.userName || admin.screen_name;
    const cachedData = existingCache[username.toLowerCase()];
    if (cachedData && cachedData.profilePicture && cachedData.followers) {
      return false; // Has valid cache, no need to fetch
    }

    return !username;
  });

  if (adminsNeedingFetch.length === 0) {
    return admins;
  }

  // Track which usernames failed to fetch (suspended, not found, etc)
  const failedUsernames = new Set();

  // Fetch profiles with rate limiting (delay between requests)
  const results = await Promise.allSettled(
    adminsNeedingFetch.map(async (admin, index) => {
      // Add delay to avoid rate limiting (3 requests per second)
      await new Promise(r => setTimeout(r, 350 * index));

      const username = admin.username || admin.userName || admin.screen_name;
      const profileData = await fetchAdminProfile(username);

      if (profileData) {
        // Merge profile data with admin object
        return {
          ...admin,
          ...profileData
        };
      } else {
        failedUsernames.add(username.toLowerCase());
        return null; // Return null to indicate failed fetch
      }
    })
  );

  // Map results back to admins
  const fetchedMap = new Map();
  results.forEach((result, index) => {
    if (result.status === 'fulfilled' && result.value !== null) {
      const username = adminsNeedingFetch[index].username || adminsNeedingFetch[index].userName || adminsNeedingFetch[index].screen_name;
      fetchedMap.set(username.toLowerCase(), result.value);
    }
  });

  // Update admins with fetched data, filtering out failed fetches
  const validAdmins = admins.filter(admin => {
    const username = (admin.username || admin.userName || admin.screen_name)?.toLowerCase();
    // Keep admin if they weren't in the needing fetch list OR if they were successfully fetched
    return !failedUsernames.has(username);
  });

  // Map to fetched data where available, otherwise keep original
  return validAdmins.map(admin => {
    const username = admin.username || admin.userName || admin.screen_name;
    const fetched = fetchedMap.get(username.toLowerCase());
    return fetched || admin;
  });
}

/**
 * Import profile cache to local storage
 * @param {Object} profileCache - Profile cache to import
 * @param {boolean} mergeWithExisting - Merge with existing cache or replace
 * @returns {Promise<void>}
 */
function importProfileCache(profileCache, mergeWithExisting = true) {
  return new Promise((resolve, reject) => {
    const cacheSize = JSON.stringify(profileCache).length;

    // Only import cache if it's under 1MB to avoid quota errors
    if (cacheSize >= 1000000) {
      reject(new Error(`Profile cache too large: ${Math.round(cacheSize/1024)}KB`));
      return;
    }

    if (mergeWithExisting) {
      // Get existing cache and merge
      chrome.storage.local.get(['adminProfileCache'], (result) => {
        const existingCache = result.adminProfileCache || {};
        const mergedCache = { ...existingCache, ...profileCache };

        chrome.storage.local.set({ adminProfileCache: mergedCache }, () => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve();
          }
        });
      });
    } else {
      chrome.storage.local.set({ adminProfileCache: profileCache }, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    }
  });
}

/**
 * Main import function - single entry point for all imports
 *
 * @param {string|object|File} data - Data to import (JSON string, parsed object, or File object)
 * @param {ImportOptions} options - Import options
 * @returns {Promise<ImportResult>} Import result with status and summary
 *
 * @example
 * // Import from JSON string
 * const result = await importData(jsonString);
 *
 * @example
 * // Import from File object
 * const result = await importData(fileObject);
 *
 * @example
 * // Import with options
 * const result = await importData(data, { importProfileCache: false });
 */
export async function importData(data, options = {}) {
  const opts = { ...DEFAULT_IMPORT_OPTIONS, ...options };
  const messages = [];
  const summary = {
    admins: { imported: 0, skipped: 0, failed: false },
    settings: { imported: false, failed: false },
    blacklist: { imported: 0, failed: false },
    tweets: { imported: 0, failed: false },
    tweetsBlacklist: { imported: 0, failed: false },
    profileCache: { imported: 0, failed: false }
  };

  try {
    // If data is a File object, read it first
    let parsedData;
    if (data instanceof File) {
      parsedData = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsText(data);
      });
    } else {
      parsedData = data;
    }

    // Parse import data
    const importData = parseImportData(parsedData);

    // Import tracked admins
    if (importData.admins.length > 0) {
      try {
        // First import the profile cache if available, so fetchMissingProfiles can use it
        if (Object.keys(importData.profileCache).length > 0) {
          try {
            await importProfileCache(importData.profileCache, true);
          } catch (e) {
            // Silently fail if profile cache import fails
          }
        }

        // Get existing cache for profile fetching
        let existingCache = {};
        try {
          existingCache = await new Promise((resolve) => {
            chrome.storage.local.get(['adminProfileCache'], (result) => {
              resolve(result.adminProfileCache || {});
            });
          });
        } catch (e) {
          // Silently fail if getting existing cache fails
        }

        // Fetch profiles for admins missing them (filters out suspended/failed fetches)
        const originalCount = importData.admins.length;
        const adminsWithProfiles = await fetchMissingProfiles(importData.admins, existingCache);
        const filteredCount = originalCount - adminsWithProfiles.length;

        const result = await importAdminsBatch(adminsWithProfiles, opts);
        summary.admins.imported = result.importedCount;
        summary.admins.skipped = result.skippedCount;
        messages.push(`${result.importedCount} tracked admins imported`);
        if (result.skippedCount > 0) {
          messages.push(`${result.skippedCount} admins skipped (already exist)`);
        }
        if (filteredCount > 0) {
          messages.push(`${filteredCount} admins skipped (suspended/failed fetch)`);
        }
      } catch (error) {
        console.error('Failed to import tracked admins:', error);
        summary.admins.failed = true;
        if (error.message && error.message.includes('quota')) {
          messages.push('tracked admins (quota exceeded)');
        } else {
          messages.push('tracked admins (failed)');
        }
      }
    }

    // Import settings
    if (opts.importSettings && Object.keys(importData.settings).length > 0) {
      try {
        await importSettings(importData.settings);
        summary.settings.imported = true;
        messages.push('settings imported');
      } catch (error) {
        console.error('Failed to import settings:', error);
        summary.settings.failed = true;
        messages.push('settings (failed)');
      }
    }

    // Import blacklist
    if (opts.importBlacklist && importData.blacklist.length > 0) {
      try {
        // First import the profile cache if available (for tracked admins we did it above, but do it again if needed)
        if (Object.keys(importData.profileCache).length > 0 && summary.admins.imported === 0) {
          try {
            await importProfileCache(importData.profileCache, true);
          } catch (e) {
            // Silently fail if profile cache import fails
          }
        }

        // Get existing cache for profile fetching
        let existingCache = {};
        try {
          existingCache = await new Promise((resolve) => {
            chrome.storage.local.get(['adminProfileCache'], (result) => {
              resolve(result.adminProfileCache || {});
            });
          });
        } catch (e) {
          // Silently fail if getting existing cache fails
        }

        // Fetch profiles for blacklisted admins missing them (filters out suspended/failed fetches)
        const originalBlacklistCount = importData.blacklist.length;
        const blacklistWithProfiles = await fetchMissingProfiles(importData.blacklist, existingCache);
        const filteredBlacklistCount = originalBlacklistCount - blacklistWithProfiles.length;

        await importBlacklist(blacklistWithProfiles);
        summary.blacklist.imported = blacklistWithProfiles.length;
        messages.push(`${blacklistWithProfiles.length} blacklisted admins`);
        if (filteredBlacklistCount > 0) {
          messages.push(`${filteredBlacklistCount} blacklist entries skipped (suspended/failed fetch)`);
        }
      } catch (error) {
        console.error('Failed to import blacklist:', error);
        summary.blacklist.failed = true;
        messages.push('blacklisted admins (failed)');
      }
    } else {
      // Blacklist import skipped
    }

    // Import tracked tweets
    if (importData.tweets.length > 0) {
      try {
        await importTrackedTweets(importData.tweets);
        summary.tweets.imported = importData.tweets.length;
        messages.push(`${importData.tweets.length} tracked tweets`);
      } catch (error) {
        console.error('Failed to import tracked tweets:', error);
        summary.tweets.failed = true;
        messages.push('tracked tweets (failed)');
      }
    }

    // Import tweets blacklist
    if (importData.tweetsBlacklist.length > 0) {
      try {
        await importTweetsBlacklist(importData.tweetsBlacklist);
        summary.tweetsBlacklist.imported = importData.tweetsBlacklist.length;
        messages.push(`${importData.tweetsBlacklist.length} blacklisted tweets`);
      } catch (error) {
        console.error('Failed to import tweets blacklist:', error);
        summary.tweetsBlacklist.failed = true;
        messages.push('tweets blacklist (failed)');
      }
    }

    // Import profile cache (if not already imported above)
    if (opts.importProfileCache && Object.keys(importData.profileCache).length > 0 && summary.admins.imported === 0 && summary.blacklist.imported === 0) {
      try {
        await importProfileCache(importData.profileCache, true);
        summary.profileCache.imported = Object.keys(importData.profileCache).length;
        messages.push(`${Object.keys(importData.profileCache).length} profile cache entries`);
      } catch (error) {
        console.error('Failed to import profile cache:', error);
        summary.profileCache.failed = true;
        if (error.message.includes('too large')) {
          messages.push(error.message);
        } else {
          messages.push('profile cache (failed)');
        }
      }
    }

    if (messages.length === 0) {
      messages.push('No data found to import');
    }

    return {
      success: true,
      messages,
      importedCount: summary.admins.imported,
      summary
    };

  } catch (error) {
    console.error('Import error:', error);
    return {
      success: false,
      messages: [`Failed to import: ${error.message}`],
      importedCount: 0,
      summary
    };
  }
}

/**
 * Import admins from bundled JSON file
 * @param {string} bundledJsonPath - Path to bundled JSON file
 * @returns {Promise<ImportResult>} Import result
 */
export async function importFromBundledFile(bundledJsonPath) {
  try {
    const response = await fetch(chrome.runtime.getURL(bundledJsonPath));
    if (!response.ok) {
      throw new Error(`Failed to load bundled file: ${response.status}`);
    }

    const data = await response.json();
    return await importData(data);
  } catch (error) {
    console.error('Error importing from bundled file:', error);
    return {
      success: false,
      messages: [`Failed to import from bundled file: ${error.message}`],
      importedCount: 0,
      summary: {}
    };
  }
}

// Export for use in non-module contexts
if (typeof window !== 'undefined') {
  window.ImportModule = { importData, importFromBundledFile };
}
