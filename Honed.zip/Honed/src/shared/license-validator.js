class LicenseValidator {
  constructor() {
    this.validationUrl = 'https://2947015829157.vercel.app/api/validate';
    this.checkIntervalMinutes = 5; // Use minutes for chrome.alarms
    this.checkTimer = null;
    this.alarmName = 'licenseValidatorHeartbeat';
    this.isValid = false;
    this.lastReason = null;
    this.listeners = [];
    this.initialized = false;
    this.deviceId = null;
    this.authToken = null;
    this.updateRequired = false;
    this.updateInfo = null;

    // SECURITY: Offline grace period settings
    this.offlineGracePeriodDays = 7; // Allow 7 days offline after last successful validation
    this.maxOfflineAttempts = 10; // Max consecutive offline failures before blocking
  }

  async getDeviceId() {
    if (this.deviceId) return this.deviceId;

    return new Promise((resolve) => {
      chrome.storage.local.get(['honedDeviceId'], async (result) => {
        if (result.honedDeviceId) {
          this.deviceId = result.honedDeviceId;
          resolve(this.deviceId);
        } else {
          // Generate a stable device fingerprint from browser characteristics
          // This persists across extension reinstalls
          const fingerprint = await this._generateFingerprint();
          const newDeviceId = `fp-${fingerprint}`;

          chrome.storage.local.set({ honedDeviceId: newDeviceId }, () => {
            this.deviceId = newDeviceId;
            console.log('[LicenseValidator] Generated device fingerprint:', newDeviceId);
            resolve(newDeviceId);
          });
        }
      });
    });
  }

  /**
   * Generate a stable device fingerprint from browser/system characteristics.
   * This fingerprint will be the same across extension reinstalls on the same device.
   */
  async _generateFingerprint() {
    const components = [];

    // Platform info from Chrome API (most stable)
    try {
      const platformInfo = await chrome.runtime.getPlatformInfo();
      components.push(platformInfo.os);
      components.push(platformInfo.arch);
    } catch (e) {
      // Fallback to navigator
      components.push(navigator.platform || 'unknown');
    }

    // Hardware info (stable across reinstalls)
    components.push(`cores-${navigator.hardwareConcurrency || 'unknown'}`);
    components.push(`lang-${navigator.language || 'unknown'}`);

    // Screen characteristics (change only if display changes)
    // Note: screen/window may not be available in service worker context
    try {
      if (typeof screen !== 'undefined') {
        components.push(`screen-${screen.width}x${screen.height}`);
        components.push(`color-${screen.colorDepth}`);
      } else {
        components.push('screen-unknown');
        components.push('color-unknown');
      }
      if (typeof window !== 'undefined' && window.devicePixelRatio) {
        components.push(`dpi-${Math.round(window.devicePixelRatio * 100)}`);
      } else {
        components.push('dpi-unknown');
      }
    } catch (e) {
      components.push('screen-unknown');
      components.push('color-unknown');
      components.push('dpi-unknown');
    }

    // Timezone (rarely changes)
    try {
      components.push(`tz-${Intl.DateTimeFormat().resolvedOptions().timeZone}`);
    } catch (e) {
      components.push(`tz-unknown`);
    }

    // Create a hash from all components
    const fingerprintString = components.join('|');
    const hash = await this._hashFingerprint(fingerprintString);
    
    // Return first 16 chars of hash (sufficient entropy)
    return hash.substring(0, 16);
  }

  /**
   * Create a simple hash from a string
   */
  async _hashFingerprint(str) {
    try {
      const encoder = new TextEncoder();
      const data = encoder.encode(str);
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    } catch (e) {
      // Fallback: simple string hash if crypto not available
      let hash = 0;
      for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
      }
      return Math.abs(hash).toString(16).padStart(16, '0');
    }
  }

  async init() {
    if (this.initialized) return;

    console.log('[LicenseValidator] Initializing...');

    await this.getDeviceId();

    const storedKey = await this.getLicenseKey();

    if (storedKey) {
      await this.validate(storedKey);
    } else {
      this.isValid = false;
      this.lastReason = 'NO_KEY';
      this.notifyListeners();
      await this._updateStorage(false);
    }

    this.startPeriodicCheck();
    this.initialized = true;

    console.log('[LicenseValidator] Initialized. Valid:', this.isValid, 'Reason:', this.lastReason);
  }

  async getLicenseKey() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['licenseKey'], (result) => {
        resolve(result.licenseKey || null);
      });
    });
  }

  async saveLicenseKey(key) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ licenseKey: key }, () => {
        console.log('[LicenseValidator] License key saved');
        resolve();
      });
    });
  }

  async clearLicenseKey() {
    return new Promise((resolve) => {
      chrome.storage.local.remove(['licenseKey'], () => {
        console.log('[LicenseValidator] License key cleared');
        resolve();
      });
    });
  }

  async validate(key = null) {
    const keyToCheck = key || await this.getLicenseKey();

    if (!keyToCheck) {
      this.isValid = false;
      this.lastReason = 'NO_KEY';
      this.notifyListeners();
      await this._updateStorage(false);
      return false;
    }

    try {
      const deviceId = await this.getDeviceId();
      
      // Get extension version from manifest
      const extensionVersion = chrome.runtime?.getManifest?.()?.version || '1.0';

      console.log('[LicenseValidator] Validating license key for device:', deviceId, 'version:', extensionVersion);
      const response = await fetch(`${this.validationUrl}?key=${encodeURIComponent(keyToCheck)}&deviceId=${encodeURIComponent(deviceId)}&version=${encodeURIComponent(extensionVersion)}`);
      const data = await response.json();

      console.log('[LicenseValidator] Validation response:', data);

      this.isValid = data.valid;
      this.lastReason = data.reason;

      if (data.token) {
        this.authToken = data.token;
        await this._storeToken(data.token);
      }

      // Check for version update requirement (from extension_versions table)
      if (data.updateNotification && data.updateNotification.active && data.reason === 'UPDATE_REQUIRED') {
        console.log('[LicenseValidator] Version update required:', {
          currentVersion: data.updateNotification.currentVersion,
          minimumVersion: data.updateNotification.minimumVersion,
          latestVersion: data.updateNotification.latestVersion
        });
        await this._handleUpdateNotification(data.updateNotification);
        this.updateRequired = true;
        this.updateInfo = data.updateNotification;
        console.log('[LicenseValidator] ⚠️ Version update required - extension disabled until updated');
      } else {
        this.updateRequired = false;
        this.updateInfo = null;
        console.log('[LicenseValidator] ✅ Version check passed');
        
        // Clear any cached update requirement from storage
        await new Promise((resolve) => {
          chrome.storage.local.remove(['updateRequired', 'updateInfo'], () => {
            console.log('[LicenseValidator] Cleared cached update requirement');
            resolve();
          });
        });
      }

      await this._updateStorage(this.isValid);

      // SECURITY: Track last successful validation for offline grace period
      if (this.isValid) {
        await new Promise((resolve) => {
          chrome.storage.local.set({
            lastSuccessfulValidation: Date.now(),
            offlineFailureCount: 0 // Reset failure count on successful validation
          }, () => {
            console.log('[LicenseValidator] ✅ Last successful validation timestamp updated');
            resolve();
          });
        });
      } else {
        // SECURITY: Clear grace period tracking for revoked/invalid licenses
        if (this.lastReason === 'REVOKED' || this.lastReason === 'INVALID') {
          await new Promise((resolve) => {
            chrome.storage.local.remove(['lastSuccessfulValidation', 'offlineFailureCount'], () => {
              console.log('[LicenseValidator] ⚠️ Grace period cleared due to license revocation/invalidation');
              resolve();
            });
          });
        }
      }

      this.notifyListeners();

      if (this.isValid) {
        console.log('[LicenseValidator] ✅ License valid');
      } else {
        console.warn('[LicenseValidator] ❌ License invalid:', data.message);
      }

      return this.isValid;

    } catch (error) {
      console.error('[LicenseValidator] Validation error:', error);

      // SECURITY: Check if we can allow offline grace period access
      const gracePeriodResult = await this._checkOfflineGracePeriod();

      if (gracePeriodResult.allowed) {
        console.warn(`[LicenseValidator] Network error - allowing offline access (${gracePeriodResult.daysRemaining} days grace remaining)`);
        this.isValid = true;
        this.lastReason = 'OFFLINE_GRACE_PERIOD';
        this.notifyListeners();
        return true;
      } else {
        console.error('[LicenseValidator] Network error - offline grace period expired or no prior validation');
        this.isValid = false;
        this.lastReason = gracePeriodResult.reason || 'NETWORK_ERROR_NO_GRACE';
        this.notifyListeners();
        return false;
      }
    }
  }

  // Removed: No longer storing licenseValid/validUntil in storage
  // Always validate with server instead of trusting client-side storage
  async _updateStorage(isValid) {
    // Storage update removed - validation state now comes from server only
    return Promise.resolve();
  }

  async _storeToken(token) {
    return new Promise((resolve) => {
      const tokenExpiry = Date.now() + (5 * 60 * 1000);

      chrome.storage.local.set({
        licenseToken: token,
        licenseTokenExpiry: tokenExpiry
      }, () => {
        console.log('[LicenseValidator] Token stored');
        resolve();
      });
    });
  }

  async getAuthToken() {
    if (this.authToken && this.isValid) {
      return this.authToken;
    }

    return new Promise((resolve) => {
      chrome.storage.local.get(['licenseToken', 'licenseTokenExpiry'], (result) => {
        const token = result.licenseToken;
        const expiry = result.licenseTokenExpiry || 0;
        const now = Date.now();

        if (token && expiry > now) {
          this.authToken = token;
          resolve(token);
        } else {
          resolve(null);
        }
      });
    });
  }

  /**
   * SECURITY: Check if offline grace period access is allowed
   * Only allows offline use if:
   * 1. User has been validated successfully before (has lastSuccessfulValidation timestamp)
   * 2. Last validation was within the grace period (7 days default)
   * 3. Hasn't exceeded max offline attempts
   * @returns {Object} { allowed: boolean, reason: string, daysRemaining: number }
   * @private
   */
  async _checkOfflineGracePeriod() {
    return new Promise((resolve) => {
      chrome.storage.local.get(
        ['lastSuccessfulValidation', 'offlineFailureCount', 'lastOfflineFailureTime', 'licenseTokenExpiry'],
        async (result) => {
          const now = Date.now();

          // Check 1: Must have had at least one successful validation
          if (!result.lastSuccessfulValidation) {
            console.warn('[LicenseValidator] Offline grace denied - no prior successful validation');
            resolve({
              allowed: false,
              reason: 'NO_PRIOR_VALIDATION',
              daysRemaining: 0
            });
            return;
          }

          // Check 2: Must be within grace period (days since last validation)
          const daysSinceLastValidation = (now - result.lastSuccessfulValidation) / (1000 * 60 * 60 * 24);
          const daysRemaining = Math.max(0, this.offlineGracePeriodDays - daysSinceLastValidation);

          if (daysSinceLastValidation > this.offlineGracePeriodDays) {
            console.error(`[LicenseValidator] Offline grace denied - expired (${daysSinceLastValidation.toFixed(1)} days > ${this.offlineGracePeriodDays} days)`);

            // Reset failure count after grace period expires (give user another chance)
            chrome.storage.local.set({ offlineFailureCount: 0 });

            resolve({
              allowed: false,
              reason: 'GRACE_PERIOD_EXPIRED',
              daysRemaining: 0
            });
            return;
          }

          // Check 3: Check consecutive offline failure count
          const failureCount = result.offlineFailureCount || 0;
          const lastFailureTime = result.lastOfflineFailureTime || 0;

          // Reset failure count if it's been more than 1 hour since last failure
          if (now - lastFailureTime > 60 * 60 * 1000) {
            chrome.storage.local.set({ offlineFailureCount: 0 });
          } else if (failureCount >= this.maxOfflineAttempts) {
            console.error(`[LicenseValidator] Offline grace denied - too many failures (${failureCount} >= ${this.maxOfflineAttempts})`);
            resolve({
              allowed: false,
              reason: 'TOO_MANY_OFFLINE_FAILURES',
              daysRemaining: Math.floor(daysRemaining)
            });
            return;
          }

          // Check 4: JWT token should ideally still be valid (5 min expiration)
          // If JWT is expired, we're relying purely on grace period
          const tokenExpiry = result.licenseTokenExpiry || 0;
          const hasValidToken = tokenExpiry > now;

          if (!hasValidToken) {
            console.warn('[LicenseValidator] JWT token expired, using grace period only');
          }

          // Increment offline failure counter
          const newFailureCount = (now - lastFailureTime <= 60 * 60 * 1000) ? failureCount + 1 : 1;
          chrome.storage.local.set({
            offlineFailureCount: newFailureCount,
            lastOfflineFailureTime: now
          });

          console.log(`[LicenseValidator] Offline grace allowed - ${daysRemaining.toFixed(1)} days remaining (failure ${newFailureCount}/${this.maxOfflineAttempts})`);

          resolve({
            allowed: true,
            reason: 'OFFLINE_GRACE_PERIOD',
            daysRemaining: Math.floor(daysRemaining)
          });
        }
      );
    });
  }

  startPeriodicCheck() {
    // Clear any existing interval
    if (this.checkTimer) {
      clearInterval(this.checkTimer);
      this.checkTimer = null;
    }

    // Use chrome.alarms for persistence across service worker restarts
    chrome.alarms.create(this.alarmName, {
      delayInMinutes: this.checkIntervalMinutes,
      periodInMinutes: this.checkIntervalMinutes
    });

    console.log('[LicenseValidator] Periodic checks started using chrome.alarms');
  }

  stopPeriodicCheck() {
    if (this.checkTimer) {
      clearInterval(this.checkTimer);
      this.checkTimer = null;
    }

    // Clear the alarm
    chrome.alarms.clear(this.alarmName);

    console.log('[LicenseValidator] Periodic checks stopped');
  }

  isLicenseValid() {
    return this.isValid;
  }

  getValidationReason() {
    return this.lastReason;
  }

  onValidationChange(callback) {
    this.listeners.push(callback);
  }

  removeValidationListener(callback) {
    this.listeners = this.listeners.filter(cb => cb !== callback);
  }

  notifyListeners() {
    this.listeners.forEach(callback => {
      try {
        callback(this.isValid, this.lastReason);
      } catch (error) {
        console.error('[LicenseValidator] Listener error:', error);
      }
    });
  }

  getErrorMessage() {
    switch (this.lastReason) {
      case 'NO_KEY':
        return 'Please enter your license key to use this extension.';
      case 'INVALID':
        return 'Invalid license key. Please purchase a license to use this extension.';
      case 'REVOKED':
        return 'Your license has been revoked. Please contact support.';
      case 'MAINTENANCE':
        return 'Extension is temporarily disabled for maintenance. Please check back later.';
      case 'DEVICE_MISMATCH':
        return 'This license key is already bound to another device. Each key can only be used on one device.';
      case 'NO_PRIOR_VALIDATION':
        return 'Unable to validate license. Please connect to the internet and validate your license first.';
      case 'GRACE_PERIOD_EXPIRED':
        return 'Offline grace period expired. Please connect to the internet to validate your license.';
      case 'TOO_MANY_OFFLINE_FAILURES':
        return 'Too many offline validation attempts. Please connect to the internet and validate your license.';
      case 'NETWORK_ERROR_NO_GRACE':
        return 'Network error and no grace period available. Please check your connection.';
      case 'OFFLINE_GRACE_PERIOD':
        return 'License valid (offline mode). Some features may be limited.';
      case 'UPDATE_REQUIRED':
        return 'Extension update required. Please update to the latest version.';
      default:
        return 'License validation failed. Please try again later.';
    }
  }

  checkFeature(featureName = 'feature') {
    if (this.updateRequired) {
      console.warn(`[LicenseValidator] Feature "${featureName}" blocked - update required`);
      return false;
    }
    if (!this.isValid) {
      console.warn(`[LicenseValidator] Feature "${featureName}" blocked - license invalid`);
      return false;
    }
    return true;
  }

  isUpdateRequired() {
    return this.updateRequired;
  }

  getUpdateInfo() {
    return this.updateInfo;
  }

  async _handleUpdateNotification(notification) {
    const storage = await this._getNotificationStorage();
    // Include version (updated_at timestamp) in hash so re-enabling shows again
    const notificationHash = await this._hashNotification(notification.message + (notification.version || ''));

    if (storage.lastShownHash !== notificationHash) {
      console.log('[LicenseValidator] 📢 Update notification:', notification.message);

      // Store in chrome.storage for popup to access
      await new Promise((resolve) => {
        chrome.storage.local.set({
          updateRequired: true,
          updateInfo: {
            message: notification.message,
            downloadUrl: notification.downloadUrl || null,
            download_url: notification.download_url || null,
            currentVersion: notification.currentVersion,
            minimumVersion: notification.minimumVersion,
            latestVersion: notification.latestVersion,
            timestamp: Date.now()
          },
          pendingUpdateNotification: {
            message: notification.message,
            downloadUrl: notification.downloadUrl || null,
            timestamp: Date.now()
          }
        }, resolve);
      });

      await this._setNotificationStorage(notificationHash);
    }
  }

  async _getNotificationStorage() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['updateNotificationStorage'], (result) => {
        resolve(result.updateNotificationStorage || { lastShownHash: null });
      });
    });
  }

  async _setNotificationStorage(hash) {
    return new Promise((resolve) => {
      chrome.storage.local.set({
        updateNotificationStorage: {
          lastShownHash: hash,
          updatedAt: Date.now()
        }
      }, resolve);
    });
  }

  async _hashNotification(message) {
    const msgBuffer = new TextEncoder().encode(message);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 16);
  }
}

const licenseValidator = new LicenseValidator();

// Listen for alarm events (persists across service worker restarts)
if (typeof chrome !== 'undefined' && chrome.alarms) {
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === licenseValidator.alarmName) {
      console.log('[LicenseValidator] Alarm triggered - periodic validation check');
      licenseValidator.validate().catch(err => {
        console.error('[LicenseValidator] Periodic validation failed:', err);
      });
    }
  });
}

if (typeof window !== 'undefined') {
  window.LicenseValidator = LicenseValidator;
  window.licenseValidator = licenseValidator;
}

export { licenseValidator, LicenseValidator };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { licenseValidator, LicenseValidator };
}
