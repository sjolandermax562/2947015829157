/**
 * Supabase Sync Service
 * Runs in background service worker
 * Fetches admin stats and tokens from Vercel API (secure backend)
 * Uses IndexedDB for storage (no quota limits)
 */

import { storage as indexedDBStorage } from '../shared/database.js';
import { licenseValidator } from '../shared/license-validator.js';
import { supabaseDirect } from '../shared/supabase-client.js';

class SheetsSyncService {
  constructor() {
    // Adaptive sync intervals (in seconds) - MINIMAL to reduce Supabase reads
    this.intervals = {
      recentActive: 300,     // 5 minutes - recent sync when active
      fullActive: 3600,      // 1 hour - full sync when active
      idle: null             // never sync when idle - user must return to active tab
    };
    this.currentInterval = this.intervals.recentActive;
    this.lastActiveTime = Date.now();
    this.activeTabCount = 0;
    this.fullSyncInterval = 60 * 60 * 1000; // 1 hour between full syncs
    this.lastFullSync = 0;
    this.isSyncing = false;
    this.syncTimeout = null;
    
    // FEATURE FLAG: Use direct Supabase connection instead of Vercel
    // Set to true to bypass Vercel's 4.5MB response size limits
    this.useDirectSupabase = true;
    
    // Vercel API URLs (fallback)
    this.apiUrl = 'https://2947015829157.vercel.app/api/supabase';
    this.recentApiUrl = 'https://2947015829157.vercel.app/api/supabase/recent';
  }

  /**
   * Initialize the sync service
   */
  async init() {
    // Initialize license validator first
    await licenseValidator.init();

    // Monitor active tabs for adaptive sync intervals
    chrome.tabs.onActivated.addListener(() => {
      this.lastActiveTime = Date.now();
      this._countActiveTabs();
      this._scheduleNextSync();
    });

    chrome.tabs.onRemoved.addListener(() => {
      this._countActiveTabs();
      this._scheduleNextSync();
    });

    // Also monitor tab updates (URL changes, page loads)
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      if (changeInfo.status === 'complete' && tab.url) {
        if (tab.url.includes('trade.padre.gg') || tab.url.includes('axiom.trade')) {
          this.lastActiveTime = Date.now();
          this._countActiveTabs();
          this._scheduleNextSync();
        }
      }
    });

    // Initial tab count
    this._countActiveTabs();

    // Set up a backup alarm (5 minutes) in case setTimeout doesn't persist
    chrome.alarms.create('sheetsSync', {
      delayInMinutes: 5,
      periodInMinutes: 5
    });

    // Listen for alarm events (backup)
    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name === 'sheetsSync') {
        // Only sync if license is valid
        if (licenseValidator.isLicenseValid()) {
          this.sync().catch(err => {
            console.error('[SheetsSync] Alarm sync failed:', err);
          });
        } else {
          console.log('[SheetsSync] Alarm sync skipped - license invalid');
        }
      }
    });

    // Listen for license validation state changes (in-memory)
    licenseValidator.onValidationChange((isValid, reason) => {
      if (isValid) {
        console.log('[SheetsSync] License became valid, triggering sync...');
        this.sync().catch(err => {
          console.error('[SheetsSync] Sync after license validation failed:', err);
        });
      }
    });

    // Listen for storage changes (detect license key/token changes from popup)
    chrome.storage.onChanged.addListener(async (changes, areaName) => {
      if (areaName === 'local') {
        // Check if license token was added/updated (indicates successful validation)
        if (changes.licenseToken && changes.licenseToken.newValue) {
          console.log('[SheetsSync] License token detected in storage, re-validating...');
          // Re-validate to ensure in-memory state is updated
          const storedKey = await licenseValidator.getLicenseKey();
          if (storedKey) {
            await licenseValidator.validate(storedKey);
          }
          // Now trigger sync
          if (licenseValidator.isLicenseValid()) {
            this.sync().catch(err => {
              console.error('[SheetsSync] Sync after license token change failed:', err);
            });
          }
        }
        // Check if license key was added (may also trigger validation)
        if (changes.licenseKey && changes.licenseKey.newValue && !changes.licenseKey.oldValue) {
          console.log('[SheetsSync] License key added, waiting for validation...');
          // Give a moment for validation to complete, then try syncing
          setTimeout(async () => {
            // Re-validate to ensure in-memory state is updated
            await licenseValidator.validate(changes.licenseKey.newValue);
            if (licenseValidator.isLicenseValid()) {
              this.sync().catch(err => {
                console.error('[SheetsSync] Sync after license key addition failed:', err);
              });
            }
          }, 1000);
        }
      }
    });

    // Do initial sync after 2 seconds to let extension fully load
    // Only schedule if license is already valid; otherwise wait for license change event
    if (licenseValidator.isLicenseValid()) {
      console.log('[SheetsSync] License valid on init, scheduling initial sync...');
      setTimeout(() => {
        this.sync().catch(err => {
          console.error('[SheetsSync] Initial sync failed:', err);
        });
      }, 2000);
    } else {
      console.log('[SheetsSync] No valid license on init, waiting for license key entry...');
    }

    // Schedule next adaptive sync
    this._scheduleNextSync();
  }

  /**
   * Count active tabs on padre.gg or axiom.trade
   * @private
   */
  _countActiveTabs() {
    chrome.tabs.query({}, (tabs) => {
      this.activeTabCount = tabs.filter(tab =>
        tab.url && (tab.url.includes('trade.padre.gg') || tab.url.includes('axiom.trade'))
      ).length;
      console.log(`[SheetsSync] Active tabs: ${this.activeTabCount}`);
    });
  }

  /**
   * Check if user is idle (no active tabs or inactive for 10 minutes)
   * @private
   */
  _isUserIdle() {
    const inactiveTime = Date.now() - this.lastActiveTime;
    return inactiveTime > 600000 || this.activeTabCount === 0; // 10 min inactive or no active tabs
  }

  /**
   * Schedule the next sync based on activity level
   * @private
   */
  async _scheduleNextSync() {
    // Clear existing timeout if any
    if (this.syncTimeout) {
      clearTimeout(this.syncTimeout);
    }

    // Determine interval based on activity
    // If idle and idle interval is null, don't schedule any sync
    if (this._isUserIdle() && this.intervals.idle === null) {
      console.log('[SheetsSync] User is idle - sync paused until user returns');
      return;
    }

    const intervalMs = this._isUserIdle()
      ? this.intervals.idle * 1000
      : this.intervals.recentActive * 1000;

    const intervalLabel = this._isUserIdle() ? 'idle' : 'active';
    console.log(`[SheetsSync] Scheduling next sync in ${intervalMs / 1000}s (${intervalLabel} mode)`);

    this.syncTimeout = setTimeout(async () => {
      // Only sync if license is valid
      if (licenseValidator.isLicenseValid()) {
        try {
          await this.sync();
        } catch (err) {
          console.error('[SheetsSync] Scheduled sync failed:', err);
        }
      } else {
        console.log('[SheetsSync] Scheduled sync skipped - license invalid, will retry when license becomes valid');
      }
      // Schedule next sync after completion (or skip if license invalid)
      this._scheduleNextSync();
    }, intervalMs);
  }

  /**
   * Parse a number that may use European locale format (comma as decimal, period as thousands)
   * Handles both formats:
   * - European: "2,69" or "1.234,56" (comma decimal, period thousands)
   * - US: "2.69" or "1,234.56" (period decimal, comma thousands)
   */
  parseLocaleNumber(value) {
    if (!value) return 0;

    // If already a number, return as-is
    if (typeof value === 'number') return value;

    const str = String(value).trim();

    // Detect European format: last comma before end of number
    // European: "2,69" or "1.234,56" - comma is decimal separator
    // US: "2.69" or "1,234.56" - period is decimal separator

    // Check if the last separator is a comma (European decimal)
    const lastCommaIndex = str.lastIndexOf(',');
    const lastPeriodIndex = str.lastIndexOf('.');

    if (lastCommaIndex > lastPeriodIndex) {
      // European format: comma is decimal, period is thousands
      // Remove period (thousands), then replace comma with period (decimal)
      const normalized = str.replace(/\./g, '').replace(',', '.');
      return parseFloat(normalized) || 0;
    } else {
      // US format or already has period as decimal
      // Remove commas (thousands separator)
      const normalized = str.replace(/,/g, '');
      return parseFloat(normalized) || 0;
    }
  }

  /**
   * Fetch data from Vercel API
   * @param {string} range - Optional sheet range to fetch
   * @param {number} since - Optional Unix timestamp for incremental sync
   * @returns {Promise<Object>} API response
   */
  async fetchFromAPI(range = null, since = null) {
    // Add cache-busting timestamp to ensure fresh data
    const timestamp = Date.now();
    let url = range
      ? `${this.apiUrl}?range=${encodeURIComponent(range)}&_t=${timestamp}`
      : `${this.apiUrl}?_t=${timestamp}`;

    // Add incremental sync parameter if provided (convert to seconds)
    if (since) {
      url += `&since=${Math.floor(since / 1000)}`;
    }

    // Get auth token from license validator
    const token = await licenseValidator.getAuthToken();

    const headers = {
      'Content-Type': 'application/json'
    };

    // Add Authorization header if we have a valid token
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(url, {
      headers,
      // Ensure fetch doesn't use browser cache
      cache: 'no-store'
    });
    const data = await response.json();

    if (!response.ok) {
      // Check if it's an auth error
      if (response.status === 401) {
        throw new Error('License validation required. Please check your license key.');
      }
      throw new Error(data.error || 'API request failed');
    }

    if (!data.success) {
      throw new Error(data.error || 'API request failed');
    }

    return data;
  }

  /**
   * Parse admin stats from sheet data
   */
  parseAdminStats(values) {
    if (!values || values.length < 2) return {};

    const admins = {};
    let skippedRows = 0;
    let processedRows = 0;

    for (let i = 1; i < values.length; i++) {
      const row = values[i];
      const username = row[0]?.toLowerCase().trim();

      if (!username) {
        skippedRows++;
        continue;
      }

      processedRows++;

      admins[username] = {
        admin_username: row[0]?.trim() || '',
        total_rating: this.parseLocaleNumber(row[1]),
        tokens_score_0: parseInt(row[2]) || 0,
        tokens_score_1: parseInt(row[3]) || 0,
        tokens_score_2: parseInt(row[4]) || 0,
        tokens_score_3: parseInt(row[5]) || 0,
        tokens_score_4: parseInt(row[6]) || 0,
        tokens_score_5: parseInt(row[7]) || 0,
        tokens_score_6: parseInt(row[8]) || 0,  // Column I (8) - Score 6 (Failed)
        total_tokens_created: parseInt(row[9]) || 0,
        winrate: this.parseLocaleNumber(row[10]) / 100, // Convert percentage to decimal
        avg_migrate_time: row[11]?.trim() || '',  // Column L (11) - Avg Migrate Time
        last_active: row[12]?.trim() || '',  // Column M (12) - Last Active
        last_updated: row[13]?.trim() || ''   // Column N (13) - Last Updated
      };
    }

    console.log('[SheetsSync] Parsed admin stats for', Object.keys(admins).length, 'admins from', processedRows, 'rows. Skipped', skippedRows, 'rows with empty usernames.');
    console.log('[SheetsSync] Admin usernames (first 10):', Object.keys(admins).slice(0, 10));

    return admins;
  }

  /**
   * Calculate admin stats from their tokens (fallback for admins not in Supabase admins table)
   * @param {string} username - Admin username
   * @param {Array} tokens - Array of token data
   * @returns {Object} Calculated admin stats
   */
  calculateAdminStatsFromTokens(username, tokens) {
    if (!tokens || tokens.length === 0) {
      return null;
    }

    // Initialize counters
    const scores = { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 };
    let totalRating = 0;
    let migratedCount = 0;
    let totalMigratedTime = 0;
    let maxMarketCap = 0;

    // Calculate stats from tokens
    for (const token of tokens) {
      const score = token.token_score || 0;
      scores[score]++;

      // Calculate average rating
      totalRating += score;

      // Track migration stats
      if (score <= 2) {  // Score 0-2 means migrated
        migratedCount++;

        // Try to parse migrate time from token_age (e.g., "1h 23m", "45m")
        if (token.token_age) {
          const minutes = this.parseTokenAgeToMinutes(token.token_age);
          totalMigratedTime += minutes;
        }

        // Track ATH market cap
        const ath = this.parseLocaleNumber(token.ath_market_cap);
        if (ath > maxMarketCap) {
          maxMarketCap = ath;
        }
      }
    }

    const tokenCount = tokens.length;
    const avgRating = totalRating / tokenCount;
    const winrate = migratedCount / tokenCount;  // % of tokens with score ≤ 2
    const avgMigrateTimeMinutes = migratedCount > 0 ? totalMigratedTime / migratedCount : null;

    // Format avg_migrate_time as human-readable string (e.g., "4h 0m")
    const avgMigrateTimeFormatted = avgMigrateTimeMinutes !== null
      ? this.formatMinutesToTime(avgMigrateTimeMinutes)
      : null;

    // Return admin stats object matching Supabase schema
    return {
      admin_username: username,
      total_rating: avgRating,
      tokens_score_0: scores[0],
      tokens_score_1: scores[1],
      tokens_score_2: scores[2],
      tokens_score_3: scores[3],
      tokens_score_4: scores[4],
      tokens_score_5: scores[5],
      tokens_score_6: scores[6],
      total_tokens_created: tokenCount,
      winrate: winrate,
      avg_migrate_time: avgMigrateTimeFormatted,
      last_active: null,  // We don't have this from tokens
      last_updated: null,  // We don't have this from tokens
      _calculated_from_tokens: true  // Flag to indicate this is calculated data
    };
  }

  /**
   * Format minutes to human-readable time string (e.g., "4h 0m", "45m", "1d 2h")
   * @param {number} minutes - Minutes to format
   * @returns {string} Formatted time string
   */
  formatMinutesToTime(minutes) {
    if (!minutes || minutes === 0) return '';

    const days = Math.floor(minutes / (24 * 60));
    const hours = Math.floor((minutes % (24 * 60)) / 60);
    const mins = Math.floor(minutes % 60);

    if (days > 0) {
      return `${days}d ${hours}h`;
    } else if (hours > 0) {
      return `${hours}h ${mins}m`;
    } else {
      return `${mins}m`;
    }
  }

  /**
   * Parse token age string (e.g., "1h 23m", "45m", "2d ago") to minutes
   * @param {string} tokenAge - Token age string
   * @returns {number} Minutes
   */
  parseTokenAgeToMinutes(tokenAge) {
    if (!tokenAge || typeof tokenAge !== 'string') return 0;

    let totalMinutes = 0;

    // Parse days
    const daysMatch = tokenAge.match(/(\d+)\s*d/);
    if (daysMatch) {
      totalMinutes += parseInt(daysMatch[1]) * 24 * 60;
    }

    // Parse hours
    const hoursMatch = tokenAge.match(/(\d+)\s*h/);
    if (hoursMatch) {
      totalMinutes += parseInt(hoursMatch[1]) * 60;
    }

    // Parse minutes
    const minutesMatch = tokenAge.match(/(\d+)\s*m/);
    if (minutesMatch) {
      totalMinutes += parseInt(minutesMatch[1]);
    }

    return totalMinutes;
  }

  /**
   * Calculate token creation date from token_age string
   * @param {string} tokenAge - Token age string (e.g., "24d ago", "1h 23m", "45m")
   * @param {number} referenceTime - Reference timestamp (default: current time)
   * @returns {Date|null} Estimated creation date or null if unable to parse
   */
  calculateTokenCreationDate(tokenAge, referenceTime = Date.now()) {
    if (!tokenAge || typeof tokenAge !== 'string') return null;

    const minutesAgo = this.parseTokenAgeToMinutes(tokenAge);
    if (minutesAgo === 0) return null;

    // Calculate creation date by subtracting minutes from reference time
    return new Date(referenceTime - minutesAgo * 60 * 1000);
  }

  /**
   * Format date to YYYY-MM-DD string
   * @param {Date} date - Date object
   * @returns {string} Formatted date string
   */
  formatDateToYYYYMMDD(date) {
    if (!date || !(date instanceof Date) || isNaN(date.getTime())) return null;
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  /**
   * Calculate daily stats from all tokens
   * Aggregates tokens by creation date and calculates daily metrics
   * @param {Object} allTokens - Object mapping username -> array of tokens
   * @param {number} referenceTime - Reference timestamp for calculating token ages (default: Date.now())
   * @returns {Array} Array of daily stats objects
   */
  calculateDailyStats(allTokens, referenceTime = Date.now()) {
    // Map to store tokens grouped by date
    const tokensByDate = new Map();

    // Group all tokens by their creation date
    for (const [username, tokenList] of Object.entries(allTokens)) {
      for (const token of tokenList) {
        // Try to use created_at timestamp if available, otherwise calculate from token_age
        let creationDate = null;

        // Check if token has a created_at timestamp (Unix timestamp in seconds or milliseconds)
        if (token.created_at) {
          const createdAt = typeof token.created_at === 'string'
            ? parseInt(token.created_at, 10)
            : token.created_at;

          // Check if it's in seconds (Unix timestamp) or milliseconds (JavaScript timestamp)
          // Unix timestamps are typically around 1.7 billion for 2024, JS timestamps are much larger
          const timestamp = createdAt > 10000000000 ? createdAt : createdAt * 1000;
          creationDate = new Date(timestamp);
        }

        // Fallback to calculating from token_age
        if (!creationDate || isNaN(creationDate.getTime())) {
          creationDate = this.calculateTokenCreationDate(token.token_age, referenceTime);
        }

        if (!creationDate || isNaN(creationDate.getTime())) continue;

        const dateKey = this.formatDateToYYYYMMDD(creationDate);
        if (!dateKey) continue;

        if (!tokensByDate.has(dateKey)) {
          tokensByDate.set(dateKey, []);
        }
        tokensByDate.get(dateKey).push({ ...token, admin_username: username });
      }
    }

    // Calculate stats for each date
    const dailyStats = [];
    for (const [date, tokens] of tokensByDate) {
      if (tokens.length === 0) continue;

      // Calculate basic stats
      const totalTokens = tokens.length;
      const scores = tokens.map(t => t.token_score || 0);
      const avgScore = scores.reduce((sum, s) => sum + s, 0) / totalTokens;
      const goodTokens = scores.filter(s => s >= 0 && s <= 2).length;
      const winRate = goodTokens / totalTokens;

      // Find top admin by score (lowest avg score is best)
      const adminStats = new Map();
      for (const token of tokens) {
        const admin = token.admin_username || 'unknown';
        if (!adminStats.has(admin)) {
          adminStats.set(admin, { totalScore: 0, count: 0, tokens: [] });
        }
        const stats = adminStats.get(admin);
        stats.totalScore += (token.token_score || 0);
        stats.count++;
        stats.tokens.push(token);
      }

      // Find best admin (lowest average score with at least 2 tokens)
      let topAdmin = null;
      let topAdminAvgScore = null;
      let topAdminTokens = 0;

      for (const [admin, stats] of adminStats) {
        const avgScore = stats.totalScore / stats.count;
        // Require at least 2 tokens to be considered "top admin" for the day
        if (stats.count >= 2) {
          if (topAdmin === null || avgScore < topAdminAvgScore) {
            topAdmin = admin;
            topAdminAvgScore = avgScore;
            topAdminTokens = stats.count;
          }
        }
      }

      // Find top 3 tokens by ATH
      const tokensByATH = [...tokens].sort((a, b) => {
        const athA = this.parseLocaleNumber(b.ath_market_cap);
        const athB = this.parseLocaleNumber(a.ath_market_cap);
        return athA - athB;
      });

      const top3Tokens = tokensByATH.slice(0, 3).map(t => ({
        address: t.base_token || '',
        score: t.token_score || 0,
        ath: this.parseLocaleNumber(t.ath_market_cap),
        symbol: t.token_symbol || ''
      }));

      // Build daily stats object
      dailyStats.push({
        date,
        tokens_created: totalTokens,
        avg_score: avgScore,
        win_rate: winRate,
        good_tokens_0_2: goodTokens,
        top_admin: topAdmin,
        top_admin_avg_score: topAdminAvgScore,
        top_admin_tokens: topAdminTokens,
        token_1_address: top3Tokens[0]?.address || null,
        token_1_score: top3Tokens[0]?.score || null,
        token_1_ath: top3Tokens[0]?.ath || null,
        token_2_address: top3Tokens[1]?.address || null,
        token_2_score: top3Tokens[1]?.score || null,
        token_2_ath: top3Tokens[1]?.ath || null,
        token_3_address: top3Tokens[2]?.address || null,
        token_3_score: top3Tokens[2]?.score || null,
        token_3_ath: top3Tokens[2]?.ath || null
      });
    }

    // Sort by date descending
    dailyStats.sort((a, b) => b.date.localeCompare(a.date));

    console.log(`[SheetsSync] Calculated daily stats for ${dailyStats.length} days`);
    return dailyStats;
  }

  /**
   * Parse token data from sheet
   * @param {Array} values - Sheet values
   * @param {boolean} isFailed - Whether these are failed tokens (default: false)
   */
  parseTokens(values, isFailed = false) {
    if (!values || values.length < 2) return {};

    const tokens = {};
    let skippedRows = 0;
    let processedRows = 0;

    for (let i = 1; i < values.length; i++) {
      const row = values[i];
      const username = row[0]?.toLowerCase().trim();

      if (!username) {
        skippedRows++;
        continue;
      }

      processedRows++;

      if (!tokens[username]) {
        tokens[username] = [];
      }

      const tokenScore = parseInt(row[8]) || 0;
      // Auto-detect failed tokens by score (score 6 = failed)
      // This handles cases where Supabase returns all tokens in one array
      const isFailedToken = isFailed || tokenScore === 6;

      tokens[username].push({
        admin_username: username,  // Already normalized to lowercase
        base_token: row[1]?.trim() || '',
        token_name: row[2]?.trim() || '',
        token_symbol: row[3]?.trim() || '',
        community_link: row[4]?.trim() || '',
        token_age: row[5]?.trim() || '',  // Column F (5) - Token Age (e.g., "24d ago")
        market_cap: this.parseLocaleNumber(row[6]),  // Column G - Current MC
        ath_market_cap: this.parseLocaleNumber(row[7]),  // Column H - ATH MC
        token_score: tokenScore,  // Column I - Score
        created_at: row[9] ? (parseInt(row[9]) || null) : null,  // Column J (9) - Created At timestamp (Unix)
        is_failed_token: isFailedToken  // Mark as failed token
      });
    }

    const sheetType = isFailed ? 'failed' : 'regular';
    console.log(`[SheetsSync] Parsed ${processedRows} ${sheetType} token rows for ${Object.keys(tokens).length} admins. Skipped ${skippedRows} rows with empty usernames.`);

    return tokens;
  }


  /**
   * Main sync function - stores admin stats, comments, and tokens
   */
  async sync() {
    // Check license first
    if (!licenseValidator.isLicenseValid()) {
      console.warn('[SheetsSync] Sync blocked - license invalid');
      throw new Error(licenseValidator.getErrorMessage());
    }

    // Check if already syncing - if so, wait for it to complete
    if (this.isSyncing) {
      // Wait for current sync to complete (max 30 seconds)
      const maxWait = 300;
      let waited = 0;
      while (this.isSyncing && waited < maxWait) {
        await new Promise(resolve => setTimeout(resolve, 100));
        waited++;
      }
      // If still syncing after timeout, throw error
      if (this.isSyncing) {
        throw new Error('Sync timed out (already in progress)');
      }
      // Storage was already updated by the original sync
      return;
    }

    try {
      this.isSyncing = true;

      // Clear previous error
      await this.clearError();

      const now = Date.now();

      // Check if we need a full sync (every 5 minutes or first sync)
      const needsFullSync = !this.lastFullSync || (now - this.lastFullSync) > this.fullSyncInterval;
      const useRecentEndpoint = !needsFullSync;

      const syncType = needsFullSync ? 'FULL' : 'RECENT';
      const apiUrl = useRecentEndpoint ? this.recentApiUrl : this.apiUrl;

      console.log(`[SheetsSync] ${syncType} sync requested`);

      let apiData;

      if (this.useDirectSupabase) {
        // Use direct Supabase connection (bypasses Vercel size limits)
        console.log('[SheetsSync] Fetching data from Supabase directly...');
        try {
          // Pass lastFullSync timestamp - sync() will decide full vs recent
          apiData = await supabaseDirect.sync(this.lastFullSync);
          console.log(`[SheetsSync] Supabase ${apiData.syncType} sync complete`);
        } catch (directError) {
          console.error('[SheetsSync] Direct Supabase error:', directError);
          console.log('[SheetsSync] Falling back to Vercel API...');
          this.useDirectSupabase = false; // Temporarily disable for this session
          throw directError; // Will be caught below and retry
        }
      } else {
        // Use Vercel API (original behavior)
        console.log('[SheetsSync] Fetching data from Vercel API...');
        const response = await fetch(`${apiUrl}?_t=${now}`, {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${await licenseValidator.getAuthToken()}`
          },
          cache: 'no-store'
        });

        apiData = await response.json();

        if (!response.ok) {
          if (response.status === 401) {
            throw new Error('License validation required. Please check your license key.');
          }
          throw new Error(apiData.error || 'API request failed');
        }

        if (!apiData.success) {
          throw new Error(apiData.error || 'API request failed');
        }
      }

      console.log('[SheetsSync] API returned data:', {
        admins: apiData.admins?.length || 0,
        tokens: apiData.tokens?.length || 0,
        failedTokens: apiData.failedTokens?.length || 0,
        source: this.useDirectSupabase ? 'direct-supabase' : 'vercel-api'
      });

      // Parse admin stats
      const adminsData = this.parseAdminStats(apiData.admins || []);
      console.log('[SheetsSync] Parsed', Object.keys(adminsData).length, 'admins');

      // Parse tokens
      const tokensData = this.parseTokens(apiData.tokens || [], false);
      const failedTokensData = this.parseTokens(apiData.failedTokens || [], true);

      // Merge regular and failed tokens
      const allTokens = { ...tokensData };
      for (const [username, tokenList] of Object.entries(failedTokensData)) {
        if (!allTokens[username]) {
          allTokens[username] = [];
        }
        allTokens[username].push(...tokenList);
      }

      const totalTokens = Object.values(allTokens).flat().length;
      console.log('[SheetsSync] Parsed', totalTokens, 'total tokens for', Object.keys(allTokens).length, 'admins');

      if (needsFullSync) {
        // Full sync - replace all data and calculate fresh stats
        console.log('[SheetsSync] Full sync - replacing all data...');

        // Calculate admin stats from actual tokens (we have all tokens in full sync)
        const adminsCalculatedFromTokens = [];
        for (const [username, tokenList] of Object.entries(allTokens)) {
          const calculatedStats = this.calculateAdminStatsFromTokens(username, tokenList);
          if (calculatedStats) {
            // Preserve last_active and last_updated from Supabase if available
            if (adminsData[username]) {
              calculatedStats.last_active = adminsData[username].last_active;
              calculatedStats.last_updated = adminsData[username].last_updated;
            }
            adminsData[username] = calculatedStats;
            adminsCalculatedFromTokens.push(username);
          }
        }

        if (adminsCalculatedFromTokens.length > 0) {
          console.log('[SheetsSync] Calculated stats from actual tokens for', adminsCalculatedFromTokens.length, 'admins');
        }

        await indexedDBStorage.setAdminStats(adminsData);
        await indexedDBStorage.setTokens(allTokens);

        // Calculate and store daily stats from all tokens
        const dailyStats = this.calculateDailyStats(allTokens, now);
        await indexedDBStorage.setDailyStats(dailyStats);
        console.log('[SheetsSync] Stored daily stats for', dailyStats.length, 'days');

        this.lastFullSync = now;
      } else {
        // Recent sync - verify and correct, don't recalculate everything
        console.log('[SheetsSync] Recent sync - verifying and correcting data...');

        // Get existing data from database
        const existingAdmins = await indexedDBStorage.getAllAdminStats() || {};
        const existingTokens = await indexedDBStorage.getAllTokens() || {};

        // Merge recent tokens with existing tokens
        for (const [username, newTokenList] of Object.entries(allTokens)) {
          if (!existingTokens[username]) {
            existingTokens[username] = newTokenList;
          } else {
            // Merge by base_token (newer data overwrites older)
            const existingTokenMap = new Map();
            for (const token of existingTokens[username]) {
              existingTokenMap.set(token.base_token, token);
            }
            for (const newToken of newTokenList) {
              existingTokenMap.set(newToken.base_token, newToken);
            }
            existingTokens[username] = Array.from(existingTokenMap.values());
          }
        }

        // Verify and correct stats - only recalculate if mismatch detected
        let verifiedCount = 0;
        let correctedCount = 0;
        const adminsToCorrect = new Map();

        for (const [username, tokenList] of Object.entries(existingTokens)) {
          const dbAdmin = existingAdmins[username];
          const actualTokenCount = tokenList.length;

          // Check if we need to verify this admin (it was in recent sync or has mismatch)
          const needsVerification = allTokens[username] || !dbAdmin;

          if (needsVerification && dbAdmin) {
            // Verify: check if stored token count matches actual
            const storedCount = dbAdmin.total_tokens_created || 0;

            if (storedCount !== actualTokenCount) {
              // Mismatch detected - calculate correct stats
              console.log(`[SheetsSync] Stat mismatch for ${username}: DB says ${storedCount} tokens, actually has ${actualTokenCount}`);
              const calculatedStats = this.calculateAdminStatsFromTokens(username, tokenList);
              if (calculatedStats) {
                // Preserve last_active and last_updated from DB
                calculatedStats.last_active = dbAdmin.last_active;
                calculatedStats.last_updated = dbAdmin.last_updated;
                adminsToCorrect.set(username, calculatedStats);
                correctedCount++;
              }
            } else {
              verifiedCount++;
            }
          }
        }

        // Handle new admins from recent sync
        for (const [username, adminData] of Object.entries(adminsData)) {
          if (!existingAdmins[username] && existingTokens[username]) {
            // New admin - calculate stats from tokens
            const calculatedStats = this.calculateAdminStatsFromTokens(username, existingTokens[username]);
            if (calculatedStats) {
              calculatedStats.last_active = adminData.last_active;
              calculatedStats.last_updated = adminData.last_updated;
              adminsToCorrect.set(username, calculatedStats);
            }
          }
        }

        // Apply corrections
        for (const [username, stats] of adminsToCorrect) {
          existingAdmins[username] = stats;
        }

        if (correctedCount > 0) {
          console.log(`[SheetsSync] Corrected stats for ${correctedCount} admins, verified ${verifiedCount}`);
        } else {
          console.log(`[SheetsSync] Verified ${verifiedCount} admins - all stats correct`);
        }

        // Store updated admin stats
        await indexedDBStorage.setAdminStats(existingAdmins);

        // Use efficient upsertTokens for incremental updates
        const tokenStats = await indexedDBStorage.upsertTokens(allTokens, { deleteMissing: false });
        console.log(`[SheetsSync] Token upsert complete: ${tokenStats.added} added, ${tokenStats.updated} updated, ${tokenStats.deleted} deleted`);
      }

      await indexedDBStorage.setLastSyncTime(now);
      await indexedDBStorage.setMetadata('sheetsSyncError', null);

      // Notify all tabs to invalidate their cache
      chrome.tabs.query({}, (tabs) => {
        for (const tab of tabs) {
          if (tab.url && (tab.url.includes('trade.padre.gg') || tab.url.includes('axiom.trade'))) {
            chrome.tabs.sendMessage(tab.id, { action: 'sheetsDataUpdated' }).catch(() => {
              // Tab might not be ready to receive messages, ignore error
            });
          }
        }
      });

      console.log('[SheetsSync] Storage write successful');
      console.log('[SheetsSync] Stored', Object.keys(adminsData).length, 'admins with stats');
      console.log('[SheetsSync] Stored', totalTokens, 'tokens for', Object.keys(allTokens).length, 'admins');
      console.log('[SheetsSync] Sync completed successfully');

    } catch (error) {
      console.error('[SheetsSync] Sync failed:', error);
      await this.updateError(error.message);
      throw error;
    } finally {
      this.isSyncing = false;
    }
  }

  /**
   * Fetch tokens for a specific admin from IndexedDB
   * Falls back to Vercel API if not found in IndexedDB
   * @param {string} username - Admin username
   * @returns {Promise<Array>} Array of token data
   */
  async fetchAdminTokens(username) {
    const usernameLower = username.toLowerCase().trim();

    try {
      // Try to get from IndexedDB first
      console.log('[SheetsSync] Fetching tokens for admin from IndexedDB:', usernameLower);
      const tokens = await indexedDBStorage.getTokens(usernameLower);

      if (tokens && tokens.length > 0) {
        console.log('[SheetsSync] Found', tokens.length, 'tokens in IndexedDB for admin:', usernameLower);
        return tokens;
      }

      // Fallback: Fetch from API (shouldn't happen after first full sync)
      console.log('[SheetsSync] No tokens in IndexedDB, fetching from API for admin:', usernameLower);

      const allTokens = [];

      // Fetch regular tokens for this admin
      const tokensData = await this.fetchFromAPI("'Tokens - Sorted by Admin'!A1:I");
      const parsedTokens = this.parseTokens(tokensData.values || []);

      if (parsedTokens[usernameLower]) {
        allTokens.push(...parsedTokens[usernameLower]);
      }

      // Fetch failed tokens for this admin
      const failedTokensData = await this.fetchFromAPI("'Tokens - Failed (Under 10k)'!A1:I");
      const parsedFailedTokens = this.parseTokens(failedTokensData.values || [], true);

      if (parsedFailedTokens[usernameLower]) {
        allTokens.push(...parsedFailedTokens[usernameLower]);
      }

      console.log('[SheetsSync] Fetched', allTokens.length, 'tokens from API for admin:', usernameLower);
      return allTokens;

    } catch (error) {
      console.error('[SheetsSync] Failed to fetch tokens for admin:', usernameLower, error);
      // Return empty array instead of throwing, so modal can still render
      return [];
    }
  }

  /**
   * Update error in storage
   */
  async updateError(error) {
    return await indexedDBStorage.setMetadata('sheetsSyncError', error);
  }

  /**
   * Clear error from storage
   */
  async clearError() {
    return await indexedDBStorage.setMetadata('sheetsSyncError', null);
  }

  /**
   * Manual trigger for sync
   */
  async manualSync() {
    await this.sync();
  }

  /**
   * Test connection by fetching from API
   */
  async testConnection() {
    try {
      const data = await this.fetchFromAPI("'Admins'!A1:N2");
      return { success: true, rowCount: data.values?.length || 0 };
    } catch (error) {
      throw error;
    }
  }

}

// Initialize on service worker start
const sheetsSync = new SheetsSyncService();
sheetsSync.init();

// Listen for manual sync requests from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'syncSheetsNow') {
    sheetsSync.manualSync()
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'testSheetsConnection') {
    sheetsSync.testConnection()
      .then((result) => sendResponse({ success: true, ...result }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'fetchAdminTokens') {
    sheetsSync.fetchAdminTokens(request.username)
      .then((tokens) => sendResponse({ success: true, tokens }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Get admin stats from IndexedDB (for content scripts)
  if (request.action === 'getAdminStats') {
    indexedDBStorage.getAdminStats(request.username.toLowerCase())
      .then(admin => sendResponse({ success: true, admin }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Get all admin stats from IndexedDB (for content scripts)
  if (request.action === 'getAllAdminStats') {
    indexedDBStorage.getAllAdminStats()
      .then(admins => sendResponse({ success: true, admins }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Get last sync info from IndexedDB (for content scripts)
  if (request.action === 'getSyncInfo') {
    Promise.all([
      indexedDBStorage.getLastSyncTime(),
      indexedDBStorage.getMetadata('sheetsSyncError')
    ])
      .then(([lastSync, error]) => sendResponse({ success: true, lastSync, error }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  // Get all daily stats from IndexedDB (for content scripts)
  if (request.action === 'getAllDailyStats') {
    indexedDBStorage.getAllDailyStats()
      .then(dailyStats => sendResponse({ success: true, dailyStats }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Get daily stats for a specific date from IndexedDB (for content scripts)
  if (request.action === 'getDailyStats') {
    indexedDBStorage.getDailyStats(request.date)
      .then(dailyStat => sendResponse({ success: true, dailyStat }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Get all tokens from IndexedDB (for content scripts)
  if (request.action === 'getAllTokens') {
    indexedDBStorage.getAllTokens()
      .then(tokens => sendResponse({ success: true, tokens }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

});

// Export for testing
if (typeof module !== 'undefined' && module.exports) {
  module.exports = SheetsSyncService;
}
