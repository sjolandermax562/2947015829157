/**
 * Background Service Worker
 * Handles API requests and caching for the X Community Detector extension
 * Uses shared API client from api.js
 */

// Import database module first (loads indexedDBStorage global)
import { storage as indexedDBStorage } from '../shared/database.js';

// Import default settings for initialization on install
import { DEFAULT_SETTINGS } from '../shared/storage.js';

// Make available globally for api.js
self.indexedDBStorage = indexedDBStorage;

// ============================================
// MEMORY LEAK FIX: Use Map-based tabData instead of globalThis
// This ensures proper garbage collection and cleanup
// ============================================
const tabData = new Map(); // Maps tabId -> { communities: Map }

// Clean up tab data when tabs are closed
chrome.tabs.onRemoved.addListener((tabId) => {
  tabData.delete(tabId);
});

// Import Google Sheets sync service
import './sheets-sync.js';

// Import license validator for device ID generation
import { licenseValidator } from '../shared/license-validator.js';

// Import shared API client
import { api } from '../shared/api.js';

// ============================================
// Initialize default settings on service worker startup
// Ensures settings are available even if onInstalled doesn't fire
// ============================================
function initializeDefaultSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(DEFAULT_SETTINGS, (items) => {
      const missingSettings = Object.keys(DEFAULT_SETTINGS).filter(key => items[key] === undefined);
      if (missingSettings.length > 0) {
        const settingsToSet = {};
        missingSettings.forEach(key => {
          settingsToSet[key] = DEFAULT_SETTINGS[key];
        });
        chrome.storage.sync.set(settingsToSet, () => {
          console.log('✅ Default settings initialized:', settingsToSet);
          resolve();
        });
      } else {
        resolve();
      }
    });
  });
}

// Initialize settings on service worker startup
initializeDefaultSettings();

// Clear any stale update requirements from old manual notification system
chrome.storage.local.remove(['updateRequired', 'updateInfo'], () => {
  console.log('[Background] Cleared stale update flags on startup');
});

// Add MEVX-specific method to the imported api client
// PERFORMANCE: Added caching with TTL for MEVX token data
api.getMevxTokenData = async function(tokenAddress) {
  const cacheKey = `mevx_token_${tokenAddress}`;

  await this._ensureDB();

  // Check cache first
  const cached = this.db ? await this.db.getCache(cacheKey) : null;
  if (cached) {
    return cached;
  }

  // Check for in-flight request
  const pendingKey = `mevx_${tokenAddress}`;
  if (this.pendingRequests && this.pendingRequests.has(pendingKey)) {
    return this.pendingRequests.get(pendingKey);
  }

  const url = `https://api.mevx.io/api/v1/pools/search?q=${encodeURIComponent(tokenAddress)}`;

  const request = fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  })
  .then(async (response) => {
    if (!response.ok) {
      throw new Error(`MEVX API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();

    // PERFORMANCE: Cache with 5 minute TTL (token data is time-sensitive)
    if (this.db) {
      await this.db.setCache(cacheKey, data, 300, 'mevx_token');
    }

    if (this.pendingRequests) {
      this.pendingRequests.delete(pendingKey);
    }

    return data;
  })
  .catch((error) => {
    if (this.pendingRequests) {
      this.pendingRequests.delete(pendingKey);
    }
    console.error(`[API] MEVX fetch failed for ${tokenAddress}:`, error);
    throw error;
  });

  if (this.pendingRequests) {
    this.pendingRequests.set(pendingKey, request);
  }

  return request;
};

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'fetchCommunityInfo') {
    api.getCommunity(request.communityId)
      .then(data => sendResponse({ success: true, data }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'fetchUserProfile' || request.action === 'fetchFullProfile') {
    api.getUserProfile(request.username)
      .then(data => sendResponse({ success: true, data }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'fetchMevxTokenData') {
    api.getMevxTokenData(request.tokenAddress)
      .then(data => sendResponse({ success: true, data }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'clearCache') {
    api.clearCache()
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'getCacheStats') {
    const stats = api.getStats();
    sendResponse({ success: true, stats });
    return true;
  }

  // Get current tab ID
  if (request.action === 'getTabId') {
    sendResponse({ tabId: sender.tab?.id || 0 });
    return true;
  }

  // Get device ID - ensures fingerprint is generated if not exists
  if (request.action === 'getDeviceId') {
    licenseValidator.getDeviceId()
      .then(deviceId => sendResponse({ success: true, deviceId }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'registerCommunityOwner') {
    const { communityId, adminUsername, tabId } = request;

    // Use Map-based tracking for proper garbage collection
    if (!tabData.has(tabId)) {
      tabData.set(tabId, { communities: new Map() });
    }
    const communities = tabData.get(tabId).communities;

    const existingAdmin = communities.get(communityId);

    console.log(`[Community Verification] Checking community ${communityId} for @${adminUsername} (tab ${tabId}):`, {
      exists: !!existingAdmin,
      existingAdmin: existingAdmin || null
    });

    let responseData = {
      isFirstToken: !existingAdmin,
      isVerified: !existingAdmin,  // ONLY first token gets verified
      firstTokenAdmin: existingAdmin || null
    };

    // If no existing community token, register this one
    if (!existingAdmin) {
      communities.set(communityId, adminUsername);
      console.log(`[Community Verification] Registered community ${communityId} for @${adminUsername} (tab ${tabId})`);
      sendResponse({ success: true, data: responseData });
    } else {
      // Community already seen in this tab - this is a subsequent token
      // All subsequent tokens with same community are NOT verified
      console.log(`[Community Verification] Community ${communityId} already registered by @${existingAdmin}, @${adminUsername} gets X (tab ${tabId})`);
      sendResponse({ success: true, data: responseData });
    }
    return true;
  }

  // Clear community owners for a tab (called when tab is closed or navigated)
  if (request.action === 'clearCommunityOwners') {
    const { tabId } = request;
    tabData.delete(tabId); // Full cleanup with Map
    console.log(`[Community Verification] Cleared community owners for tab ${tabId}`);
    sendResponse({ success: true });
    return true;
  }
});

// Inject content scripts into existing tabs on install/update
chrome.runtime.onInstalled.addListener(async () => {
  // Initialize default settings on first install (must complete before script injection)
  await initializeDefaultSettings();

  // Clear community owners on install/update to ensure fresh verification state
  chrome.storage.local.remove(['communityOwners'], () => {
    console.log('[Community Verification] Cleared community owners on install/update');
  });

  try {
    const tabs = await chrome.tabs.query({ url: 'https://trade.padre.gg/trenches*' });

    for (const tab of tabs) {
      try {
        // Inject CSS first
        await chrome.scripting.insertCSS({
          target: { tabId: tab.id },
          files: ['src/styles/content.css']
        });

        // Then inject JS
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['src/shared/storage.js', 'src/content/content.js', 'src/content/core.js']
        });
      } catch (err) {
        // Silently skip tabs that can't be injected
      }
    }
  } catch (err) {
    console.error('❌ Error injecting scripts:', err);
  }
});

// Log cache statistics on startup
chrome.storage.local.get(null, (items) => {
  const cacheKeys = Object.keys(items).filter(key =>
    key.startsWith('community_cache_') ||
    key.startsWith('user_profile_') ||
    key.startsWith('mevx_token_')
  );
});

// ============================================
// SPA Navigation Handling
// Triggers content script execution on client-side routing
// ============================================

// Helper function to inject all content scripts for padre.gg trenches
async function injectTrenchesScripts(tabId) {
  try {
    const scripts = [
      'src/shared/constants.js',
      'src/shared/sheets-data.js',
      'src/shared/profile-tooltip-core.js',
      'src/shared/admin-display-core.js',
      'src/shared/community-api-core.js',
      'src/shared/mevx-api-client.js',
      'src/shared/admin-tokens-modal.js',
      'src/shared/score-filtered-tokens-modal.js',
      'src/shared/analytics-modal.js',
      'src/content/content.js',
      'src/content/core.js',
      'src/content/tracked-tweets.js',
      'src/services/adminAlertAudio.js'
    ];

    for (const script of scripts) {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: [script]
      });
    }

    // Inject CSS
    await chrome.scripting.insertCSS({
      target: { tabId: tabId },
      files: [
        'src/styles/content.css',
        'src/styles/admin-tokens-modal.css',
        'src/styles/analytics-modal.css'
      ]
    });
  } catch (err) {
    // Script might already be injected - that's okay
  }
}

// Helper function to inject all content scripts for axiom.trade
async function injectAxiomScripts(tabId) {
  try {
    const scripts = [
      'src/shared/constants.js',
      'src/shared/sheets-data.js',
      'src/shared/profile-tooltip-core.js',
      'src/shared/admin-display-core.js',
      'src/shared/community-api-core.js',
      'src/shared/mevx-api-client.js',
      'src/shared/admin-tokens-modal.js',
      'src/shared/score-filtered-tokens-modal.js',
      'src/shared/analytics-modal.js',
      'src/content/axiom.js',
      'src/content/tracked-tweets.js',
      'src/services/adminAlertAudio.js'
    ];

    for (const script of scripts) {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: [script]
      });
    }

    // Inject CSS
    await chrome.scripting.insertCSS({
      target: { tabId: tabId },
      files: [
        'src/styles/axiom.css',
        'src/styles/admin-tokens-modal.css',
        'src/styles/analytics-modal.css'
      ]
    });
  } catch (err) {
    // Script might already be injected - that's okay
  }
}

// Track which tabs have scripts injected to avoid duplicate injection
const injectedTabs = new Set();

// Helper to determine which scripts to inject based on URL
async function injectScriptsForUrl(tabId, url) {
  // Check if already injected for this tab
  const tabKey = `${tabId}-${url.split('?')[0]}`;
  if (injectedTabs.has(tabKey)) {
    // Already injected, just trigger reprocessing
    chrome.tabs.sendMessage(tabId, { action: 'processTokenCards' }, () => {
      // Ignore errors
    });
    return;
  }

  if (url.includes('trade.padre.gg/trenches') || url.includes('trade.padre.gg/trade/')) {
    await injectTrenchesScripts(tabId);
    injectedTabs.add(tabKey);
  } else if (url.includes('axiom.trade')) {
    await injectAxiomScripts(tabId);
    injectedTabs.add(tabKey);
  }
}

// Listen for SPA history state changes (pushState/replaceState)
chrome.webNavigation.onHistoryStateUpdated.addListener(async (details) => {
  if (details.frameId !== 0) return;

  const url = details.url;
  if (url.includes('trade.padre.gg') || url.includes('axiom.trade')) {
    await injectScriptsForUrl(details.tabId, url);
  }
}, { url: [{ hostSuffix: '.padre.gg' }, { hostSuffix: '.trade' }] });

// Listen for reference fragment updates (hash changes)
chrome.webNavigation.onReferenceFragmentUpdated.addListener(async (details) => {
  if (details.frameId !== 0) return;

  const url = details.url;
  if (url.includes('trade.padre.gg') || url.includes('axiom.trade')) {
    await injectScriptsForUrl(details.tabId, url);
  }
}, { url: [{ hostSuffix: '.padre.gg' }, { hostSuffix: '.trade' }] });

// Also listen for completed navigation (full page loads and SPA transitions)
chrome.webNavigation.onCompleted.addListener(async (details) => {
  if (details.frameId !== 0) return;

  const url = details.url;
  if (url.includes('trade.padre.gg') || url.includes('axiom.trade')) {
    await injectScriptsForUrl(details.tabId, url);
  }
}, { url: [{ hostSuffix: '.padre.gg' }, { hostSuffix: '.trade' }] });

// Clear injected tabs tracker when tabs are closed or updated
chrome.tabs.onRemoved.addListener((tabId) => {
  // Remove all entries for this tab
  for (const key of injectedTabs) {
    if (key.startsWith(`${tabId}-`)) {
      injectedTabs.delete(key);
    }
  }
});
