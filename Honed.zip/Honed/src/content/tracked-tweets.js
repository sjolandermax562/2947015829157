// Tracked Tweets Enhancement Script
// This script detects tweets from tracked users in token cards and applies overlays/sounds

(async function() {
  'use strict';

  // Cached data for instant access (updated via storage listeners)
  let cachedTrackedTweets = [];
  let cachedBlacklistedTweets = [];
  let cachedSettings = {
    trackedGradientEnabled: true,
    adminBackgroundEnabled: true,
    trackedBorderColor: '#22d3ee',
    trackedGradientColor: '#22d3ee',
    normalAdminColor: '#1a1a2e',
    trackedGradientOpacity: 20,
    adminAlertEnabled: false,
    adminAlertVolume: 50,
    tweetTrackingEnabled: true,
    // Tweets-specific visual settings
    tweetsGradientEnabled: true,
    tweetsShowOverlay: true,
    tweetsBorderColor: '#22d3ee',
    tweetsGradientColor: '#22d3ee',
    tweetsGradientOpacity: 20
  };
  let trackedUsernamesSet = new Set(); // Cached lowercase usernames
  let blacklistedUsernamesSet = new Set(); // Cached blacklisted usernames

  // Get tracked tweets from storage
  async function getTrackedTweets() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['trackedTweets'], (result) => {
        resolve(result.trackedTweets || []);
      });
    });
  }

  // Get blacklisted tweets from storage
  async function getBlacklistedTweets() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['blacklistedTweets'], (result) => {
        resolve(result.blacklistedTweets || []);
      });
    });
  }

  // Get settings from storage
  async function getSettings() {
    return new Promise((resolve) => {
      chrome.storage.sync.get({
        trackedGradientEnabled: true,
        adminBackgroundEnabled: true,
        trackedBorderColor: '#22d3ee',
        trackedGradientColor: '#22d3ee',
        normalAdminColor: '#1a1a2e',
        trackedGradientOpacity: 20,
        adminAlertEnabled: false,
        adminAlertVolume: 50,
        tweetTrackingEnabled: true,
        // Tweets-specific visual settings
        tweetsGradientEnabled: true,
        tweetsShowOverlay: true,
        tweetsBorderColor: '#22d3ee',
        tweetsGradientColor: '#22d3ee',
        tweetsGradientOpacity: 20
      }, (settings) => {
        resolve(settings);
      });
    });
  }

  // Update cached tracked tweets and usernames set
  function updateCachedTrackedTweets(tweets) {
    cachedTrackedTweets = tweets;
    trackedUsernamesSet = new Set(
      tweets.map(t => {
        const username = t.username || t.userName || t.screen_name;
        return username ? username.toLowerCase() : null;
      }).filter(Boolean)
    );
  }

  // Update cached blacklisted tweets and usernames set
  function updateCachedBlacklistedTweets(tweets) {
    cachedBlacklistedTweets = tweets;
    blacklistedUsernamesSet = new Set(
      tweets.map(t => {
        const username = t.username || t.userName || t.screen_name;
        return username ? username.toLowerCase() : null;
      }).filter(Boolean)
    );
  }

  // Initialize admin alert audio service
  async function initAdminAlertAudio() {
    const settings = await getSettings();

    if (window.AdminAlertAudio) {
      const volume = (settings.adminAlertVolume || 50) / 100;
      window.AdminAlertAudio.configure({
        enabled: settings.adminAlertEnabled || false,
        volume: volume,
        customSoundUrl: null
      });

    }
  }

  // Play alert sound when tracked tweet is detected
  async function onTrackedTweetDetected(username) {
    if (!window.AdminAlertAudio) {
      return;
    }

    const settings = await getSettings();

    if (!settings.adminAlertEnabled) {
      return;
    }

    // Try to unlock audio and play
    const audioService = window.AdminAlertAudio;

    // Update configuration with latest settings
    const volume = (settings.adminAlertVolume || 50) / 100;
    audioService.configure({
      enabled: true,
      volume: volume
    });

    await audioService.playAdminAlert();
  }

  // Hex to RGBA converter
  function hexToRgba(hex, alpha) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }

  // Extract username from tweet URL
  function extractUsernameFromTweetUrl(url) {
    // Match patterns like: x.com/{username}/status/{id} or twitter.com/{username}/status/{id}
    const patterns = [
      /(?:x\.com|twitter\.com)\/([^\/]+)\/status\/\d+/i,
      /(?:mobile\.x\.com|mobile\.twitter\.com)\/([^\/]+)\/status\/\d+/i
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) {
        return match[1].toLowerCase();
      }
    }
    return null;
  }

  // Find all tweet links in a card
  function findTweetLinksInCard(card) {
    const links = card.querySelectorAll('a[href*="/status/"]');
    const tweetLinks = [];

    links.forEach(link => {
      const href = link.getAttribute('href');
      const username = extractUsernameFromTweetUrl(href);
      if (username) {
        tweetLinks.push({ username, element: link });
      }
    });

    return tweetLinks;
  }

  // Find token card containers
  function findTokenCards() {
    const allCards = [];
    const seenCards = new Set();

    // Strategy 1: Look for [role="gridcell"] that contain tweet links
    const gridCells = document.querySelectorAll('[role="gridcell"]');
    gridCells.forEach((cell) => {
      // Skip known non-card UI elements
      if (cell.classList.contains('padre-no-scroll') ||
          cell.classList.contains('css-xek4ag') ||
          cell.classList.contains('MuiModal-root') ||
          cell.classList.contains('MuiBackdrop-root') ||
          cell.getAttribute('tabindex') === '-1' ||
          cell.closest('.MuiModal-root')) {
        return;
      }

      // Only include if this cell contains a community link OR a tweet link
      const hasCommunityLink = cell.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]');
      const hasTweetLink = cell.querySelector('a[href*="/status/"]');

      if ((hasCommunityLink || hasTweetLink) && !seenCards.has(cell)) {
        allCards.push(cell);
        seenCards.add(cell);
      }
    });

    // Strategy 2: Find cards via tweet links (walk up to find container)
    // This handles cases where cards don't have role="gridcell"
    const tweetLinks = document.querySelectorAll('a[href*="/status/"]');

    tweetLinks.forEach((link) => {
      // Skip if link is inside a modal
      if (link.closest('.MuiModal-root')) return;

      let parent = link;
      for (let i = 0; i < 20; i++) {
        parent = parent.parentElement;
        if (!parent) break;

        // Skip known non-card UI elements during traversal
        if (i < 3 && (parent.classList.contains('padre-no-scroll') ||
                       parent.classList.contains('css-xek4ag') ||
                       parent.classList.contains('MuiModal-root') ||
                       parent.classList.contains('MuiBackdrop-root') ||
                       parent.getAttribute('tabindex') === '-1')) {
          break;
        }

        // Look for various indicators of a card container:
        // 1. Has position absolute with dimensions
        // 2. Has specific MuiStack classes
        // 3. Has both width and height set
        const style = window.getComputedStyle(parent);
        const isPositionAbsolute = style.position === 'absolute';
        const hasHeight = parent.style.height || style.height !== 'auto';
        const hasWidth = parent.style.width || style.width !== 'auto';
        const isMuiStack = parent.className.includes('MuiStack');

        // Check if this looks like a card container
        if ((isPositionAbsolute && hasHeight && hasWidth) ||
            (isMuiStack && parent.children.length > 2)) {
          // Additional check: skip if inside a modal
          if (parent.closest('.MuiModal-root')) break;

          if (!seenCards.has(parent)) {
            allCards.push(parent);
            seenCards.add(parent);
          }
          break;
        }
      }
    });

    return allCards;
  }

  // Apply blacklist overlay with blur and reveal button
  function applyBlacklistOverlay(card, username) {
    // Skip known non-card UI elements
    if (card.classList.contains('padre-no-scroll') ||
        card.classList.contains('css-xek4ag')) {
      return;
    }

    // Mark card as blacklisted
    card.classList.add('blacklisted-token');

    // Check if overlay already exists
    if (card.querySelector('.blacklist-overlay')) {
      return;
    }

    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'blacklist-overlay';
    overlay.setAttribute('data-blacklist-username', username);

    // Create reveal button
    const revealBtn = document.createElement('button');
    revealBtn.className = 'blacklist-reveal-btn';
    revealBtn.textContent = 'Show';
    revealBtn.title = 'This token is from a blacklisted tweet author';

    revealBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      overlay.remove();
    });

    overlay.appendChild(revealBtn);
    card.appendChild(overlay);
  }

  // Apply tracked tweet styling to cards
  function applyTrackedTweetStyling(specificCards = null, forceRefresh = false) {
    const settings = cachedSettings;
    const trackedUsernames = trackedUsernamesSet;
    const blacklistedUsernames = blacklistedUsernamesSet;
    const viewportHeight = window.innerHeight;

    // Check if tweet tracking is enabled
    if (!settings.tweetTrackingEnabled) {
      return;
    }

    const cards = specificCards || findTokenCards();

    if (cards.length === 0) {
      return;
    }

    cards.forEach((card) => {
      // Find all tweet links in this card
      const tweetLinks = findTweetLinksInCard(card);

      if (tweetLinks.length === 0) {
        return; // No tweets in this card
      }

      // Check if any of the tweet authors are tracked or blacklisted
      let isTracked = false;
      let isBlacklisted = false;
      let detectedUsername = null;

      for (const tweet of tweetLinks) {
        if (trackedUsernames.has(tweet.username)) {
          isTracked = true;
          detectedUsername = tweet.username;
          break;
        }
        if (blacklistedUsernames.has(tweet.username)) {
          isBlacklisted = true;
          detectedUsername = tweet.username;
          break;
        }
      }

      // Per-card alert tracking: play alert once per card per session
      if (isTracked && !card.hasAttribute('data-tweet-alert-played')) {
        card.setAttribute('data-tweet-alert-played', 'true');
        onTrackedTweetDetected(detectedUsername);
      }

      const rect = card.getBoundingClientRect();
      const isVisible = rect.top < viewportHeight && rect.bottom > 0;

      if (!isVisible) {
        return;
      }

      // Check if card already has blacklist overlay
      const existingOverlay = card.querySelector('.blacklist-overlay');
      const existingOverlayUsername = existingOverlay?.getAttribute('data-blacklist-username');

      // Handle blacklist overlay
      if (isBlacklisted && !existingOverlay) {
        applyBlacklistOverlay(card, detectedUsername);
      } else if (existingOverlay && (forceRefresh || existingOverlayUsername !== detectedUsername || !isBlacklisted)) {
        existingOverlay.remove();
        card.classList.remove('blacklisted-token');
      }

      // Apply tracked tweet styling using tweets-specific settings
      if (isTracked) {
        // Apply gradient background only if tweetsGradientEnabled is true
        if (settings.adminBackgroundEnabled && settings.tweetsGradientEnabled) {
          const opacity = (settings.tweetsGradientOpacity || 20) / 100;
          const trackedColor = hexToRgba(settings.tweetsGradientColor, opacity * 0.5);
          card.style.setProperty('background', `linear-gradient(to left, ${trackedColor} 0%, transparent 50%)`, 'important');
        } else if (settings.adminBackgroundEnabled) {
          const opacity = (settings.tweetsGradientOpacity || 20) / 100;
          const normalColor = hexToRgba(settings.normalAdminColor, opacity * 0.5);
          card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
        }

        // Apply border/overlay only if tweetsShowOverlay is true
        if (settings.tweetsShowOverlay) {
          card.style.setProperty('border', `2px solid ${settings.tweetsBorderColor}`, 'important');
          card.style.setProperty('border-radius', `12px`, 'important');
        } else {
          card.style.setProperty('border', `none`, 'important');
        }
      } else if (settings.adminBackgroundEnabled) {
        const opacity = (settings.tweetsGradientOpacity || 20) / 100;
        const normalColor = hexToRgba(settings.normalAdminColor, opacity * 0.5);
        card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
        card.style.setProperty('border', `none`, 'important');
        card.style.setProperty('border-radius', `12px`, 'important');
      }
    });
  }

  // Find tweet links in new nodes
  function findTweetLinksInNodes(nodes) {
    const cards = [];
    nodes.forEach(node => {
      if (node.nodeType === 1) { // Element node
        // Check if the node itself is a gridcell (card)
        if (node.getAttribute && node.getAttribute('role') === 'gridcell') {
          cards.push(node);
        }
        // Check children for gridcells
        if (node.querySelectorAll) {
          const found = node.querySelectorAll('[role="gridcell"]');
          cards.push(...Array.from(found));
        }
      }
    });
    return cards;
  }

  // Initialize
  async function init() {
    // Populate cache with initial data
    const [trackedTweets, blacklistedTweets, settings] = await Promise.all([
      getTrackedTweets(),
      getBlacklistedTweets(),
      getSettings()
    ]);
    updateCachedTrackedTweets(trackedTweets);
    updateCachedBlacklistedTweets(blacklistedTweets);
    Object.assign(cachedSettings, settings);

    // Initialize admin alert audio service
    await initAdminAlertAudio();

    let attempts = 0;
    const maxAttempts = 10;

    while (attempts < maxAttempts) {
      const cards = findTokenCards();
      if (cards.length > 0) {
        break;
      }
      attempts++;
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    // Apply styling
    applyTrackedTweetStyling();

    const observer = new MutationObserver((mutations) => {
      const addedNodes = [];
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === 1) {
            addedNodes.push(node);
          }
        }
      }

      if (addedNodes.length === 0) return;

      const newCards = findTweetLinksInNodes(addedNodes);
      if (newCards.length > 0) {
        applyTrackedTweetStyling(newCards);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    let scrollFrame;
    window.addEventListener('scroll', () => {
      cancelAnimationFrame(scrollFrame);
      scrollFrame = requestAnimationFrame(() => {
        applyTrackedTweetStyling();
      });
    }, { passive: true });

    // Periodic scan every 200ms for tracked tweet styling - store for cleanup
    const periodicStylingScan = setInterval(() => {
      applyTrackedTweetStyling();
    }, 200);

    // Cleanup on page unload to prevent memory leaks
    window.addEventListener('beforeunload', () => {
      clearInterval(periodicStylingScan);
      observer.disconnect();
    });

    // Setup hot-reload listener for settings changes
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'sync') {
        const startTime = performance.now();

        const relevantKeys = [
          'tweetTrackingEnabled',
          'trackedGradientEnabled',
          'adminBackgroundEnabled',
          'trackedBorderColor',
          'trackedGradientColor',
          'normalAdminColor',
          'trackedGradientOpacity',
          'adminAlertEnabled',
          'adminAlertVolume',
          // Tweets-specific visual settings
          'tweetsGradientEnabled',
          'tweetsShowOverlay',
          'tweetsBorderColor',
          'tweetsGradientColor',
          'tweetsGradientOpacity'
        ];

        const hasRelevantChange = Object.keys(changes).some(key => {
          if (!relevantKeys.includes(key)) return false;

          const setting = changes[key];
          const oldValue = setting.oldValue;
          const newValue = setting.newValue;

          // Update cached settings immediately
          cachedSettings[key] = newValue;

          // Update CSS custom properties for colors
          if (key === 'trackedBorderColor') {
            document.documentElement.style.setProperty('--tracked-border-color', newValue);
          }

          if (key === 'trackedGradientColor') {
            document.documentElement.style.setProperty('--tracked-gradient-color', newValue);
          }

          if (key === 'normalAdminColor') {
            document.documentElement.style.setProperty('--normal-admin-color', newValue);
          }

          // Update admin alert audio settings
          if (key === 'adminAlertEnabled' || key === 'adminAlertVolume') {
            initAdminAlertAudio();
          }

          return true;
        });

        if (hasRelevantChange) {
          // Clear existing inline styles from cards
          document.querySelectorAll('[role="gridcell"]').forEach(card => {
            // Verify this is a token card by checking for community or tweet links
            if (card.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"], a[href*="/status/"]')) {
              if (card.style.background || card.style.border) {
                // Remove inline styles properly
                card.style.removeProperty('background');
                card.style.removeProperty('border');
                card.style.removeProperty('border-radius');
              }
            }
          });
          applyTrackedTweetStyling();
        }
      }

      // Handle tracked tweets list changes
      if (areaName === 'local' && changes.trackedTweets) {
        const newTweets = changes.trackedTweets.newValue || [];
        updateCachedTrackedTweets(newTweets);
      }

      // Handle blacklisted tweets list changes
      if (areaName === 'local' && changes.blacklistedTweets) {
        const newBlacklist = changes.blacklistedTweets.newValue || [];
        updateCachedBlacklistedTweets(newBlacklist);
        // Force refresh to show/hide blacklist overlays
        applyTrackedTweetStyling(null, true);
      }
    });
  }

  // Run initialization
  init();
})();
